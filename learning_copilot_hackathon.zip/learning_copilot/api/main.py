"""
FastAPI Application — Multi-Agent Learning Copilot
===================================================
All endpoints, middleware, error handling, and dependency injection.

Endpoints:
  GET  /health                         Health check
  POST /session/start                  Initialize a learning session
  POST /session/{id}/respond           Process one student turn (main loop)
  GET  /session/{id}/state             Current student model / knowledge map
  GET  /session/{id}/history           Conversation + evaluation history
  POST /session/{id}/set-topic         Change learning topic mid-session
  POST /session/{id}/generate-problem  Assessment Agent: get next targeted problem
  GET  /session/{id}/knowledge-map     Full knowledge map with calibration data
  POST /demo/full-loop                 One-shot demo endpoint (hackathon)
"""
import os
import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, HTTPException, Body, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from models.schemas import SessionState, StudentProfile, LearningPreferences, ConceptMastery
from core.orchestrator import LearningOrchestrator
from core.storage import build_storage
from core.logging import RequestLoggingMiddleware, get_logger
from agents.assessment import generate_targeted_problem
from core.spaced_repetition import get_review_schedule, select_next_concept, format_schedule_summary

logger = get_logger(__name__)

# ─────────────────────────────────────────────
# APP
# ─────────────────────────────────────────────
app = FastAPI(
    title="Multi-Agent Learning Copilot",
    description=(
        "Adaptive learning system with step-level reasoning evaluation. "
        "Optimizes for deep understanding, not correct answers."
    ),
    version="1.0.0-mvp",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(RequestLoggingMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─────────────────────────────────────────────
# GLOBAL ERROR HANDLER
# ─────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    request_id = getattr(request.state, "request_id", "unknown")
    logger.error(
        "unhandled_exception",
        extra={
            "request_id": request_id,
            "path": request.url.path,
            "error": str(exc),
            "error_type": type(exc).__name__,
        }
    )
    return JSONResponse(
        status_code=500,
        content={
            "error": "internal_server_error",
            "message": "An unexpected error occurred.",
            "request_id": request_id,
        }
    )


# ─────────────────────────────────────────────
# DEPENDENCIES
# ─────────────────────────────────────────────
storage = build_storage()
from core.llm_client import build_llm_client as _build_llm_client

_llm_client = None
_orchestrator = None

def get_llm_client():
    global _llm_client
    if _llm_client is None:
        _llm_client = _build_llm_client()
    return _llm_client

def get_orchestrator():
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = LearningOrchestrator(get_llm_client(), storage)
    return _orchestrator


async def get_session_or_404(session_id: str) -> SessionState:
    session = await storage.load_session(session_id)
    if not session:
        raise HTTPException(
            status_code=404,
            detail={"error": "session_not_found", "session_id": session_id}
        )
    return session


# ─────────────────────────────────────────────
# REQUEST / RESPONSE MODELS
# ─────────────────────────────────────────────
class StartSessionRequest(BaseModel):
    model_config = {"json_schema_extra": {"example": {"student_name": "Alice", "topic": "linear_equations", "preferred_style": "direct", "prior_mastery": 0.0}}}
    student_name: str = "Student"
    topic: str
    preferred_style: str = "direct"
    prior_mastery: float = 0.0


class StudentResponseRequest(BaseModel):
    model_config = {"json_schema_extra": {"example": {"message": "Here is my solution", "steps": ["Subtract 5: 2x = 8", "Divide by 2: x = 4"], "confidence": 0.8}}}
    message: str
    steps: Optional[list[str]] = None
    confidence: Optional[float] = None


class SetTopicRequest(BaseModel):
    topic: str
    reset_mastery: bool = False


class GenerateProblemRequest(BaseModel):
    force_transfer: bool = False


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────
@app.get("/health", tags=["System"])
async def health():
    """Health check — does not require API key."""
    return {
        "status": "ok",
        "timestamp": datetime.now(timezone.utc).isoformat() + "Z",
        "version": "1.0.0-mvp",
        "agents": [
            "orchestrator", "step_evaluator", "student_model",
            "tutor", "socratic", "evaluation", "assessment"
        ],
    }


@app.post("/session/start", tags=["Session"])
async def start_session(req: StartSessionRequest):
    """
    Initialize a new learning session.

    Returns a session_id used in all subsequent calls.
    The system immediately runs the first teaching turn.
    """
    if req.prior_mastery < 0.0 or req.prior_mastery > 1.0:
        raise HTTPException(status_code=422, detail="prior_mastery must be between 0.0 and 1.0")

    valid_styles = {"direct", "socratic", "examples_first", "visual"}
    if req.preferred_style not in valid_styles:
        raise HTTPException(
            status_code=422,
            detail=f"preferred_style must be one of: {sorted(valid_styles)}"
        )

    session_id = str(uuid.uuid4())[:8]
    student_id = str(uuid.uuid4())[:12]

    profile = StudentProfile(
        student_id=student_id,
        name=req.student_name,
        current_topic=req.topic,
        session_id=session_id,
        preferences=LearningPreferences(preferred_style=req.preferred_style),
    )
    profile.concept_mastery[req.topic] = ConceptMastery(
        concept_id=req.topic,
        concept_name=req.topic.replace("_", " ").title(),
        mastery_score=req.prior_mastery,
    )

    session = SessionState(session_id=session_id, student_profile=profile)
    await storage.save_session(session)

    # First teaching turn
    initial = await get_orchestrator().process_student_response(
        session=session,
        student_input=f"I want to learn about {req.topic}",
    )

    logger.info(
        "session_started",
        extra={
            "session_id": session_id,
            "student_id": student_id,
            "topic": req.topic,
            "prior_mastery": req.prior_mastery,
        }
    )

    return {
        "session_id": session_id,
        "student_id": student_id,
        "topic": req.topic,
        "initial_message": initial.get("response", ""),
        "phase": session.current_phase,
        "teaching_strategy": initial.get("strategy_used", "direct"),
    }


@app.post("/session/{session_id}/respond", tags=["Learning Loop"])
async def student_respond(session_id: str, req: StudentResponseRequest):
    """
    Process one student turn — the core learning loop entry point.

    If `steps` is provided, the Step Evaluator agent analyzes each step
    individually to find the first incorrect reasoning step.

    If `steps` is omitted and the system is in test phase, it will ask
    the student to provide step-by-step reasoning.
    """
    session = await get_session_or_404(session_id)

    if req.confidence is not None:
        if not 0.0 <= req.confidence <= 1.0:
            raise HTTPException(status_code=422, detail="confidence must be between 0.0 and 1.0")
        cm = session.student_profile.concept_mastery.get(session.student_profile.current_topic)
        if cm:
            cm.confidence_score = req.confidence

    result = await get_orchestrator().process_student_response(
        session=session,
        student_input=req.message,
        student_steps=req.steps,
    )
    return result


@app.get("/session/{session_id}/state", tags=["Student Model"])
async def get_session_state(session_id: str):
    """
    Get the current student model — the live knowledge map.

    Returns mastery scores, confidence scores, calibration errors,
    misconception tags, streak counters, and understanding mode.
    """
    session = await get_session_or_404(session_id)
    profile = session.student_profile

    knowledge_map = {
        cid: {
            "name": cm.concept_name,
            "mastery": round(cm.mastery_score, 3),
            "confidence": round(cm.confidence_score, 3),
            "calibration_error": round(abs(cm.confidence_score - cm.mastery_score), 3),
            "overconfident": cm.confidence_score > cm.mastery_score + 0.15,
            "misconceptions": cm.misconception_tags,
            "is_memorization_risk": cm.is_memorization_risk,
            "last_tested": cm.last_tested.isoformat() if cm.last_tested else None,
        }
        for cid, cm in profile.concept_mastery.items()
    }

    return {
        "session_id": session_id,
        "student": {
            "id": profile.student_id,
            "name": profile.name,
        },
        "current_topic": profile.current_topic,
        "current_phase": session.current_phase,
        "loop_count": session.loop_count,
        "understanding_mode": profile.understanding_mode,
        "plateau_detected": profile.learning_plateau_detected,
        "focus_score": round(profile.current_focus_score, 2),
        "performance": {
            "questions_attempted": profile.questions_attempted,
            "questions_correct": profile.questions_correct,
            "accuracy": round(
                profile.questions_correct / max(profile.questions_attempted, 1), 3
            ),
            "consecutive_correct": session.consecutive_correct,
            "consecutive_wrong": session.consecutive_wrong,
        },
        "knowledge_map": knowledge_map,
        "recent_mistakes": [
            {
                "concept": m.concept_id,
                "type": m.mistake_type,
                "description": m.description,
                "step": m.step_number,
                "timestamp": m.timestamp.isoformat(),
            }
            for m in profile.recent_mistakes[-5:]
        ],
    }


@app.get("/session/{session_id}/knowledge-map", tags=["Student Model"])
async def get_knowledge_map(session_id: str):
    """
    Detailed knowledge map with calibration analysis.

    Useful for dashboards and progress visualization.
    """
    session = await get_session_or_404(session_id)
    profile = session.student_profile

    concepts = []
    for cid, cm in profile.concept_mastery.items():
        calibration_error = abs(cm.confidence_score - cm.mastery_score)
        concepts.append({
            "concept_id": cid,
            "concept_name": cm.concept_name,
            "mastery": round(cm.mastery_score, 3),
            "confidence": round(cm.confidence_score, 3),
            "calibration_error": round(calibration_error, 3),
            "calibration_status": (
                "overconfident" if cm.confidence_score > cm.mastery_score + 0.15
                else "underconfident" if cm.mastery_score > cm.confidence_score + 0.15
                else "calibrated"
            ),
            "understanding_depth": (
                "deep" if cm.mastery_score > 0.75 and not cm.is_memorization_risk
                else "procedural" if cm.mastery_score > 0.4
                else "surface"
            ),
            "misconceptions": cm.misconception_tags,
            "memorization_risk": cm.is_memorization_risk,
            "last_tested": cm.last_tested.isoformat() if cm.last_tested else None,
        })

    # Sort by mastery ascending (weakest first — that's the priority)
    concepts.sort(key=lambda x: x["mastery"])

    return {
        "session_id": session_id,
        "student_name": profile.name,
        "total_concepts": len(concepts),
        "concepts": concepts,
        "summary": {
            "avg_mastery": round(
                sum(c["mastery"] for c in concepts) / max(len(concepts), 1), 3
            ),
            "concepts_at_risk": [c["concept_id"] for c in concepts if c["mastery"] < 0.4],
            "memorization_risk_concepts": [
                c["concept_id"] for c in concepts if c["memorization_risk"]
            ],
            "overconfident_concepts": [
                c["concept_id"] for c in concepts if c["calibration_status"] == "overconfident"
            ],
        },
    }


@app.get("/session/{session_id}/history", tags=["Session"])
async def get_history(session_id: str, last_n: int = 10):
    """
    Conversation and evaluation history.

    `last_n` controls how many turns to return (default 10, max 50).
    """
    if last_n > 50:
        raise HTTPException(status_code=422, detail="last_n cannot exceed 50")

    session = await get_session_or_404(session_id)

    return {
        "session_id": session_id,
        "total_turns": len(session.conversation_history),
        "returned": min(last_n, len(session.conversation_history)),
        "history": session.conversation_history[-last_n:],
        "last_step_eval": (
            session.last_step_eval.model_dump()
            if session.last_step_eval else None
        ),
        "last_eval": (
            session.last_eval.model_dump()
            if session.last_eval else None
        ),
    }


@app.post("/session/{session_id}/set-topic", tags=["Session"])
async def set_topic(session_id: str, req: SetTopicRequest):
    """
    Change the learning topic mid-session.

    Resets the learning loop to the teach phase for the new topic.
    Optionally clears mastery data for the topic if reset_mastery=true.
    """
    session = await get_session_or_404(session_id)

    old_topic = session.student_profile.current_topic
    session.student_profile.current_topic = req.topic
    session.current_phase = "teach"
    session.consecutive_correct = 0
    session.consecutive_wrong = 0
    session.student_profile.learning_plateau_detected = False
    session.student_profile.current_focus_score = 1.0

    if req.reset_mastery and req.topic in session.student_profile.concept_mastery:
        del session.student_profile.concept_mastery[req.topic]

    # Ensure topic has a mastery entry
    if req.topic not in session.student_profile.concept_mastery:
        session.student_profile.concept_mastery[req.topic] = ConceptMastery(
            concept_id=req.topic,
            concept_name=req.topic.replace("_", " ").title(),
        )

    await storage.save_session(session)

    logger.info(
        "topic_changed",
        extra={
            "session_id": session_id,
            "old_topic": old_topic,
            "new_topic": req.topic,
        }
    )

    return {
        "session_id": session_id,
        "previous_topic": old_topic,
        "new_topic": req.topic,
        "phase_reset_to": "teach",
        "mastery_reset": req.reset_mastery,
    }


@app.post("/session/{session_id}/generate-problem", tags=["Assessment"])
async def generate_problem(session_id: str, req: GenerateProblemRequest):
    """
    Assessment Agent: generate one targeted problem from the student's weakness map.

    The problem is calibrated to mastery + 0.15 (zone of proximal development)
    and targets the concept with the highest-priority weakness.

    Set force_transfer=true to generate a transfer problem that tests if
    the student can apply the concept in a different domain — the ultimate
    test of deep understanding vs. memorization.
    """
    session = await get_session_or_404(session_id)

    problem = await generate_targeted_problem(
        profile=session.student_profile,
        llm_client=get_llm_client(),
        force_transfer=req.force_transfer,
    )

    logger.info(
        "problem_generated",
        extra={
            "session_id": session_id,
            "target_concept": problem.get("target_concept"),
            "difficulty": problem.get("difficulty"),
            "is_transfer": req.force_transfer,
        }
    )

    return {
        "session_id": session_id,
        "problem": problem,
        "instruction": (
            "Please solve this step-by-step. Show each step on a separate line. "
            "Submit your solution using POST /session/{id}/respond with your steps in the 'steps' array."
        ),
    }


# ─────────────────────────────────────────────
# SPACED REPETITION
# ─────────────────────────────────────────────
@app.get("/session/{session_id}/schedule", tags=["Assessment"])
async def get_review_schedule_endpoint(session_id: str):
    """
    Spaced repetition review schedule.

    Returns all tracked concepts ordered by urgency:
    - critical: retention < 40% (concept nearly forgotten)
    - due: retention < 65% (scheduled review)
    - upcoming: review due within 24h
    - ok: well retained

    Also suggests the optimal next concept to study.
    """
    session = await get_session_or_404(session_id)
    schedule = get_review_schedule(session.student_profile)
    next_concept = select_next_concept(session.student_profile)

    return {
        "session_id": session_id,
        "next_concept_recommended": next_concept,
        "summary": format_schedule_summary(schedule),
        "schedule": [
            {
                "concept_id":     item.concept_id,
                "concept_name":   item.concept_name,
                "mastery":        item.mastery,
                "retention":      item.retention,
                "urgency":        item.urgency,
                "hours_overdue":  item.hours_overdue,
                "next_review_at": item.next_review_at.isoformat(),
            }
            for item in schedule
        ],
    }


# ─────────────────────────────────────────────
# DEMO ENDPOINT
# ─────────────────────────────────────────────
@app.post("/demo/full-loop", tags=["Demo"])
async def demo_full_loop(
    topic: str = Body(...),
    student_name: str = Body("Demo Student"),
    problem: str = Body(...),
    student_steps: list[str] = Body(...),
):
    """
    One-shot demo endpoint for the hackathon showcase.

    Creates a session → teaches → evaluates steps → updates student model →
    generates a Socratic question — all in one API call.

    Demo-able in < 3 minutes. No setup required beyond ANTHROPIC_API_KEY.
    """
    # 1. Start session
    start_req = StartSessionRequest(
        topic=topic,
        student_name=student_name,
        prior_mastery=0.3,
    )
    start_result = await start_session(start_req)
    session_id = start_result["session_id"]

    # 2. Student attempts problem with steps
    respond_req = StudentResponseRequest(
        message=f"Here is my attempt at: {problem}",
        steps=student_steps,
        confidence=0.7,
    )
    eval_result = await student_respond(session_id, respond_req)

    # 3. Get knowledge map
    state = await get_session_state(session_id)

    return {
        "demo_session_id": session_id,
        "topic": topic,
        "problem": problem,
        "student_steps": student_steps,
        "evaluation": {
            "step_analysis": eval_result.get("step_analysis", []),
            "first_incorrect_step": eval_result.get("first_incorrect_step"),
            "mistake_type": eval_result.get("mistake_type"),
            "system_response": eval_result.get("response", ""),
            "next_action": eval_result.get("next_action"),
        },
        "student_model_after": {
            "knowledge_map": state["knowledge_map"],
            "understanding_mode": state["understanding_mode"],
            "performance": state["performance"],
        },
        "how_to_continue": (
            f"POST /session/{session_id}/respond with your next attempt "
            f"or POST /session/{session_id}/generate-problem for a targeted practice problem."
        ),
    }
