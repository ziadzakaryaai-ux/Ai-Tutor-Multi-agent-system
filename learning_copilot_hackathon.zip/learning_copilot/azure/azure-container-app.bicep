// azure-container-app.bicep
// ─────────────────────────────────────────────────────────────────────────────
// Deploys:
//   - Azure Container Apps environment
//   - Container App (the FastAPI backend)
//   - Log Analytics workspace (structured JSON logs)
//   - Cosmos DB account + database + container  (optional — controlled by param)
// ─────────────────────────────────────────────────────────────────────────────

@description('Container image tag (set by deploy-azure.sh)')
param containerImage string = 'learning-copilot:latest'

@description('Anthropic API key (stored as a secret)')
@secure()
param anthropicApiKey string = ''

@description('Azure OpenAI endpoint (leave blank to use Anthropic)')
param azureOpenAiEndpoint string = ''

@secure()
param azureOpenAiApiKey string = ''

@description('Minimum replica count (0 = scale to zero)')
param minReplicas int = 0

@description('Maximum replica count')
param maxReplicas int = 3

@description('Deploy Cosmos DB storage backend?')
param deployCosmosDb bool = false

var location = resourceGroup().location
var appName = 'learning-copilot'
var logWorkspaceName = '${appName}-logs'
var environmentName = '${appName}-env'
var containerAppName = appName

// ── Log Analytics workspace ───────────────────────────────────────────────
resource logWorkspace 'Microsoft.OperationalInsights/workspaces@2022-10-01' = {
  name: logWorkspaceName
  location: location
  properties: {
    sku: { name: 'PerGB2018' }
    retentionInDays: 30
  }
}

// ── Container Apps environment ────────────────────────────────────────────
resource environment 'Microsoft.App/managedEnvironments@2023-05-01' = {
  name: environmentName
  location: location
  properties: {
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: logWorkspace.properties.customerId
        sharedKey: logWorkspace.listKeys().primarySharedKey
      }
    }
  }
}

// ── Cosmos DB (optional) ─────────────────────────────────────────────────
resource cosmosAccount 'Microsoft.DocumentDB/databaseAccounts@2023-04-15' = if (deployCosmosDb) {
  name: '${appName}-cosmos'
  location: location
  kind: 'GlobalDocumentDB'
  properties: {
    databaseAccountOfferType: 'Standard'
    locations: [{ locationName: location, failoverPriority: 0 }]
    capabilities: [{ name: 'EnableServerless' }]
  }
}

// ── Container App ─────────────────────────────────────────────────────────
resource containerApp 'Microsoft.App/containerApps@2023-05-01' = {
  name: containerAppName
  location: location
  properties: {
    managedEnvironmentId: environment.id
    configuration: {
      ingress: {
        external: true
        targetPort: 8000
        transport: 'auto'
        allowInsecure: false
      }
      secrets: [
        { name: 'anthropic-api-key', value: anthropicApiKey }
        { name: 'azure-openai-api-key', value: azureOpenAiApiKey }
      ]
    }
    template: {
      containers: [
        {
          name: containerAppName
          image: containerImage
          resources: { cpu: json('0.5'), memory: '1Gi' }
          env: [
            { name: 'ANTHROPIC_API_KEY', secretRef: 'anthropic-api-key' }
            { name: 'AZURE_OPENAI_ENDPOINT', value: azureOpenAiEndpoint }
            { name: 'AZURE_OPENAI_API_KEY', secretRef: 'azure-openai-api-key' }
            { name: 'STORAGE_BACKEND', value: deployCosmosDb ? 'cosmos' : 'json' }
            { name: 'PORT', value: '8000' }
          ]
        }
      ]
      scale: {
        minReplicas: minReplicas
        maxReplicas: maxReplicas
        rules: [
          {
            name: 'http-scaling'
            http: { metadata: { concurrentRequests: '10' } }
          }
        ]
      }
    }
  }
}

output appUrl string = 'https://${containerApp.properties.configuration.ingress.fqdn}'
output environmentName string = environment.name
