#!/usr/bin/env bash
# deploy-azure.sh
# ─────────────────────────────────────────────────────────────────────────────
# One-command deploy to Azure Container Apps.
#
# Prerequisites:
#   az login
#   az acr login --name <your-registry>
#   Docker running locally
#
# Usage:
#   chmod +x azure/deploy-azure.sh
#   ./azure/deploy-azure.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

# ── config (edit these) ──────────────────────────────────
RESOURCE_GROUP="learning-copilot-rg"
LOCATION="eastus"
ACR_NAME="<your-registry>"          # Azure Container Registry name (no .azurecr.io)
IMAGE_TAG="${ACR_NAME}.azurecr.io/learning-copilot:$(date +%Y%m%d-%H%M%S)"
PARAMS_FILE="azure/azure-params.json"

echo "═══════════════════════════════════════════════════════"
echo " Learning Copilot — Azure Deployment"
echo "═══════════════════════════════════════════════════════"

# ── 1. Build & push image ────────────────────────────────
echo ""
echo "[1/4] Building Docker image: $IMAGE_TAG"
docker build -t "$IMAGE_TAG" .

echo "[2/4] Pushing to Azure Container Registry..."
docker push "$IMAGE_TAG"

# ── 2. Update params file with new image tag ─────────────
echo "[3/4] Patching container image in params file..."
python3 -c "
import json, sys
with open('$PARAMS_FILE') as f:
    params = json.load(f)
params['parameters']['containerImage']['value'] = '$IMAGE_TAG'
with open('$PARAMS_FILE', 'w') as f:
    json.dump(params, f, indent=2)
print('  containerImage →', '$IMAGE_TAG')
"

# ── 3. Deploy ────────────────────────────────────────────
echo "[4/4] Deploying to Azure Container Apps..."
az group create --name "$RESOURCE_GROUP" --location "$LOCATION" --output none

DEPLOY_OUTPUT=$(az deployment group create \
    --resource-group "$RESOURCE_GROUP" \
    --template-file azure/azure-container-app.bicep \
    --parameters @"$PARAMS_FILE" \
    --output json)

APP_URL=$(echo "$DEPLOY_OUTPUT" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d['properties']['outputs']['appUrl']['value'])")

echo ""
echo "═══════════════════════════════════════════════════════"
echo " Deployment complete!"
echo " API:  $APP_URL"
echo " Docs: $APP_URL/docs"
echo " Health: $(curl -s "$APP_URL/health" | python3 -c 'import json,sys; d=json.load(sys.stdin); print(d["status"])')"
echo "═══════════════════════════════════════════════════════"
