# azure deployment resources
