"""
Multi-Agent Learning Copilot — Core Data Models
All inter-agent communication is typed. These schemas are the contract.
"""
from __future__ import annotations
from typing import Literal, Optional
from pydantic import BaseModel, Field
from datetime import datetime, timezone
import uuid


# ─────────────────────────────────────────────
# MISTAKE TAXONOMY
# ─────────────────────────────────────────────
MistakeType = Literal[
    "conceptual",    # Wrong mental model of the concept
    "procedural",    # Right concept, wrong steps
    "careless",      # Arithmetic / transcription slip
    "knowledge_gap", # Missing prerequisite knowledge
    "confidence_mismatch",  # Correct but claims uncertainty, or vice versa
]

# ─────────────────────────────────────────────
# STUDENT MODEL  (the core state, persists across sessions)
# ─────────────────────────────────────────────
class ConceptMastery(BaseModel):
    concept_id: str
    concept_name: str
    mastery_score: float = Field(0.0, ge=0.0, le=1.0, description="0=no knowledge, 1=expert")
    confidence_score: float = Field(0.5, ge=0.0, le=1.0, description="Student's self-assessed confidence")
    calibration_error: float = Field(0.0, description="abs(confidence - mastery). Detects overconfidence.")
    misconception_tags: list[str] = Field(default_factory=list)
    last_tested: Optional[datetime] = None
    is_memorization_risk: bool = False  # True if pattern-matching suspected


class RecentMistake(BaseModel):
    mistake_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    concept_id: str
    mistake_type: MistakeType
    description: str
    step_number: Optional[int] = None   # Which step in a multi-step problem
    correction_given: bool = False
    session_id: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class LearningPreferences(BaseModel):
    preferred_style: Literal["direct", "socratic", "examples_first", "visual"] = "direct"
    cognitive_load: Literal["low", "medium", "high"] = "medium"
    attention_span_minutes: int = 25
    responds_well_to_analogies: bool = True
    needs_step_by_step: bool = False


class StudentProfile(BaseModel):
    """
    The central state of the learning system.
    Lightweight, JSON-serializable, persists between sessions.
    """
    student_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:12])
    name: str = "Student"
    current_topic: str = ""
    session_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    
    # Mastery per concept — the knowledge map
    concept_mastery: dict[str, ConceptMastery] = Field(default_factory=dict)
    
    # Mistake history (last 20 kept, older archived)
    recent_mistakes: list[RecentMistake] = Field(default_factory=list, max_length=20)
    
    # Overall learning profile
    preferences: LearningPreferences = Field(default_factory=LearningPreferences)
    
    # Session-level tracking
    questions_attempted: int = 0
    questions_correct: int = 0
    current_focus_score: float = 1.0  # Degrades with inactivity / wrong streaks
    learning_plateau_detected: bool = False
    
    # Understanding depth estimate
    understanding_mode: Literal["memorizing", "procedural", "conceptual"] = "procedural"


# ─────────────────────────────────────────────
# STEP EVALUATOR OUTPUT  (the key agent)
# ─────────────────────────────────────────────
class StepAnalysis(BaseModel):
    step_number: int
    step_text: str
    is_correct: bool
    mistake_type: Optional[MistakeType] = None
    explanation: str  # Why it's right/wrong — the reasoning trace
    confidence: float = Field(1.0, ge=0.0, le=1.0)  # Evaluator's confidence in its judgment


class StepEvaluatorOutput(BaseModel):
    problem_id: str
    student_steps: list[str]  # Raw steps from student
    step_analyses: list[StepAnalysis]
    first_incorrect_step: Optional[int] = None  # 1-indexed, None if all correct
    final_answer_correct: bool = False
    
    # Crucial distinction: pattern match vs real understanding
    shows_understanding: bool = False
    shows_memorization_risk: bool = False
    
    # Dominant mistake in this attempt
    primary_mistake_type: Optional[MistakeType] = None
    
    # Guidance for Tutor Agent
    targeted_intervention: str = ""  # Specific hint for next teaching action
    suggested_next_action: Literal["reteach", "hint", "socratic", "advance", "retest"] = "hint"


# ─────────────────────────────────────────────
# TUTOR AGENT OUTPUT
# ─────────────────────────────────────────────
class TutorOutput(BaseModel):
    explanation: str
    teaching_strategy: Literal["direct", "socratic", "worked_example", "analogy", "progressive_hint"]
    examples: list[str] = Field(default_factory=list, max_length=2)
    adapted_for: list[str] = Field(default_factory=list)  # e.g. ["visual learner", "overconfidence"]
    follow_up_prompt: Optional[str] = None  # Question to check comprehension


# ─────────────────────────────────────────────
# SOCRATIC AGENT OUTPUT
# ─────────────────────────────────────────────
QuestionType = Literal["probing", "transfer", "reverse", "counter_example", "explain_to_me"]

class SocraticQuestion(BaseModel):
    question_type: QuestionType
    question: str
    target_concept: str
    reveals_if_memorizing: bool = False  # True = this question breaks pattern-matchers
    expected_response_indicators: list[str] = Field(default_factory=list)


class SocraticOutput(BaseModel):
    questions: list[SocraticQuestion]
    primary_goal: Literal["verify_understanding", "expose_gap", "trigger_transfer", "check_calibration"]


# ─────────────────────────────────────────────
# EVALUATION AGENT OUTPUT
# ─────────────────────────────────────────────
class EvaluationOutput(BaseModel):
    understanding_score: float = Field(0.0, ge=0.0, le=1.0)
    confidence_score: float = Field(0.0, ge=0.0, le=1.0)
    retention_score: float = Field(0.0, ge=0.0, le=1.0)
    focus_score: float = Field(1.0, ge=0.0, le=1.0)
    
    is_plateau: bool = False
    plateau_reason: Optional[str] = None
    
    # Memorization vs understanding assessment
    understanding_depth: Literal["surface", "procedural", "deep"] = "surface"
    evidence_for_depth: list[str] = Field(default_factory=list)
    
    recommended_action: Literal["continue", "retest", "change_strategy", "take_break", "advance"] = "continue"


# ─────────────────────────────────────────────
# ORCHESTRATOR SESSION STATE
# ─────────────────────────────────────────────
class SessionState(BaseModel):
    """Working memory for the current session. Cleared between sessions."""
    session_id: str
    student_profile: StudentProfile
    current_problem: Optional[str] = None
    current_problem_id: Optional[str] = None
    last_step_eval: Optional[StepEvaluatorOutput] = None
    last_tutor_output: Optional[TutorOutput] = None
    last_socratic_output: Optional[SocraticOutput] = None
    last_eval: Optional[EvaluationOutput] = None
    
    # Loop tracking
    loop_count: int = 0
    consecutive_correct: int = 0
    consecutive_wrong: int = 0
    
    # Phase tracking
    current_phase: Literal["teach", "test", "evaluate", "diagnose", "adapt"] = "teach"
    
    # History for context
    conversation_history: list[dict] = Field(default_factory=list, max_length=30)
