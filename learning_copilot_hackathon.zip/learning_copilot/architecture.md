# Learning Copilot — Architecture Document
> Version: 1.0 MVP | Updated: Session 6

---

## Core Design Principle

**The Orchestrator is a deterministic Python state machine — not an LLM.**

All routing decisions are auditable Python. LLMs are called only to generate content (explanations, questions, problems) — never to decide what happens next.

---

## Agent Topology

```
Student Input
     │
     ▼
┌─────────────────────────────────────────────────┐
│             ORCHESTRATOR (state machine)         │
│  Phase: teach → test → evaluate → adapt → test  │
└──────────────────┬──────────────────────────────┘
                   │ delegates to
     ┌─────────────┼──────────────────┐
     │             │                  │
     ▼             ▼                  ▼
┌─────────┐  ┌──────────────┐  ┌───────────┐
│  Tutor  │  │ Step Evaluator│  │ Socratic  │
│  Agent  │  │    Agent      │  │   Agent   │
└─────────┘  └──────┬───────┘  └───────────┘
                    │
                    ▼
             ┌─────────────┐
             │  Evaluator  │  ← deterministic, no LLM
             │   Agent     │
             └──────┬──────┘
                    │ recommended_action
                    ▼
             ┌─────────────┐
             │ Orchestrator│  ← routing decision
             └─────────────┘
```

---

## Phase State Machine

```
teach ──→ test ──→ evaluate ──→ diagnose ──→ adapt ──→ test
  ↑                    │                              │
  └────── advance ─────┘                              │
          (mastery confirmed)                         │
                                                      │
  ← ─ ─ ─ ─ ─ ─ ─ change_strategy ─ ─ ─ ─ ─ ─ ─ ─ ┘
```

### _next_phase Priority Ladder (highest wins)

1. `EvaluationOutput.recommended_action` from Evaluator Agent
   - `take_break` → `adapt`
   - `change_strategy` → `adapt`
   - `advance` → `teach`
   - `retest`/`continue` → fall through
2. `consecutive_wrong >= 3` → `adapt`
3. `mastery > 0.7 && consecutive_correct >= 2` → `evaluate`
4. Current phase = `adapt` → `test`
5. Current phase = `evaluate` + shows_understanding → `teach`
6. Default flow table: `teach→test→evaluate→diagnose→adapt`

---

## Key Architectural Boundaries

### Deterministic vs. LLM

| Component | Deterministic | LLM-driven |
|-----------|--------------|------------|
| Phase routing | ✅ | |
| Teaching strategy selection | ✅ | |
| Mastery scoring (ELO) | ✅ | |
| Plateau detection | ✅ | |
| Retention calculation | ✅ | |
| Explanation generation | | ✅ |
| Step-by-step evaluation | | ✅ |
| Socratic question generation | | ✅ |
| Problem generation | | ✅ |

### Separation of concerns

- **routing logic** lives in `core/orchestrator.py` — never in agents
- **content generation** lives in `agents/` — never in orchestrator
- **data contracts** live in `models/schemas.py` — never duplicated

---

## Data Model

### StudentProfile (persists across sessions)
```
student_id, name, current_topic
concept_mastery: dict[str → ConceptMastery]
  └── mastery_score [0–1], confidence_score [0–1]
  └── calibration_error, misconception_tags
  └── last_tested, is_memorization_risk
recent_mistakes: list[RecentMistake] (rolling 20)
  └── mistake_type (5-type taxonomy)
preferences: LearningPreferences
understanding_mode: memorizing | procedural | conceptual
```

### SessionState (per-session working memory)
```
session_id, student_profile
current_phase: teach | test | evaluate | diagnose | adapt
loop_count, consecutive_correct, consecutive_wrong
last_step_eval: StepEvaluatorOutput
last_eval: EvaluationOutput
conversation_history: list[dict] (rolling 30)
```

### Five-Type Mistake Taxonomy
- `conceptual` — wrong mental model (−0.08 × mastery)
- `procedural` — right idea, wrong steps (−0.08 × mastery)
- `careless` — arithmetic slip (−0.02 fixed)
- `knowledge_gap` — missing prerequisite (−0.08 × mastery + Tool Agent)
- `confidence_mismatch` — calibration error (no mastery penalty)

---

## LLM Backend Abstraction

All agents call one interface:
```python
response = await llm_client.messages.create(
    model=MODEL_EVALUATOR,   # or MODEL_TUTOR
    max_tokens=...,
    system=...,
    messages=[...]
)
text = response.content[0].text
```

`build_llm_client()` returns either:
- `anthropic.AsyncAnthropic` (Anthropic backend)
- `_AzureClientWrapper(_AzureMessagesAdapter(...))` (Azure backend)

Both satisfy the same interface. Agents are backend-agnostic.

### Model Constants

| Constant | Default | Override Env Var |
|----------|---------|-----------------|
| `MODEL_EVALUATOR` | `claude-opus-4-5` | `MODEL_EVALUATOR` |
| `MODEL_TUTOR` | `claude-haiku-4-5-20251001` | `MODEL_TUTOR` |

---

## Storage Layer

| Backend | When | How to enable |
|---------|------|---------------|
| `InMemoryStorage` | Tests / CI | `STORAGE_BACKEND=memory` |
| `JSONFileStorage` | Local dev / MVP | `STORAGE_BACKEND=json` (default) |
| `CosmosDBStorage` | Production | `STORAGE_BACKEND=cosmos` |

All backends implement the same 6-method async interface.
CosmosDB stores `student_id` as a top-level field for O(1) parameterized queries.

---

## Spaced Repetition

Ebbinghaus model:
```
R = mastery × exp(-elapsed_hours / stability)
stability = 24 + mastery × 168  (1 day → 1 week)
```

Urgency levels: `critical` (R < 0.40) → `due` (R < 0.65) → `upcoming` → `ok`

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Health check (no API key required) |
| POST | `/session/start` | Create session, run first teaching turn |
| POST | `/session/{id}/respond` | Main learning loop entry point |
| GET | `/session/{id}/state` | Live knowledge map |
| GET | `/session/{id}/history` | Conversation + eval history |
| POST | `/session/{id}/set-topic` | Change topic mid-session |
| POST | `/session/{id}/generate-problem` | Assessment Agent: targeted problem |
| GET | `/session/{id}/knowledge-map` | Detailed calibration map |
| GET | `/session/{id}/schedule` | Spaced repetition schedule |
| POST | `/demo/full-loop` | One-shot hackathon demo |

---

## Infrastructure (Azure)

```
Azure Container Apps
  └── Container (FastAPI + all agents)
  └── Log Analytics (structured JSON logs)
  └── [Optional] Cosmos DB (production storage)
  └── [Optional] Azure AI Search (curriculum retrieval)
```

Deploy: `./azure/deploy-azure.sh` (single command after `az login`)
