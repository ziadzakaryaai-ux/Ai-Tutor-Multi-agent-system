"""
Extended Test Suite — agents, API smoke, logging, conftest fixtures
===================================================================
These tests extend test_system.py and use the shared conftest fixtures.
Run with: python -m pytest tests/ -v
"""
import asyncio
import json
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from models.schemas import (
    StudentProfile, ConceptMastery, SessionState,
    StepEvaluatorOutput, StepAnalysis, RecentMistake,
)
from agents.step_evaluator import update_student_model_from_eval
from agents.tutor import select_teaching_strategy, build_tutor_system_prompt
from agents.evaluator import evaluate_understanding
from agents.socratic import _determine_socratic_goal
from core.storage import InMemoryStorage
from core.logging import safe_parse_json, get_logger
from core.orchestrator import LearningOrchestrator


# ─────────────────────────────────────────────
# TESTS USING CONFTEST FIXTURES
# ─────────────────────────────────────────────
class TestConftestFixtures:
    """Verify that conftest fixtures themselves are correct."""

    def test_base_profile_has_algebra(self, base_profile):
        assert "algebra" in base_profile.concept_mastery
        assert base_profile.concept_mastery["algebra"].mastery_score == 0.4

    def test_high_mastery_profile(self, high_mastery_profile):
        assert high_mastery_profile.concept_mastery["algebra"].mastery_score == 0.85
        assert high_mastery_profile.understanding_mode == "conceptual"

    def test_memorizing_profile(self, memorizing_profile):
        assert memorizing_profile.understanding_mode == "memorizing"
        assert memorizing_profile.concept_mastery["algebra"].is_memorization_risk

    def test_correct_eval_fixture(self, correct_eval_with_understanding):
        assert correct_eval_with_understanding.final_answer_correct
        assert correct_eval_with_understanding.shows_understanding
        assert correct_eval_with_understanding.first_incorrect_step is None

    def test_conceptual_error_fixture(self, conceptual_error_eval):
        assert not conceptual_error_eval.final_answer_correct
        assert conceptual_error_eval.first_incorrect_step == 1
        assert conceptual_error_eval.primary_mistake_type == "conceptual"

    def test_careless_error_fixture(self, careless_error_eval):
        assert not careless_error_eval.final_answer_correct
        assert careless_error_eval.first_incorrect_step == 2
        assert careless_error_eval.primary_mistake_type == "careless"

    def test_memorization_risk_fixture(self, memorization_risk_eval):
        assert memorization_risk_eval.final_answer_correct
        assert memorization_risk_eval.shows_memorization_risk
        assert not memorization_risk_eval.shows_understanding

    def test_base_session(self, base_session, base_profile):
        assert base_session.session_id == "test_session_001"
        assert base_session.current_phase == "test"
        assert base_session.student_profile.name == base_profile.name


# ─────────────────────────────────────────────
# STUDENT MODEL — FIXTURE-BASED
# ─────────────────────────────────────────────
class TestStudentModelWithFixtures:

    def test_correct_understanding_raises_mastery(
        self, base_profile, correct_eval_with_understanding
    ):
        before = base_profile.concept_mastery["algebra"].mastery_score
        p2 = update_student_model_from_eval(base_profile, correct_eval_with_understanding, "algebra")
        assert p2.concept_mastery["algebra"].mastery_score > before

    def test_conceptual_error_lowers_mastery_significantly(
        self, base_profile, conceptual_error_eval
    ):
        before = base_profile.concept_mastery["algebra"].mastery_score
        p2 = update_student_model_from_eval(base_profile, conceptual_error_eval, "algebra")
        drop = before - p2.concept_mastery["algebra"].mastery_score
        assert drop > 0.02

    def test_careless_error_tiny_penalty(
        self, base_profile, careless_error_eval
    ):
        before = base_profile.concept_mastery["algebra"].mastery_score
        p2 = update_student_model_from_eval(base_profile, careless_error_eval, "algebra")
        drop = before - p2.concept_mastery["algebra"].mastery_score
        assert 0 < drop <= 0.03

    def test_memorization_flag_set_from_fixture(
        self, base_profile, memorization_risk_eval
    ):
        p2 = update_student_model_from_eval(base_profile, memorization_risk_eval, "algebra")
        assert p2.concept_mastery["algebra"].is_memorization_risk

    def test_careless_penalty_less_than_conceptual(
        self, careless_error_eval, conceptual_error_eval
    ):
        from models.schemas import ConceptMastery as CM
        p_careless = StudentProfile(name="C", current_topic="algebra")
        p_careless.concept_mastery["algebra"] = CM(
            concept_id="algebra", concept_name="Algebra", mastery_score=0.5
        )
        p_conceptual = StudentProfile(name="D", current_topic="algebra")
        p_conceptual.concept_mastery["algebra"] = CM(
            concept_id="algebra", concept_name="Algebra", mastery_score=0.5
        )

        p_c = update_student_model_from_eval(p_careless, careless_error_eval, "algebra")
        p_d = update_student_model_from_eval(p_conceptual, conceptual_error_eval, "algebra")

        careless_drop = 0.5 - p_c.concept_mastery["algebra"].mastery_score
        conceptual_drop = 0.5 - p_d.concept_mastery["algebra"].mastery_score
        assert careless_drop < conceptual_drop


# ─────────────────────────────────────────────
# TUTOR STRATEGY — FIXTURE-BASED
# ─────────────────────────────────────────────
class TestTutorWithFixtures:

    def test_high_mastery_correct_gives_socratic(
        self, high_mastery_profile, correct_eval_with_understanding
    ):
        strat = select_teaching_strategy(high_mastery_profile, correct_eval_with_understanding)
        assert strat == "socratic"

    def test_memorizing_profile_gives_socratic(
        self, memorizing_profile, memorization_risk_eval
    ):
        strat = select_teaching_strategy(memorizing_profile, memorization_risk_eval)
        assert strat == "socratic"

    def test_conceptual_error_gives_analogy_or_example(
        self, base_profile, conceptual_error_eval
    ):
        strat = select_teaching_strategy(base_profile, conceptual_error_eval)
        assert strat in ("analogy", "worked_example")

    def test_system_prompt_includes_strategy_name(self, base_profile):
        for strategy in ("direct", "socratic", "worked_example", "analogy", "progressive_hint"):
            prompt = build_tutor_system_prompt(strategy, base_profile)
            assert len(prompt) > 100
            assert "STRATEGY" in prompt.upper() or strategy.upper() in prompt.upper()

    def test_all_strategies_produce_non_empty_prompts(self, base_profile):
        for strategy in ("direct", "socratic", "worked_example", "analogy", "progressive_hint"):
            prompt = build_tutor_system_prompt(strategy, base_profile)
            assert prompt.strip()


# ─────────────────────────────────────────────
# EVALUATION AGENT — FIXTURE-BASED
# ─────────────────────────────────────────────
class TestEvaluationWithFixtures:

    def test_correct_understanding_high_score(
        self, base_session, correct_eval_with_understanding
    ):
        base_session.last_step_eval = correct_eval_with_understanding
        result = evaluate_understanding(base_session)
        assert result.understanding_score >= 0.4  # at least above base

    def test_conceptual_error_lower_score(
        self, base_session, conceptual_error_eval
    ):
        base_session.last_step_eval = conceptual_error_eval
        result_wrong = evaluate_understanding(base_session)

        base_session.last_step_eval = correct_eval_with_understanding = (
            StepEvaluatorOutput(
                problem_id="p", student_steps=[], step_analyses=[],
                final_answer_correct=True, shows_understanding=True,
                shows_memorization_risk=False,
                targeted_intervention="", suggested_next_action="advance",
            )
        )
        base_session.last_step_eval = correct_eval_with_understanding
        result_correct = evaluate_understanding(base_session)

        assert result_wrong.understanding_score <= result_correct.understanding_score

    def test_plateau_session_recommends_change_strategy(self, plateau_session):
        result = evaluate_understanding(plateau_session)
        assert result.recommended_action == "change_strategy"
        assert result.is_plateau

    def test_full_eval_returns_all_fields(self, base_session, correct_eval_with_understanding):
        base_session.last_step_eval = correct_eval_with_understanding
        result = evaluate_understanding(base_session)
        assert hasattr(result, "understanding_score")
        assert hasattr(result, "retention_score")
        assert hasattr(result, "focus_score")
        assert hasattr(result, "understanding_depth")
        assert hasattr(result, "recommended_action")


# ─────────────────────────────────────────────
# SOCRATIC GOAL SELECTION
# ─────────────────────────────────────────────
class TestSocraticGoalSelection:

    def test_memorization_risk_returns_expose_gap(
        self, base_profile, memorization_risk_eval
    ):
        goal = _determine_socratic_goal(base_profile, memorization_risk_eval)
        assert goal == "expose_gap"

    def test_memorizing_mode_returns_trigger_transfer(self, memorizing_profile):
        goal = _determine_socratic_goal(memorizing_profile, None)
        assert goal == "trigger_transfer"

    def test_overconfident_returns_check_calibration(self):
        p = StudentProfile(name="T", current_topic="algebra")
        p.concept_mastery["algebra"] = ConceptMastery(
            concept_id="algebra", concept_name="Algebra",
            mastery_score=0.4,
            confidence_score=0.9,  # overconfident
        )
        goal = _determine_socratic_goal(p, None)
        assert goal == "check_calibration"

    def test_high_mastery_returns_verify(self, high_mastery_profile):
        goal = _determine_socratic_goal(high_mastery_profile, None)
        assert goal == "verify_understanding"

    def test_default_returns_expose_gap(self):
        p = StudentProfile(name="T", current_topic="algebra")
        goal = _determine_socratic_goal(p, None)
        assert goal == "expose_gap"


# ─────────────────────────────────────────────
# LOGGING UTILITIES
# ─────────────────────────────────────────────
class TestLogging:

    def test_get_logger_returns_logger(self):
        lg = get_logger("test.module")
        assert lg is not None
        assert lg.name == "test.module"

    def test_same_name_returns_same_instance(self):
        lg1 = get_logger("test.same")
        lg2 = get_logger("test.same")
        assert lg1 is lg2

    def test_safe_parse_plain_json(self):
        data = safe_parse_json('{"key": "value", "num": 42}', "test")
        assert data["key"] == "value"
        assert data["num"] == 42

    def test_safe_parse_fenced_json(self):
        raw = '```json\n{"result": true}\n```'
        data = safe_parse_json(raw, "test")
        assert data["result"] is True

    def test_safe_parse_fenced_no_lang(self):
        raw = '```\n{"x": 1}\n```'
        data = safe_parse_json(raw, "test")
        assert data["x"] == 1

    def test_safe_parse_json_with_preamble(self):
        raw = 'Here is the result:\n\n{"answer": "yes"}'
        data = safe_parse_json(raw, "test")
        assert data["answer"] == "yes"

    def test_safe_parse_json_with_trailing_text(self):
        raw = '{"value": 99}\n\nNote: this is the computed value.'
        data = safe_parse_json(raw, "test")
        assert data["value"] == 99

    def test_safe_parse_raises_on_no_json(self):
        with pytest.raises(ValueError, match="No JSON"):
            safe_parse_json("This is just plain text with no JSON.", "test")

    def test_safe_parse_raises_on_invalid_json(self):
        with pytest.raises((ValueError, Exception)):
            safe_parse_json('{"key": value_without_quotes}', "test")

    def test_safe_parse_array(self):
        data = safe_parse_json('[1, 2, 3]', "test")
        assert data == [1, 2, 3]

    def test_safe_parse_nested(self):
        raw = '{"steps": [{"n": 1, "ok": true}, {"n": 2, "ok": false}]}'
        data = safe_parse_json(raw, "test")
        assert len(data["steps"]) == 2
        assert data["steps"][1]["ok"] is False


# ─────────────────────────────────────────────
# ORCHESTRATOR — MOCK LLM INTEGRATION
# ─────────────────────────────────────────────
class TestOrchestratorWithMockLLM:

    def test_teach_phase_returns_explanation(self, mock_llm, memory_storage, base_session):
        orch = LearningOrchestrator(mock_llm, memory_storage)
        base_session.current_phase = "teach"

        async def run():
            result = await orch.process_student_response(
                session=base_session,
                student_input="Teach me algebra",
            )
            assert "response" in result
            assert len(result["response"]) > 10

        asyncio.run(run())

    def test_test_phase_with_steps_returns_evaluation(
        self, mock_llm, memory_storage, base_session
    ):
        orch = LearningOrchestrator(mock_llm, memory_storage)
        base_session.current_phase = "test"

        async def run():
            result = await orch.process_student_response(
                session=base_session,
                student_input="x = 16",
                student_steps=["2x = 8", "x = 16"],
            )
            assert result.get("type") in (
                "evaluation", "request_steps", "teaching",
                "adaptation", "socratic_challenge", "memorization_intervention"
            )

        asyncio.run(run())

    def test_response_always_has_student_state(
        self, mock_llm, memory_storage, base_session
    ):
        orch = LearningOrchestrator(mock_llm, memory_storage)

        async def run():
            result = await orch.process_student_response(
                session=base_session,
                student_input="hello",
            )
            state = result.get("student_state", {})
            assert "mastery" in state
            assert "understanding_mode" in state
            assert "accuracy" in state

        asyncio.run(run())

    def test_wrong_streak_triggers_adapt_phase(
        self, mock_llm_factory, memory_storage
    ):
        """After 3 consecutive wrong answers the phase must be 'adapt'."""
        llm = mock_llm_factory()
        orch = LearningOrchestrator(llm, memory_storage)

        p = StudentProfile(name="T", current_topic="algebra")
        p.concept_mastery["algebra"] = ConceptMastery(
            concept_id="algebra", concept_name="Algebra", mastery_score=0.4
        )
        session = SessionState(
            session_id="streak_test",
            student_profile=p,
            current_phase="test",
            consecutive_wrong=2,
        )

        async def run():
            await orch.process_student_response(
                session=session,
                student_input="x=99",
                student_steps=["wrong step 1", "wrong step 2"],
            )
            # After processing the 3rd wrong answer the phase should flip to adapt
            assert session.current_phase == "adapt"

        asyncio.run(run())

    def test_history_grows_per_turn(self, mock_llm, memory_storage, base_session):
        orch = LearningOrchestrator(mock_llm, memory_storage)

        async def run():
            before = len(base_session.conversation_history)
            await orch.process_student_response(
                session=base_session,
                student_input="test input",
            )
            after = len(base_session.conversation_history)
            assert after > before

        asyncio.run(run())

    def test_loop_count_increments(self, mock_llm, memory_storage, base_session):
        orch = LearningOrchestrator(mock_llm, memory_storage)
        before = base_session.loop_count

        async def run():
            await orch.process_student_response(
                session=base_session,
                student_input="answer",
            )
            assert base_session.loop_count == before + 1

        asyncio.run(run())


# ─────────────────────────────────────────────
# STORAGE — EXTENDED
# ─────────────────────────────────────────────
class TestStorageExtended:

    def test_in_memory_save_overwrites(self, memory_storage, base_session):
        async def run():
            await memory_storage.save_session(base_session)
            base_session.loop_count = 99
            await memory_storage.save_session(base_session)
            loaded = await memory_storage.load_session(base_session.session_id)
            assert loaded.loop_count == 99

        asyncio.run(run())

    def test_in_memory_student_profile(self, memory_storage, base_profile):
        async def run():
            await memory_storage.save_student_profile(base_profile)
            loaded = await memory_storage.load_student_profile(base_profile.student_id)
            assert loaded is not None
            assert loaded.name == base_profile.name

        asyncio.run(run())

    def test_in_memory_list_sessions(self, memory_storage, base_session):
        async def run():
            await memory_storage.save_session(base_session)
            sessions = await memory_storage.list_sessions(base_session.student_profile.student_id)
            assert base_session.session_id in sessions

        asyncio.run(run())

    def test_json_storage_student_profile(self, tmp_path, base_profile):
        from core.storage import JSONFileStorage
        storage = JSONFileStorage(data_dir=str(tmp_path))

        async def run():
            await storage.save_student_profile(base_profile)
            storage._cache.clear()
            loaded = await storage.load_student_profile(base_profile.student_id)
            assert loaded is not None
            assert loaded.student_id == base_profile.student_id

        asyncio.run(run())


# ─────────────────────────────────────────────
# API IMPORT SMOKE TEST
# ─────────────────────────────────────────────
class TestAPIImports:
    """Verify the FastAPI app can be imported without errors."""

    def test_app_importable(self):
        import importlib
        try:
            mod = importlib.import_module("api.main")
            assert hasattr(mod, "app")
        except Exception as e:
            pytest.fail(f"api.main import failed: {e}")

    def test_app_has_required_routes(self):
        from api.main import app
        paths = {r.path for r in app.routes}
        assert "/health" in paths
        assert "/session/start" in paths
        assert "/session/{session_id}/respond" in paths
        assert "/session/{session_id}/state" in paths
        assert "/session/{session_id}/history" in paths
        assert "/session/{session_id}/set-topic" in paths
        assert "/session/{session_id}/generate-problem" in paths
        assert "/session/{session_id}/knowledge-map" in paths
        assert "/session/{session_id}/schedule" in paths
        assert "/demo/full-loop" in paths

    def test_health_endpoint_structure(self):
        """Test the health endpoint logic directly (no HTTP)."""
        import asyncio
        from api.main import health

        async def run():
            result = await health()
            assert result["status"] == "ok"
            assert "agents" in result
            assert "step_evaluator" in result["agents"]

        asyncio.run(run())
