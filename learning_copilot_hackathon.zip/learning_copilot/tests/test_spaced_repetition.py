"""
Tests for the spaced repetition scheduler.
"""
import sys
import math
from pathlib import Path
from datetime import datetime, timezone, timedelta

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from models.schemas import StudentProfile, ConceptMastery
from core.spaced_repetition import (
    compute_retention, get_review_schedule, select_next_concept,
    REVIEW_THRESHOLD, CRITICAL_THRESHOLD, ReviewItem,
)


def make_cm(mastery=0.5, hours_ago=0):
    last = datetime.now(timezone.utc) - timedelta(hours=hours_ago)
    return ConceptMastery(
        concept_id="test", concept_name="Test", mastery_score=mastery, last_tested=last
    )


class TestComputeRetention:
    def test_zero_elapsed_returns_mastery(self):
        cm = make_cm(mastery=0.8, hours_ago=0)
        r = compute_retention(cm)
        assert abs(r - 0.8) < 0.01

    def test_retention_decays_over_time(self):
        cm_fresh = make_cm(mastery=0.6, hours_ago=1)
        cm_old   = make_cm(mastery=0.6, hours_ago=200)
        assert compute_retention(cm_fresh) > compute_retention(cm_old)

    def test_higher_mastery_decays_slower(self):
        cm_low  = make_cm(mastery=0.2, hours_ago=48)
        cm_high = make_cm(mastery=0.9, hours_ago=48)
        r_low   = compute_retention(cm_low)
        r_high  = compute_retention(cm_high)
        # High mastery: higher initial retention AND slower decay
        assert r_high > r_low

    def test_retention_bounded_0_to_1(self):
        for mastery in [0.0, 0.5, 1.0]:
            for hours in [0, 10, 1000]:
                cm = make_cm(mastery=mastery, hours_ago=hours)
                r = compute_retention(cm)
                assert 0.0 <= r <= 1.0

    def test_no_last_tested_returns_half_mastery(self):
        cm = ConceptMastery(concept_id="x", concept_name="X", mastery_score=0.8)
        r = compute_retention(cm)
        assert abs(r - 0.4) < 0.01   # 0.8 * 0.5

    def test_naive_datetime_handled(self):
        cm = ConceptMastery(
            concept_id="x", concept_name="X", mastery_score=0.6,
            last_tested=datetime(2025, 1, 1, 12, 0, 0)   # naive
        )
        r = compute_retention(cm)
        assert 0.0 <= r <= 1.0


class TestReviewSchedule:
    def _profile_with(self, concepts: dict) -> StudentProfile:
        """concepts: {concept_id: (mastery, hours_ago)}"""
        p = StudentProfile(name="T", current_topic=list(concepts)[0])
        for cid, (mastery, hours_ago) in concepts.items():
            p.concept_mastery[cid] = ConceptMastery(
                concept_id=cid, concept_name=cid.title(),
                mastery_score=mastery,
                last_tested=datetime.now(timezone.utc) - timedelta(hours=hours_ago),
            )
        return p

    def test_critical_concept_comes_first(self):
        p = self._profile_with({
            "forgotten": (0.5, 5000),   # very old → critical
            "fresh":     (0.5, 1),
        })
        schedule = get_review_schedule(p)
        assert schedule[0].concept_id == "forgotten"
        assert schedule[0].urgency == "critical"

    def test_fresh_concept_is_ok(self):
        p = self._profile_with({"algebra": (0.8, 0)})
        schedule = get_review_schedule(p)
        assert schedule[0].urgency == "ok"

    def test_urgency_levels_populated(self):
        p = self._profile_with({
            "old":  (0.5, 5000),
            "mid":  (0.5, 60),
            "new":  (0.8, 1),
        })
        schedule = get_review_schedule(p)
        urgencies = {r.concept_id: r.urgency for r in schedule}
        assert urgencies["old"]  in ("critical", "due")
        assert urgencies["new"]  in ("upcoming", "ok")

    def test_returns_review_item_type(self):
        p = self._profile_with({"x": (0.5, 10)})
        items = get_review_schedule(p)
        assert all(isinstance(i, ReviewItem) for i in items)

    def test_empty_profile_returns_empty(self):
        p = StudentProfile(name="T", current_topic="x")
        assert get_review_schedule(p) == []


class TestSelectNextConcept:
    def test_selects_critical_over_low_mastery(self):
        p = StudentProfile(name="T", current_topic="algebra")
        p.concept_mastery["algebra"] = ConceptMastery(
            concept_id="algebra", concept_name="Algebra", mastery_score=0.1,
            last_tested=datetime.now(timezone.utc),
        )
        p.concept_mastery["geometry"] = ConceptMastery(
            concept_id="geometry", concept_name="Geometry", mastery_score=0.8,
            last_tested=datetime.now(timezone.utc) - timedelta(hours=5000),
        )
        next_c = select_next_concept(p)
        assert next_c == "geometry"   # forgotten, not just low mastery

    def test_selects_lowest_mastery_when_all_fresh(self):
        p = StudentProfile(name="T", current_topic="algebra")
        p.concept_mastery["algebra"]  = ConceptMastery(concept_id="algebra",  concept_name="A", mastery_score=0.6, last_tested=datetime.now(timezone.utc))
        p.concept_mastery["geometry"] = ConceptMastery(concept_id="geometry", concept_name="G", mastery_score=0.2, last_tested=datetime.now(timezone.utc))
        next_c = select_next_concept(p)
        assert next_c == "geometry"

    def test_returns_current_topic_when_no_concepts(self):
        p = StudentProfile(name="T", current_topic="calculus")
        assert select_next_concept(p) == "calculus"
