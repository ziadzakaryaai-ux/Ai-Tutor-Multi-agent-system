"""
Tests — Azure Integration Layer
================================
Tests for:
  1. LLM client factory (Azure vs Anthropic selection)
  2. Azure adapter shape compatibility
  3. Tool Agent graceful degradation (no Azure Search configured)
  4. Storage factory selection
  5. CosmosDB storage interface contract (without real Cosmos)
"""
import asyncio
import os
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))


# ─────────────────────────────────────────────
# LLM CLIENT FACTORY
# ─────────────────────────────────────────────
class TestLLMClientFactory:
    """Tests that the factory returns the correct backend based on env vars."""

    def test_no_env_raises_value_error(self, monkeypatch):
        monkeypatch.delenv("AZURE_OPENAI_ENDPOINT", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY",     raising=False)
        from core.llm_client import build_llm_client
        with pytest.raises(ValueError, match="No LLM backend"):
            build_llm_client()

    def test_anthropic_key_returns_anthropic_client(self, monkeypatch):
        monkeypatch.delenv("AZURE_OPENAI_ENDPOINT", raising=False)
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        with patch.dict("sys.modules", {"anthropic": MagicMock()}):
            from importlib import reload
            import core.llm_client as mod
            reload(mod)
            client = mod.build_llm_client()
            # Anthropic client returned directly (has .messages attribute natively)
            assert client is not None

    def test_azure_endpoint_returns_wrapper(self, monkeypatch):
        monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://test.openai.azure.com/")
        monkeypatch.setenv("AZURE_OPENAI_API_KEY",  "fake-azure-key")
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

        mock_azure_class = MagicMock()
        mock_azure_instance = MagicMock()
        mock_azure_class.return_value = mock_azure_instance

        with patch.dict("sys.modules", {"openai": MagicMock(AsyncAzureOpenAI=mock_azure_class)}):
            from importlib import reload
            import core.llm_client as mod
            reload(mod)
            client = mod.build_llm_client()
            # Should return _AzureClientWrapper
            assert hasattr(client, "messages")
            assert hasattr(client.messages, "create")

    def test_azure_without_key_raises(self, monkeypatch):
        monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://test.openai.azure.com/")
        monkeypatch.delenv("AZURE_OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY",    raising=False)

        with patch.dict("sys.modules", {"openai": MagicMock()}):
            from importlib import reload
            import core.llm_client as mod
            reload(mod)
            with pytest.raises(ValueError, match="AZURE_OPENAI_API_KEY is missing"):
                mod.build_llm_client()

    def test_azure_without_openai_package_raises(self, monkeypatch):
        monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://test.openai.azure.com/")
        monkeypatch.setenv("AZURE_OPENAI_API_KEY",  "fake-key")

        import builtins
        real_import = builtins.__import__
        def mock_import(name, *args, **kwargs):
            if name == "openai":
                raise ImportError("No module named 'openai'")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=mock_import):
            from importlib import reload
            import core.llm_client as mod
            reload(mod)
            with pytest.raises(ImportError, match="openai"):
                mod.build_llm_client()


# ─────────────────────────────────────────────
# AZURE ADAPTER INTERFACE SHAPE
# ─────────────────────────────────────────────
class TestAzureAdapterShape:
    """
    Verify the Azure adapter output matches the Anthropic response shape
    that all agents expect: response.content[0].text
    """

    def test_response_has_content_list(self):
        from core.llm_client import _AnthropicShapedResponse
        r = _AnthropicShapedResponse("hello world")
        assert hasattr(r, "content")
        assert isinstance(r.content, list)
        assert len(r.content) == 1

    def test_content_block_has_text(self):
        from core.llm_client import _AnthropicShapedResponse, _ContentBlock
        r = _AnthropicShapedResponse("hello world")
        assert hasattr(r.content[0], "text")
        assert r.content[0].text == "hello world"

    def test_adapter_translate_system_to_messages(self):
        """System kwarg must become a system message prepended to messages list."""
        from core.llm_client import _AzureMessagesAdapter

        captured_calls = []

        async def fake_create(**kwargs):
            captured_calls.append(kwargs)
            resp = MagicMock()
            resp.choices = [MagicMock(message=MagicMock(content="answer"))]
            return resp

        mock_client = MagicMock()
        mock_client.chat.completions.create = fake_create
        adapter = _AzureMessagesAdapter(mock_client)

        async def run():
            await adapter.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=100,
                system="You are a tutor.",
                messages=[{"role": "user", "content": "explain x"}],
            )

        asyncio.run(run())
        assert len(captured_calls) == 1
        msgs = captured_calls[0]["messages"]
        assert msgs[0]["role"] == "system"
        assert msgs[0]["content"] == "You are a tutor."
        assert msgs[1]["role"] == "user"

    def test_adapter_model_aliasing(self):
        """claude-opus-4-5 must be mapped to gpt-4o deployment."""
        from core.llm_client import _AzureMessagesAdapter

        captured = []

        async def fake_create(**kwargs):
            captured.append(kwargs.get("model"))
            resp = MagicMock()
            resp.choices = [MagicMock(message=MagicMock(content="ok"))]
            return resp

        mock_client = MagicMock()
        mock_client.chat.completions.create = fake_create
        adapter = _AzureMessagesAdapter(mock_client)

        async def run():
            await adapter.create(
                model="claude-opus-4-5",
                max_tokens=100,
                messages=[{"role": "user", "content": "q"}],
            )

        asyncio.run(run())
        # Should use the evaluator deployment (gpt-4o by default)
        assert captured[0] in ("gpt-4o", os.getenv("AZURE_DEPLOYMENT_EVALUATOR", "gpt-4o"))

    def test_adapter_without_system(self):
        """No system kwarg — messages passed through unchanged."""
        from core.llm_client import _AzureMessagesAdapter

        captured = []

        async def fake_create(**kwargs):
            captured.append(kwargs["messages"])
            resp = MagicMock()
            resp.choices = [MagicMock(message=MagicMock(content="ok"))]
            return resp

        mock_client = MagicMock()
        mock_client.chat.completions.create = fake_create
        adapter = _AzureMessagesAdapter(mock_client)

        async def run():
            await adapter.create(
                model="claude-haiku-4-5-20251001",
                max_tokens=100,
                messages=[{"role": "user", "content": "hello"}],
            )

        asyncio.run(run())
        assert len(captured[0]) == 1
        assert captured[0][0]["role"] == "user"


# ─────────────────────────────────────────────
# TOOL AGENT — GRACEFUL DEGRADATION
# ─────────────────────────────────────────────
class TestToolAgentDegradation:
    """
    With no Azure Search configured, the Tool Agent must return
    used_retrieval=False and empty grounding — no errors, no disruption.
    """

    def test_no_config_returns_no_retrieval(self, monkeypatch):
        monkeypatch.delenv("AZURE_SEARCH_ENDPOINT", raising=False)
        monkeypatch.delenv("AZURE_SEARCH_KEY",      raising=False)

        from importlib import reload
        import agents.tool_agent as mod
        reload(mod)

        async def run():
            return await mod.search_curriculum("algebra", "explain linear equations", top_k=3)

        results = asyncio.run(run())
        assert results == []

    def test_run_tool_agent_no_search_returns_no_retrieval(self, monkeypatch):
        monkeypatch.delenv("AZURE_SEARCH_ENDPOINT", raising=False)
        monkeypatch.delenv("AZURE_SEARCH_KEY",      raising=False)

        from importlib import reload
        import agents.tool_agent as mod
        reload(mod)

        async def run():
            return await mod.run_tool_agent(
                concept="algebra",
                mistake_type="knowledge_gap",
                student_question="what is a variable?",
                llm_client=MagicMock(),
            )

        result = asyncio.run(run())
        assert result["used_retrieval"] is False
        assert result["grounding_context"] == ""
        assert result["sources"] == []

    def test_non_knowledge_gap_skips_retrieval(self):
        from importlib import reload
        import agents.tool_agent as mod
        reload(mod)

        async def run():
            return await mod.run_tool_agent(
                concept="algebra",
                mistake_type="careless",   # Not a knowledge gap
                student_question=None,
                llm_client=MagicMock(),
            )

        result = asyncio.run(run())
        assert result["used_retrieval"] is False

    def test_search_result_grounding_text(self):
        from agents.tool_agent import SearchResult
        r = SearchResult(title="Algebra Basics", content="A variable is a symbol.", score=0.9)
        text = r.to_grounding_text()
        assert "Algebra Basics" in text
        assert "variable is a symbol" in text

    def test_search_http_error_returns_empty(self, monkeypatch):
        """Network errors must degrade gracefully, not crash the system."""
        monkeypatch.setenv("AZURE_SEARCH_ENDPOINT", "https://fake.search.windows.net")
        monkeypatch.setenv("AZURE_SEARCH_KEY", "fake-key")

        from importlib import reload
        import agents.tool_agent as mod
        reload(mod)

        async def fail(*args, **kwargs):
            raise ConnectionError("network error")

        with patch("httpx.AsyncClient") as mock_client_class:
            mock_instance = AsyncMock()
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__  = AsyncMock(return_value=False)
            mock_instance.post       = AsyncMock(side_effect=ConnectionError("network error"))
            mock_client_class.return_value = mock_instance

            async def run():
                return await mod.search_curriculum("algebra", "test", top_k=3)

            results = asyncio.run(run())
            assert results == []


# ─────────────────────────────────────────────
# STORAGE FACTORY
# ─────────────────────────────────────────────
class TestStorageFactory:

    def test_default_returns_json_storage(self, monkeypatch, tmp_path):
        monkeypatch.delenv("STORAGE_BACKEND", raising=False)
        monkeypatch.setenv("DATA_DIR", str(tmp_path))
        from importlib import reload
        import core.storage as mod
        reload(mod)
        storage = mod.build_storage()
        assert isinstance(storage, mod.JSONFileStorage)

    def test_json_explicit_returns_json_storage(self, monkeypatch, tmp_path):
        monkeypatch.setenv("STORAGE_BACKEND", "json")
        monkeypatch.setenv("DATA_DIR", str(tmp_path))
        from importlib import reload
        import core.storage as mod
        reload(mod)
        storage = mod.build_storage()
        assert isinstance(storage, mod.JSONFileStorage)

    def test_memory_returns_in_memory_storage(self, monkeypatch):
        monkeypatch.setenv("STORAGE_BACKEND", "memory")
        from importlib import reload
        import core.storage as mod
        reload(mod)
        storage = mod.build_storage()
        assert isinstance(storage, mod.InMemoryStorage)

    def test_cosmos_without_package_raises_import_error(self, monkeypatch):
        monkeypatch.setenv("STORAGE_BACKEND", "cosmos")
        monkeypatch.setenv("COSMOS_ENDPOINT", "https://fake.documents.azure.com:443/")
        monkeypatch.setenv("COSMOS_KEY",      "fake-key")

        import builtins
        real_import = builtins.__import__
        def mock_import(name, *args, **kwargs):
            if "azure.cosmos" in name:
                raise ImportError("No module named 'azure.cosmos'")
            return real_import(name, *args, **kwargs)

        from importlib import reload
        import core.storage as mod
        reload(mod)

        with patch("builtins.__import__", side_effect=mock_import):
            with pytest.raises(ImportError, match="azure-cosmos"):
                mod.CosmosDBStorage()

    def test_cosmos_storage_has_correct_interface(self, monkeypatch):
        """CosmosDBStorage must expose the same 5-method interface."""
        monkeypatch.setenv("COSMOS_ENDPOINT", "https://fake.documents.azure.com:443/")
        monkeypatch.setenv("COSMOS_KEY",      "fake-key")

        mock_cosmos = MagicMock()
        mock_cosmos.aio = MagicMock()
        mock_cosmos.aio.CosmosClient = MagicMock()
        mock_pk = MagicMock()

        with patch.dict("sys.modules", {
            "azure":             MagicMock(),
            "azure.cosmos":      mock_cosmos,
            "azure.cosmos.aio":  mock_cosmos.aio,
        }):
            from importlib import reload
            import core.storage as mod
            reload(mod)
            storage = mod.CosmosDBStorage()
            for method in ("save_session", "load_session",
                           "save_student_profile", "load_student_profile",
                           "list_sessions", "archive_session"):
                assert hasattr(storage, method), f"Missing method: {method}"
                assert callable(getattr(storage, method))
