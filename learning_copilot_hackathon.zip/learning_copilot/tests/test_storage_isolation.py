"""
test_storage_isolation.py
=========================
Regression tests for BUG: list_sessions ignored the student_id parameter
and returned ALL sessions instead of only those belonging to the caller.

Covers all three writable backends:
  • InMemoryStorage
  • JSONFileStorage
  • CosmosDBStorage (mocked — no real Cosmos needed)

Run with:
  python -m pytest tests/test_storage_isolation.py -v
"""
import asyncio
import json
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from models.schemas import (
    SessionState, StudentProfile, ConceptMastery, LearningPreferences,
)
from core.storage import InMemoryStorage, JSONFileStorage


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────
def _make_session(session_id: str, student_id: str, student_name: str) -> SessionState:
    """Minimal but valid SessionState owned by the given student_id."""
    profile = StudentProfile(
        student_id=student_id,
        name=student_name,
        current_topic="algebra",
        session_id=session_id,
    )
    return SessionState(
        session_id=session_id,
        student_profile=profile,
    )


# ─────────────────────────────────────────────
# IN-MEMORY STORAGE
# ─────────────────────────────────────────────
class TestInMemoryStorageIsolation:
    """list_sessions must filter by student_id, not return everything."""

    def _run(self, coro):
        return asyncio.run(coro)

    def test_returns_only_own_sessions(self):
        storage = InMemoryStorage()
        alice_session  = _make_session("sess-a1", "alice-001", "Alice")
        alice_session2 = _make_session("sess-a2", "alice-001", "Alice")
        bob_session    = _make_session("sess-b1", "bob-002",   "Bob")

        async def run():
            await storage.save_session(alice_session)
            await storage.save_session(alice_session2)
            await storage.save_session(bob_session)

            alice_ids = await storage.list_sessions("alice-001")
            bob_ids   = await storage.list_sessions("bob-002")

            # Alice sees exactly her two sessions, nothing from Bob
            assert set(alice_ids) == {"sess-a1", "sess-a2"}
            # Bob sees only his session, nothing from Alice
            assert bob_ids == ["sess-b1"]

        self._run(run())

    def test_unknown_student_returns_empty(self):
        storage = InMemoryStorage()
        session = _make_session("sess-x1", "alice-001", "Alice")

        async def run():
            await storage.save_session(session)
            result = await storage.list_sessions("nobody-999")
            assert result == []

        self._run(run())

    def test_empty_store_returns_empty(self):
        storage = InMemoryStorage()

        async def run():
            result = await storage.list_sessions("alice-001")
            assert result == []

        self._run(run())

    def test_does_not_leak_between_students(self):
        """Regression guard: adding a third student must not affect others."""
        storage = InMemoryStorage()
        sessions = [
            _make_session(f"sess-{i}", f"student-{i:03d}", f"Student {i}")
            for i in range(5)
        ]

        async def run():
            for s in sessions:
                await storage.save_session(s)

            for i in range(5):
                ids = await storage.list_sessions(f"student-{i:03d}")
                assert ids == [f"sess-{i}"], (
                    f"student-{i:03d} expected ['sess-{i}'], got {ids}"
                )

        self._run(run())


# ─────────────────────────────────────────────
# JSON FILE STORAGE
# ─────────────────────────────────────────────
class TestJSONFileStorageIsolation:
    """list_sessions must filter by student_id in both cache and disk paths."""

    def _run(self, coro):
        return asyncio.run(coro)

    def test_returns_only_own_sessions(self, tmp_path):
        storage = JSONFileStorage(data_dir=str(tmp_path))
        alice_session  = _make_session("sess-a1", "alice-001", "Alice")
        alice_session2 = _make_session("sess-a2", "alice-001", "Alice")
        bob_session    = _make_session("sess-b1", "bob-002",   "Bob")

        async def run():
            await storage.save_session(alice_session)
            await storage.save_session(alice_session2)
            await storage.save_session(bob_session)

            alice_ids = await storage.list_sessions("alice-001")
            bob_ids   = await storage.list_sessions("bob-002")

            assert set(alice_ids) == {"sess-a1", "sess-a2"}
            assert bob_ids == ["sess-b1"]

        self._run(run())

    def test_disk_path_works_after_cache_cleared(self, tmp_path):
        """Regression: the disk-read path (no cache) must also filter."""
        storage = JSONFileStorage(data_dir=str(tmp_path))
        alice_session = _make_session("sess-a1", "alice-001", "Alice")
        bob_session   = _make_session("sess-b1", "bob-002",   "Bob")

        async def run():
            await storage.save_session(alice_session)
            await storage.save_session(bob_session)

            # Clear in-process cache to force the slow (disk-read) path
            storage._cache.clear()

            alice_ids = await storage.list_sessions("alice-001")
            bob_ids   = await storage.list_sessions("bob-002")

            assert alice_ids == ["sess-a1"]
            assert bob_ids   == ["sess-b1"]

        self._run(run())

    def test_mixed_cache_and_disk(self, tmp_path):
        """One session hot in cache, another only on disk — both must filter."""
        storage = JSONFileStorage(data_dir=str(tmp_path))
        alice_cached = _make_session("sess-cached", "alice-001", "Alice")
        alice_disk   = _make_session("sess-disk",   "alice-001", "Alice")
        bob_session  = _make_session("sess-b1",     "bob-002",   "Bob")

        async def run():
            await storage.save_session(alice_cached)
            await storage.save_session(alice_disk)
            await storage.save_session(bob_session)

            # Evict alice_disk and bob from cache; keep alice_cached warm
            storage._cache.pop("sess-disk", None)
            storage._cache.pop("sess-b1",   None)

            alice_ids = await storage.list_sessions("alice-001")
            assert set(alice_ids) == {"sess-cached", "sess-disk"}, (
                f"Expected both alice sessions, got {alice_ids}"
            )

        self._run(run())

    def test_unknown_student_returns_empty(self, tmp_path):
        storage = JSONFileStorage(data_dir=str(tmp_path))
        session = _make_session("sess-a1", "alice-001", "Alice")

        async def run():
            await storage.save_session(session)
            storage._cache.clear()
            result = await storage.list_sessions("nobody-999")
            assert result == []

        self._run(run())

    def test_corrupt_json_file_is_skipped(self, tmp_path):
        """A corrupt session file must not crash list_sessions."""
        storage = JSONFileStorage(data_dir=str(tmp_path))
        good_session = _make_session("sess-good", "alice-001", "Alice")

        async def run():
            await storage.save_session(good_session)
            # Write a corrupt file that cannot be parsed
            corrupt = tmp_path / "session_corrupt-id.json"
            corrupt.write_text("{this is not valid json{{")

            result = await storage.list_sessions("alice-001")
            assert result == ["sess-good"]   # Corrupt file silently skipped

        self._run(run())

    def test_json_file_missing_student_profile_key_is_skipped(self, tmp_path):
        """A JSON file without student_profile must be skipped silently."""
        storage = JSONFileStorage(data_dir=str(tmp_path))
        good_session = _make_session("sess-good", "alice-001", "Alice")

        async def run():
            await storage.save_session(good_session)
            # Write a syntactically valid but structurally wrong file
            bad = tmp_path / "session_bad-id.json"
            bad.write_text(json.dumps({"id": "bad-id", "no_student_profile": True}))

            result = await storage.list_sessions("alice-001")
            # bad-id has no student_profile → empty string → filtered out
            assert "bad-id" not in result
            assert "sess-good" in result

        self._run(run())

    def test_does_not_include_archived_sessions(self, tmp_path):
        """Archived sessions move to a sub-directory; list_sessions must not see them."""
        storage = JSONFileStorage(data_dir=str(tmp_path))
        session = _make_session("sess-a1", "alice-001", "Alice")

        async def run():
            await storage.save_session(session)
            await storage.archive_session("sess-a1")

            result = await storage.list_sessions("alice-001")
            assert result == []

        self._run(run())


# ─────────────────────────────────────────────
# COSMOS DB STORAGE (fully mocked)
# ─────────────────────────────────────────────
class TestCosmosDBStorageIsolation:
    """
    Verify the Cosmos save_session doc shape and list_sessions query.
    Uses a mock Cosmos container — no real Cosmos required.
    """

    def _make_cosmos_storage(self, monkeypatch):
        """Construct a CosmosDBStorage with all Azure imports mocked out."""
        monkeypatch.setenv("COSMOS_ENDPOINT", "https://fake.documents.azure.com:443/")
        monkeypatch.setenv("COSMOS_KEY", "fake-key")

        mock_cosmos = MagicMock()
        mock_cosmos.aio = MagicMock()
        mock_cosmos.aio.CosmosClient = MagicMock()

        with patch.dict("sys.modules", {
            "azure":             MagicMock(),
            "azure.cosmos":      mock_cosmos,
            "azure.cosmos.aio":  mock_cosmos.aio,
        }):
            from importlib import reload
            import core.storage as mod
            reload(mod)
            storage = mod.CosmosDBStorage()
            return storage, mod

    def test_save_session_includes_student_id_top_level(self, monkeypatch):
        """The Cosmos document written by save_session must carry student_id at the top level."""
        storage, _ = self._make_cosmos_storage(monkeypatch)

        upserted_docs = []

        async def fake_upsert(doc):
            upserted_docs.append(doc)

        mock_container = AsyncMock()
        mock_container.upsert_item = fake_upsert
        storage._container = mock_container

        session = _make_session("sess-a1", "alice-001", "Alice")

        asyncio.run(storage.save_session(session))

        assert len(upserted_docs) == 1
        doc = upserted_docs[0]
        assert "student_id" in doc, "student_id must be a top-level field in the Cosmos doc"
        assert doc["student_id"] == "alice-001"
        assert doc["id"] == "sess-a1"
        assert doc["type"] == "session"

    def test_list_sessions_query_includes_student_id_param(self, monkeypatch):
        """list_sessions must pass a parameterised student_id filter to Cosmos."""
        storage, _ = self._make_cosmos_storage(monkeypatch)

        captured_queries = []

        # AsyncGenerator that yields one item
        async def fake_query_items(query, parameters=None):
            captured_queries.append({"query": query, "parameters": parameters})
            items = [{"id": "sess-a1"}]
            for item in items:
                yield item

        mock_container = AsyncMock()
        mock_container.query_items = fake_query_items
        storage._container = mock_container

        async def run():
            result = await storage.list_sessions("alice-001")
            assert result == ["sess-a1"]

        asyncio.run(run())

        assert len(captured_queries) == 1
        q = captured_queries[0]

        # Query must filter on student_id, not just type
        assert "student_id" in q["query"], (
            f"Cosmos query must filter on student_id; got: {q['query']!r}"
        )
        assert "@student_id" in q["query"]
        # Parameter must be bound to the requested student
        param_values = {p["name"]: p["value"] for p in (q["parameters"] or [])}
        assert param_values.get("@student_id") == "alice-001"

    def test_list_sessions_returns_only_matching_ids(self, monkeypatch):
        """Verify that only the IDs returned by Cosmos end up in the result."""
        storage, _ = self._make_cosmos_storage(monkeypatch)

        async def fake_query_items(query, parameters=None):
            for item in [{"id": "sess-a1"}, {"id": "sess-a2"}]:
                yield item

        mock_container = AsyncMock()
        mock_container.query_items = fake_query_items
        storage._container = mock_container

        async def run():
            return await storage.list_sessions("alice-001")

        result = asyncio.run(run())
        assert set(result) == {"sess-a1", "sess-a2"}

    def test_cosmos_has_correct_interface(self, monkeypatch):
        """CosmosDBStorage must still expose all required interface methods."""
        storage, _ = self._make_cosmos_storage(monkeypatch)
        for method in (
            "save_session", "load_session",
            "save_student_profile", "load_student_profile",
            "list_sessions", "archive_session",
        ):
            assert hasattr(storage, method) and callable(getattr(storage, method)), (
                f"Missing required method: {method}"
            )
