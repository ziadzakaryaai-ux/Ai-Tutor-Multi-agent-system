"""
conftest.py — shared pytest fixtures for the full test suite.
Import these in any test file with standard pytest fixture injection.
"""
import sys
import json
import asyncio
from pathlib import Path
from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from models.schemas import (
    StudentProfile, ConceptMastery, LearningPreferences,
    StepEvaluatorOutput, StepAnalysis, SessionState,
)
from core.storage import InMemoryStorage


# ── event loop (required for async tests) ─────────────────
@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


# ── base student profile ───────────────────────────────────
@pytest.fixture
def base_profile():
    p = StudentProfile(name="TestStudent", current_topic="algebra")
    p.concept_mastery["algebra"] = ConceptMastery(
        concept_id="algebra",
        concept_name="Algebra",
        mastery_score=0.4,
        confidence_score=0.6,
        last_tested=datetime.now(timezone.utc),
    )
    return p


@pytest.fixture
def high_mastery_profile():
    p = StudentProfile(name="Advanced", current_topic="algebra")
    p.concept_mastery["algebra"] = ConceptMastery(
        concept_id="algebra",
        concept_name="Algebra",
        mastery_score=0.85,
        confidence_score=0.8,
        last_tested=datetime.now(timezone.utc),
    )
    p.understanding_mode = "conceptual"
    return p


@pytest.fixture
def memorizing_profile():
    p = StudentProfile(name="Memorizer", current_topic="algebra")
    p.concept_mastery["algebra"] = ConceptMastery(
        concept_id="algebra",
        concept_name="Algebra",
        mastery_score=0.6,
        confidence_score=0.9,
        is_memorization_risk=True,
    )
    p.understanding_mode = "memorizing"
    return p


# ── step evaluator outputs ─────────────────────────────────
@pytest.fixture
def correct_eval_with_understanding():
    return StepEvaluatorOutput(
        problem_id="p001",
        student_steps=["2x+5-5=13-5", "2x=8", "x=4"],
        step_analyses=[
            StepAnalysis(step_number=1, step_text="2x+5-5=13-5", is_correct=True,
                         explanation="Correctly subtracted 5 from both sides", confidence=0.99),
            StepAnalysis(step_number=2, step_text="2x=8", is_correct=True,
                         explanation="Simplified correctly", confidence=0.99),
            StepAnalysis(step_number=3, step_text="x=4", is_correct=True,
                         explanation="Divided correctly by coefficient", confidence=0.99),
        ],
        first_incorrect_step=None,
        final_answer_correct=True,
        shows_understanding=True,
        shows_memorization_risk=False,
        primary_mistake_type=None,
        targeted_intervention="Excellent — reasoning is sound throughout.",
        suggested_next_action="advance",
    )


@pytest.fixture
def conceptual_error_eval():
    return StepEvaluatorOutput(
        problem_id="p002",
        student_steps=["divide both sides by 2: x+5=6.5", "subtract 5: x=1.5"],
        step_analyses=[
            StepAnalysis(step_number=1, step_text="divide both sides by 2: x+5=6.5",
                         is_correct=False, mistake_type="conceptual",
                         explanation="Should isolate the constant first before dividing by coefficient",
                         confidence=0.97),
            StepAnalysis(step_number=2, step_text="subtract 5: x=1.5",
                         is_correct=False, mistake_type="procedural",
                         explanation="Step follows logically from wrong step 1, but answer is wrong",
                         confidence=0.95),
        ],
        first_incorrect_step=1,
        final_answer_correct=False,
        shows_understanding=False,
        shows_memorization_risk=False,
        primary_mistake_type="conceptual",
        targeted_intervention="Move the constant to the other side first, then divide by the coefficient.",
        suggested_next_action="reteach",
    )


@pytest.fixture
def careless_error_eval():
    return StepEvaluatorOutput(
        problem_id="p003",
        student_steps=["2x+5-5=13-5", "2x=7", "x=3.5"],
        step_analyses=[
            StepAnalysis(step_number=1, step_text="2x+5-5=13-5", is_correct=True,
                         explanation="Correct approach", confidence=0.99),
            StepAnalysis(step_number=2, step_text="2x=7", is_correct=False,
                         mistake_type="careless",
                         explanation="Arithmetic slip: 13-5=8 not 7", confidence=0.99),
            StepAnalysis(step_number=3, step_text="x=3.5", is_correct=False,
                         mistake_type="careless",
                         explanation="Follows from wrong step 2", confidence=0.97),
        ],
        first_incorrect_step=2,
        final_answer_correct=False,
        shows_understanding=True,
        shows_memorization_risk=False,
        primary_mistake_type="careless",
        targeted_intervention="Your approach is correct — check the arithmetic at step 2: 13-5=8.",
        suggested_next_action="hint",
    )


@pytest.fixture
def memorization_risk_eval():
    return StepEvaluatorOutput(
        problem_id="p004",
        student_steps=["move 5", "divide by 2", "x=4"],
        step_analyses=[
            StepAnalysis(step_number=1, step_text="move 5", is_correct=True,
                         explanation="Correct but no justification given", confidence=0.8),
            StepAnalysis(step_number=2, step_text="divide by 2", is_correct=True,
                         explanation="Correct step, still no reasoning", confidence=0.8),
            StepAnalysis(step_number=3, step_text="x=4", is_correct=True,
                         explanation="Correct answer", confidence=0.99),
        ],
        first_incorrect_step=None,
        final_answer_correct=True,
        shows_understanding=False,
        shows_memorization_risk=True,
        primary_mistake_type=None,
        targeted_intervention="Answer is correct but student cannot explain why each step works.",
        suggested_next_action="socratic",
    )


# ── session fixtures ───────────────────────────────────────
@pytest.fixture
def base_session(base_profile):
    return SessionState(
        session_id="test_session_001",
        student_profile=base_profile,
        current_phase="test",
        current_problem="Solve for x: 2x + 5 = 13",
    )


@pytest.fixture
def plateau_session(base_profile):
    s = SessionState(
        session_id="plateau_session",
        student_profile=base_profile,
        current_phase="test",
        consecutive_wrong=4,
    )
    s.student_profile.learning_plateau_detected = True
    return s


# ── storage ───────────────────────────────────────────────
@pytest.fixture
def memory_storage():
    return InMemoryStorage()


# ── mock LLM builder ──────────────────────────────────────
CANNED_STEP_EVAL = json.dumps({
    "step_analyses": [
        {"step_number": 1, "step_text": "2x=8", "is_correct": True,
         "mistake_type": None, "explanation": "Correct", "confidence": 0.99},
        {"step_number": 2, "step_text": "x=16", "is_correct": False,
         "mistake_type": "procedural",
         "explanation": "Multiplied instead of dividing by 2", "confidence": 0.97},
    ],
    "first_incorrect_step": 2,
    "final_answer_correct": False,
    "shows_understanding": False,
    "shows_memorization_risk": False,
    "primary_mistake_type": "procedural",
    "targeted_intervention": "Divide both sides by 2: x = 8/2 = 4",
    "suggested_next_action": "hint",
})

CANNED_TUTOR = (
    "Let me show you a worked example.\n\n"
    "For 2x = 8, divide both sides by 2:\n"
    "2x / 2 = 8 / 2\n"
    "x = 4\n\n"
    "Does this approach make sense?"
)

CANNED_SOCRATIC = json.dumps({
    "questions": [{
        "question_type": "transfer",
        "question": "If 3y = 12, what operation would isolate y, and why?",
        "target_concept": "linear_equations",
        "reveals_if_memorizing": True,
        "expected_response_indicators": ["divide", "inverse", "coefficient"],
    }],
    "primary_goal": "verify_understanding",
})

CANNED_ASSESSMENT = json.dumps({
    "problem": "Solve for z: 4z - 3 = 13",
    "target_concept": "linear_equations",
    "target_weakness": "procedural: order of inverse operations",
    "difficulty": 0.55,
    "expected_steps": ["Add 3 to both sides: 4z = 16", "Divide by 4: z = 4"],
    "common_wrong_step": "Dividing by 4 before adding 3",
    "why_this_problem": "Tests whether student understands why constant must be moved first",
})


def make_mock_llm(responses=None):
    """
    Build a mock Anthropic async client.
    Cycles through the provided response list (or sensible canned defaults).
    """
    defaults = [CANNED_STEP_EVAL, CANNED_TUTOR, CANNED_SOCRATIC, CANNED_ASSESSMENT]
    pool = responses if responses is not None else defaults
    state = {"i": 0}

    async def mock_create(**kwargs):
        text = pool[state["i"] % len(pool)]
        state["i"] += 1
        msg = MagicMock()
        msg.content = [MagicMock(text=text)]
        return msg

    client = MagicMock()
    client.messages.create = mock_create
    return client


@pytest.fixture
def mock_llm():
    return make_mock_llm()


@pytest.fixture
def mock_llm_factory():
    """Returns the factory so individual tests can customise responses."""
    return make_mock_llm
