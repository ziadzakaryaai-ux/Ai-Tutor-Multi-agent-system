"""
Evaluation Agent
================
Synthesizes signals from Step Evaluator, Socratic responses, and Student Model
to produce a holistic understanding assessment.

Key insight: understanding is NOT binary. We measure:
- Surface (can recall / recognize)
- Procedural (can execute the steps)
- Deep (can explain, transfer, invert, and generalize)

The Evaluation Agent runs after each teaching cycle and produces
a recommendation for the Orchestrator's routing decision.
"""
from models.schemas import (
    EvaluationOutput, StudentProfile, StepEvaluatorOutput,
    SocraticOutput, SessionState
)
from datetime import datetime, timezone


def evaluate_understanding(
    session: SessionState,
    socratic_response: str | None = None,
) -> EvaluationOutput:
    """
    Deterministic evaluation engine.
    
    Unlike the other agents, this does NOT call the LLM.
    It synthesizes signals from the already-computed outputs.
    
    Design rationale: evaluation logic must be auditable and consistent.
    If the LLM evaluates, you lose reproducibility and explainability.
    """
    profile = session.student_profile
    eval_out = session.last_step_eval
    cm = profile.concept_mastery.get(profile.current_topic)

    mastery = cm.mastery_score if cm else 0.0
    confidence = cm.confidence_score if cm else 0.5
    
    # ── Understanding score ───────────────────
    understanding_score = _compute_understanding_score(
        profile, eval_out, socratic_response
    )
    
    # ── Retention score (decay model) ────────
    retention_score = _compute_retention_score(cm)
    
    # ── Focus score ───────────────────────────
    focus_score = _compute_focus_score(session)
    
    # ── Understanding depth ───────────────────
    depth, evidence = _classify_depth(profile, eval_out, socratic_response, understanding_score)
    
    # ── Plateau detection ─────────────────────
    is_plateau, plateau_reason = _detect_plateau(session)
    
    # ── Recommended action ────────────────────
    action = _recommend_action(
        understanding_score, focus_score, is_plateau, session
    )
    
    return EvaluationOutput(
        understanding_score=round(understanding_score, 2),
        confidence_score=round(confidence, 2),
        retention_score=round(retention_score, 2),
        focus_score=round(focus_score, 2),
        is_plateau=is_plateau,
        plateau_reason=plateau_reason,
        understanding_depth=depth,
        evidence_for_depth=evidence,
        recommended_action=action,
    )


def _compute_understanding_score(
    profile: StudentProfile,
    eval_out: StepEvaluatorOutput | None,
    socratic_response: str | None,
) -> float:
    cm = profile.concept_mastery.get(profile.current_topic)
    base = cm.mastery_score if cm else 0.3

    # Step evaluation signals
    if eval_out:
        if eval_out.final_answer_correct and eval_out.shows_understanding:
            base = min(1.0, base + 0.1)
        elif eval_out.final_answer_correct and not eval_out.shows_understanding:
            base = min(1.0, base + 0.02)  # Tiny gain — might be luck
        elif not eval_out.final_answer_correct:
            # Penalty scaled by mistake type
            penalties = {
                "conceptual": 0.15,
                "procedural": 0.08,
                "careless": 0.02,
                "knowledge_gap": 0.12,
                "confidence_mismatch": 0.05,
            }
            base = max(0.0, base - penalties.get(eval_out.primary_mistake_type or "", 0.05))

        if eval_out.shows_memorization_risk:
            base *= 0.85  # Discount: surface pattern, not understanding

    # Socratic response quality (simple heuristic — no LLM call needed here)
    if socratic_response:
        words = socratic_response.lower().split()
        depth_indicators = {"because", "therefore", "since", "means", "implies",
                           "when", "if", "unless", "always", "never", "except"}
        depth_count = sum(1 for w in words if w in depth_indicators)
        if len(words) > 30 and depth_count >= 2:
            base = min(1.0, base + 0.05)

    return base


def _compute_retention_score(cm) -> float:
    """Simple time-decay model (Ebbinghaus-inspired)."""
    if cm is None or cm.last_tested is None:
        return 0.5  # Unknown
    
    hours_since = (datetime.now(timezone.utc) - cm.last_tested).total_seconds() / 3600
    
    # Retention: R = mastery * e^(-hours/stability)
    # Stability scales with mastery (stronger knowledge decays slower)
    import math
    stability = 24 + cm.mastery_score * 168  # 1 day to 1 week stability
    retention = cm.mastery_score * math.exp(-hours_since / stability)
    return round(max(0.0, min(1.0, retention)), 2)


def _compute_focus_score(session: SessionState) -> float:
    """
    Focus degrades when:
    - Many wrong answers in a row (frustration)
    - Session is very long (fatigue)
    - Plateau is detected (disengagement)
    """
    score = 1.0
    
    if session.consecutive_wrong >= 2:
        score -= 0.1 * (session.consecutive_wrong - 1)
    
    if session.loop_count > 20:
        score -= 0.01 * (session.loop_count - 20)
    
    if session.student_profile.learning_plateau_detected:
        score -= 0.15
    
    return round(max(0.2, min(1.0, score)), 2)


def _classify_depth(
    profile: StudentProfile,
    eval_out: StepEvaluatorOutput | None,
    socratic_response: str | None,
    understanding_score: float,
) -> tuple[str, list[str]]:
    evidence = []
    
    if understanding_score >= 0.75:
        if eval_out and eval_out.shows_understanding:
            evidence.append("Step evaluator confirmed reasoning quality")
        if socratic_response and len(socratic_response.split()) > 40:
            evidence.append("Student gave detailed Socratic response")
        if profile.understanding_mode == "conceptual":
            evidence.append("Understanding mode = conceptual")
        depth = "deep" if len(evidence) >= 2 else "procedural"
    elif understanding_score >= 0.45:
        evidence.append("Can execute procedure but reasoning not verified")
        if eval_out and eval_out.shows_memorization_risk:
            evidence.append("Memorization pattern detected")
        depth = "procedural"
    else:
        evidence.append("Multiple errors or conceptual gaps detected")
        depth = "surface"
    
    return depth, evidence


def _detect_plateau(session: SessionState) -> tuple[bool, str | None]:
    """
    Plateau signals:
    - Same mistake type 3+ times in a row
    - No mastery improvement in last 5 attempts
    - High wrong streak
    """
    if session.consecutive_wrong >= 3:
        return True, f"{session.consecutive_wrong} consecutive wrong answers"
    
    recent = session.student_profile.recent_mistakes[-5:]
    if len(recent) >= 4:
        types = [m.mistake_type for m in recent]
        if len(set(types)) == 1:
            return True, f"Same mistake type ({types[0]}) repeated {len(types)} times"
    
    return False, None


def _recommend_action(
    understanding_score: float,
    focus_score: float,
    is_plateau: bool,
    session: SessionState,
) -> str:
    if focus_score < 0.4:
        return "take_break"
    
    if is_plateau:
        return "change_strategy"
    
    if understanding_score > 0.8 and session.consecutive_correct >= 3:
        return "advance"
    
    if understanding_score > 0.6:
        return "retest"  # Verify with fresh problem
    
    return "continue"
