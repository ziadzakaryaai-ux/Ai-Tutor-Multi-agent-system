"""
Assessment Agent
================
Generates personalized problems targeting the student's specific weaknesses.

Key principle: problems are NOT randomly generated.
Each problem is designed to:
1. Target the highest-priority weakness in the knowledge map
2. Use a difficulty calibrated to the current mastery score
3. Be novel enough to defeat pattern-matching (no template problems)
4. Include a transfer component when mastery > 0.6

MVP: generates one targeted problem at a time.
Production: generates full adaptive assessments with spaced repetition scheduling.
"""
import json
from models.schemas import StudentProfile, ConceptMastery
from core.logging import safe_parse_json, log_agent_call, get_logger
from core.llm_client import MODEL_TUTOR

logger = get_logger(__name__)


ASSESSMENT_SYSTEM = """You are an expert at creating targeted educational problems.

You receive a student's weakness profile and must create ONE problem that:
1. Directly targets the specified misconception or gap
2. Is calibrated to the given difficulty level (0=trivial, 1=expert)
3. CANNOT be solved by memorizing a template — requires real understanding
4. For difficulty > 0.6: includes a transfer element (slightly different context)

DIFFICULTY CALIBRATION:
- 0.0–0.3: Direct application, standard form, single step
- 0.3–0.6: Multi-step, requires connecting two ideas
- 0.6–0.8: Non-standard form, requires adaptation
- 0.8–1.0: Novel context, transfer required, or inverse problem

ANTI-PATTERNS (never do these):
- Don't use the exact same surface form as the textbook
- Don't make problems that reward formula lookup
- Don't make problems solvable by plugging in and checking

Respond ONLY in this JSON format:
{
  "problem": "The full problem statement",
  "target_concept": "What concept this tests",
  "target_weakness": "Which specific weakness this addresses",
  "difficulty": 0.5,
  "expected_steps": ["Step 1...", "Step 2...", "Step 3..."],
  "common_wrong_step": "The step where students with this misconception typically fail",
  "why_this_problem": "One sentence: why this problem reveals understanding vs memorization"
}
"""


async def generate_targeted_problem(
    profile: StudentProfile,
    llm_client,
    force_transfer: bool = False,
) -> dict:
    """
    Generate one targeted problem for the student.
    
    Selection logic:
    1. Find the concept with lowest mastery that has been recently attempted
    2. Use its misconception tags to focus the problem
    3. Calibrate difficulty to mastery + 0.1 (zone of proximal development)
    """
    target_concept, cm = _select_target_concept(profile)
    
    if cm is None:
        cm_mastery = 0.3
        misconceptions = []
    else:
        cm_mastery = cm.mastery_score
        misconceptions = cm.misconception_tags

    # Zone of proximal development: slightly above current mastery
    difficulty = min(0.95, cm_mastery + 0.15)
    if force_transfer:
        difficulty = max(0.6, difficulty)

    user_prompt = f"""
STUDENT PROFILE:
- Target concept: {target_concept}
- Current mastery: {cm_mastery:.0%}
- Known misconceptions: {', '.join(misconceptions) if misconceptions else 'none yet'}
- Understanding mode: {profile.understanding_mode}
- Recent mistake pattern: {_recent_mistake_summary(profile, target_concept)}

PROBLEM REQUIREMENTS:
- Target difficulty: {difficulty:.1f}
- Must target weakness: {misconceptions[0] if misconceptions else 'general understanding'}
- Transfer required: {'YES' if force_transfer or difficulty > 0.6 else 'NO'}
- Student is currently in {profile.understanding_mode.upper()} mode

Generate one targeted problem now.
"""

    response = await llm_client.messages.create(
        model=MODEL_TUTOR,
        max_tokens=600,
        system=ASSESSMENT_SYSTEM,
        messages=[{"role": "user", "content": user_prompt}]
    )

    raw = response.content[0].text.strip()
    return safe_parse_json(raw, context="assessment.generate_targeted_problem")


def _select_target_concept(profile: StudentProfile) -> tuple[str, ConceptMastery | None]:
    """
    Priority: recently attempted + lowest mastery + has misconceptions.
    """
    if not profile.concept_mastery:
        return profile.current_topic, None

    # Score each concept: lower mastery = higher priority
    # Bonus for having known misconceptions (more targeted)
    def priority(item):
        concept_id, cm = item
        base = 1.0 - cm.mastery_score
        misconception_bonus = 0.2 if cm.misconception_tags else 0.0
        return base + misconception_bonus

    sorted_concepts = sorted(profile.concept_mastery.items(), key=priority, reverse=True)
    concept_id, cm = sorted_concepts[0]
    return concept_id, cm


def _recent_mistake_summary(profile: StudentProfile, concept_id: str) -> str:
    relevant = [m for m in profile.recent_mistakes if m.concept_id == concept_id]
    if not relevant:
        return "no recent mistakes for this concept"
    recent = relevant[-3:]
    types = [m.mistake_type for m in recent]
    dominant = max(set(types), key=types.count)
    return f"mostly '{dominant}' mistakes ({len(recent)} recent attempts)"


async def generate_transfer_problem(
    profile: StudentProfile,
    source_concept: str,
    target_domain: str,
    llm_client,
) -> dict:
    """
    Generate a problem that applies the concept in a completely different domain.
    This is the ultimate test of deep understanding vs. memorization.
    
    E.g.: If student learned linear equations through algebra,
    test the same reasoning in a physics or finance context.
    """
    cm = profile.concept_mastery.get(source_concept)
    mastery = cm.mastery_score if cm else 0.5

    prompt = f"""Create a transfer problem that tests {source_concept} 
in the domain of {target_domain}.

The problem should require the SAME underlying reasoning as {source_concept},
but be superficially different enough that pattern-matching won't work.

Student mastery of {source_concept}: {mastery:.0%}
Student understanding mode: {profile.understanding_mode}

If the student truly understands {source_concept}, they will solve this.
If they memorized the procedure, they won't recognize it.

Respond in the same JSON format as standard problems."""

    response = await llm_client.messages.create(
        model=MODEL_TUTOR,
        max_tokens=500,
        system=ASSESSMENT_SYSTEM,
        messages=[{"role": "user", "content": prompt}]
    )

    raw = response.content[0].text.strip()
    result = safe_parse_json(raw, context="assessment.generate_transfer_problem")
    result["is_transfer_problem"] = True
    result["source_concept"] = source_concept
    result["target_domain"] = target_domain
    return result
