"""
Socratic Agent
==============
Purpose: Verify understanding, expose memorization, trigger transfer thinking.

This agent asks questions. It does NOT explain. It does NOT help.
Its output is always a question, and the question is always designed to
reveal whether the student understands the CONCEPT or just the PATTERN.

The Socratic agent is deployed when:
1. The student gets the right answer (we verify it's not luck)
2. Memorization risk is detected (we force novel application)
3. Mastery score is high (we confirm conceptual depth before advancing)
"""
import json
from models.schemas import (
    SocraticOutput, SocraticQuestion, StudentProfile,
    StepEvaluatorOutput
)
from core.logging import safe_parse_json, log_agent_call, get_logger
from core.llm_client import MODEL_TUTOR

logger = get_logger(__name__)


SOCRATIC_SYSTEM = """You are a Socratic tutor. Your SOLE purpose is to ask questions that reveal
whether a student truly understands a concept, or merely recognizes its surface pattern.

QUESTION TYPES you can use:
- probing: "Why does this step work here but not in this case...?"
- transfer: Apply the concept to a completely different domain or scenario
- reverse: "If the answer was X, what could the problem have been?"
- counter_example: "Can you construct a case where this rule breaks down?"
- explain_to_me: "Explain this concept to me as if I'd never seen it before"

ANTI-PATTERNS — never do these:
- Never give hints in your question
- Never ask yes/no questions
- Never ask questions answerable by reciting a formula
- Never repeat the same question type twice in a row
- Never ask what the student already proved they know

MEMORIZATION DETECTION: The single best technique is "surface feature change."
Change the numbers, change the domain, change the direction of the question.
If a student memorized "distribute and simplify", ask them to:
- Go backwards from answer to problem
- Apply to a word problem
- Find the flaw in a WRONG worked example

Respond ONLY in this JSON:
{
  "questions": [
    {
      "question_type": "probing",
      "question": "...",
      "target_concept": "...",
      "reveals_if_memorizing": true,
      "expected_response_indicators": ["should mention...", "should NOT just..."]
    }
  ],
  "primary_goal": "verify_understanding"
}

Generate 1-2 questions, not more. Quality over quantity.
"""


@log_agent_call("socratic", model=MODEL_TUTOR)
async def run_socratic_agent(
    concept: str,
    profile: StudentProfile,
    eval_output: StepEvaluatorOutput | None,
    conversation_history: list[dict],
    llm_client,
) -> SocraticOutput:
    """
    Generates Socratic questions tailored to the student's current state.
    
    Key design: the question strategy (which type to use) is guided
    by what we already know about the student's weaknesses.
    """
    # Determine what kind of challenge is needed
    goal = _determine_socratic_goal(profile, eval_output)
    
    # What questions have we already asked? (avoid repetition)
    recent_questions = [
        msg["content"] for msg in conversation_history[-6:]
        if msg.get("role") == "assistant" and "?" in msg.get("content", "")
    ]
    
    cm = profile.concept_mastery.get(concept) or profile.concept_mastery.get(profile.current_topic)
    mastery = cm.mastery_score if cm else 0.4
    misconceptions = cm.misconception_tags if cm else []
    
    user_prompt = f"""
CONCEPT BEING TESTED: {concept}
STUDENT MASTERY SCORE: {mastery:.0%}
STUDENT UNDERSTANDING MODE: {profile.understanding_mode}
KNOWN MISCONCEPTIONS: {', '.join(misconceptions) if misconceptions else 'none'}
GOAL: {goal}

{"MEMORIZATION RISK DETECTED: The student may be pattern-matching. Design a question that breaks the surface pattern." if eval_output and eval_output.shows_memorization_risk else ""}

{"RECENT MISTAKES: " + str([m.description[:50] for m in profile.recent_mistakes[-3:]]) if profile.recent_mistakes else ""}

Previously asked questions (don't repeat these themes):
{chr(10).join(f"- {q[:80]}" for q in recent_questions[-3:]) if recent_questions else "None yet"}

Generate {1 if mastery < 0.5 else 2} Socratic question(s) for this student.
"""

    response = await llm_client.messages.create(
        model=MODEL_TUTOR,
        max_tokens=600,
        system=SOCRATIC_SYSTEM,
        messages=[{"role": "user", "content": user_prompt}]
    )
    
    raw = response.content[0].text.strip()
    data = safe_parse_json(raw, context="socratic")
    
    questions = [
        SocraticQuestion(
            question_type=q["question_type"],
            question=q["question"],
            target_concept=q["target_concept"],
            reveals_if_memorizing=q.get("reveals_if_memorizing", False),
            expected_response_indicators=q.get("expected_response_indicators", [])
        )
        for q in data["questions"]
    ]
    
    return SocraticOutput(
        questions=questions,
        primary_goal=data["primary_goal"]
    )


def _determine_socratic_goal(
    profile: StudentProfile,
    eval_output: StepEvaluatorOutput | None
) -> str:
    """Deterministic goal selection based on student state."""
    
    if eval_output and eval_output.shows_memorization_risk:
        return "expose_gap"
    
    if profile.understanding_mode == "memorizing":
        return "trigger_transfer"
    
    cm = profile.concept_mastery.get(profile.current_topic)
    if cm:
        # High confidence, lower mastery = overconfidence
        if cm.confidence_score > cm.mastery_score + 0.2:
            return "check_calibration"
        
        # Good mastery, verify it's real
        if cm.mastery_score > 0.7:
            return "verify_understanding"
    
    return "expose_gap"  # Default: look for what they don't know
