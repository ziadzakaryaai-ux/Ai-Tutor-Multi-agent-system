"""
Tutor Agent
===========
Explains concepts, generates examples/analogies, and adapts its
teaching approach to the student's current state.

Design principle (matches the Orchestrator):
  STRATEGY SELECTION is deterministic, not LLM-driven.
  `select_teaching_strategy()` is a pure function of the student profile
  and the most recent Step Evaluator output. The LLM is only used to
  GENERATE the explanation/content for the chosen strategy — never to
  pick the strategy itself. This keeps adaptation auditable and testable.

Teaching strategies:
  - direct:           Plain explanation. Default for new/neutral concepts.
  - socratic:         Guided questions instead of answers. Used when mastery
                       is high (verify depth) or memorization risk detected.
  - worked_example:   Step-by-step worked solution. Used for procedural errors.
  - analogy:          Concept mapped to a familiar domain. Used for
                       conceptual misunderstandings (wrong mental model).
  - progressive_hint: Escalating hints rather than a full explanation. Used
                       for careless mistakes or low cognitive load students.
"""
from models.schemas import TutorOutput, StudentProfile, StepEvaluatorOutput
from core.logging import safe_parse_json, log_agent_call, get_logger
from core.llm_client import MODEL_TUTOR

logger = get_logger(__name__)


TUTOR_SYSTEM_TEMPLATES = {
    "direct": """You are a clear, direct tutor. Your STRATEGY is DIRECT EXPLANATION.

Explain the concept plainly and efficiently:
- State the core idea in one or two sentences first.
- Follow with the key rule or definition.
- Give at most one short example.
- Avoid tangents. Avoid over-explaining.

This strategy is used when the student has no major misconceptions yet —
they simply need a clear first exposure to the idea.
""",

    "socratic": """You are a Socratic tutor. Your STRATEGY is SOCRATIC GUIDANCE.

Do NOT give the answer or a full explanation outright.
- Ask a guiding question that leads the student toward the idea themselves.
- If you must explain, explain only enough to set up the question.
- Your output should feel like an invitation to think, not a lecture.

This strategy is used when mastery is already high (verifying real
understanding) or when memorization/pattern-matching is suspected
(forcing the student to reason rather than recall).
""",

    "worked_example": """You are a methodical tutor. Your STRATEGY is WORKED EXAMPLE.

Walk through a complete worked example step by step:
- Show every step explicitly, in order.
- Briefly state WHY each step is taken (not just what to do).
- Use a problem similar in structure to what the student is working on,
  but not identical (avoid simple copy-paste pattern matching).
- End by inviting the student to apply the same steps to their problem.

This strategy is used when the student has the right concept but executed
the PROCEDURE incorrectly — they need to see correct execution modeled.
""",

    "analogy": """You are an intuitive tutor. Your STRATEGY is ANALOGY.

Reframe the concept using a vivid, accurate analogy from everyday life:
- Choose an analogy whose underlying structure genuinely matches the concept
  (not just superficially similar).
- Map each part of the analogy explicitly to the corresponding part of the
  concept.
- Follow with one sentence connecting the analogy back to the original
  problem.

This strategy is used when the student shows a CONCEPTUAL misunderstanding —
their mental model of how the concept works is wrong, not just their
execution of it. A new mental model, not more practice, is what's needed.
""",

    "progressive_hint": """You are a patient tutor. Your STRATEGY is PROGRESSIVE HINTING.

Do not explain the full concept or solve the problem.
- Give ONE small hint that nudges the student toward the next correct step.
- Keep it short — a sentence or two.
- Leave the actual work to the student.
- If the student previously made a careless error, point at the *type* of
  thing to double check (e.g. "double-check your arithmetic on the right
  side") without naming the specific mistake.

This strategy is used for careless mistakes or when cognitive load should
stay low — the student is close; they need a nudge, not a re-teach.
""",
}


@log_agent_call("tutor", model=MODEL_TUTOR)
async def run_tutor_agent(
    concept: str,
    student_steps: list[str] | None,
    eval_output: StepEvaluatorOutput | None,
    profile: StudentProfile,
    llm_client,
) -> TutorOutput:
    """
    Generate tutoring content for the given concept.

    Strategy is selected deterministically via `select_teaching_strategy`,
    then the LLM generates the actual explanation/content for that strategy.
    """
    strategy = select_teaching_strategy(profile, eval_output)
    system_prompt = build_tutor_system_prompt(strategy, profile)

    cm = profile.concept_mastery.get(concept) or profile.concept_mastery.get(profile.current_topic)
    mastery = cm.mastery_score if cm else 0.0
    misconceptions = cm.misconception_tags if cm else []

    adapted_for: list[str] = []
    eval_context = "none yet — this is the first explanation of this concept"
    if eval_output:
        eval_context = (
            f"Final answer correct: {eval_output.final_answer_correct}. "
            f"Shows understanding: {eval_output.shows_understanding}. "
            f"Primary mistake type: {eval_output.primary_mistake_type or 'none'}. "
            f"Targeted intervention: {eval_output.targeted_intervention}"
        )
        if eval_output.primary_mistake_type:
            adapted_for.append(eval_output.primary_mistake_type)
        if eval_output.shows_memorization_risk:
            adapted_for.append("memorization risk")

    if profile.preferences.responds_well_to_analogies:
        adapted_for.append("analogies preferred")
    if profile.preferences.needs_step_by_step:
        adapted_for.append("step-by-step preferred")

    steps_block = ""
    if student_steps:
        steps_block = "\n\nSTUDENT'S STEPS:\n" + "\n".join(
            f"Step {i + 1}: {s}" for i, s in enumerate(student_steps)
        )

    user_prompt = f"""
CONCEPT: {concept}
STUDENT MASTERY: {mastery:.0%}
STUDENT UNDERSTANDING MODE: {profile.understanding_mode}
KNOWN MISCONCEPTIONS: {', '.join(misconceptions) if misconceptions else 'none'}
PREFERRED STYLE: {profile.preferences.preferred_style}
COGNITIVE LOAD CAPACITY: {profile.preferences.cognitive_load}

LAST EVALUATION: {eval_context}
{steps_block}

Generate tutoring content for this student now.

Respond ONLY in this JSON format, no preamble:
{{
  "explanation": "<the explanation/question/hint text, following your strategy>",
  "examples": ["<optional example 1>", "<optional example 2>"],
  "follow_up_prompt": "<a short question to check comprehension, or null>"
}}
Use at most 2 examples. Omit examples entirely (empty list) for socratic
and progressive_hint strategies, where giving examples would defeat the
purpose.
"""

    response = await llm_client.messages.create(
        model=MODEL_TUTOR,
        max_tokens=800,
        system=system_prompt,
        messages=[{"role": "user", "content": user_prompt}],
    )

    raw = response.content[0].text.strip()
    data = safe_parse_json(raw, context="tutor")

    # Defensive: the LLM (or in tests, a canned mock response cycling
    # through unrelated agent payloads) may not always return the
    # expected "explanation" key. A missing explanation should never
    # crash the learning loop — fall back to raw text.
    explanation = data.get("explanation")
    if not explanation:
        explanation = raw

    examples = data.get("examples", [])
    if not isinstance(examples, list):
        examples = []

    return TutorOutput(
        explanation=explanation,
        teaching_strategy=strategy,
        examples=examples[:2],
        adapted_for=adapted_for,
        follow_up_prompt=data.get("follow_up_prompt"),
    )


def select_teaching_strategy(
    profile: StudentProfile,
    eval_output: StepEvaluatorOutput | None,
) -> str:
    """
    Deterministic strategy selection — the "pedagogical brain" that the
    Orchestrator delegates to, but which itself contains NO LLM calls.

    Priority order (first match wins):
      1. High mastery + correct + shows understanding  -> socratic
         (verify depth before advancing)
      2. Memorization risk detected (mode or this eval) -> socratic
         (force transfer/explanation to break pattern-matching)
      3. Conceptual mistake                             -> analogy
         (wrong mental model needs reframing, not more drilling)
      4. Procedural mistake                             -> worked_example
         (right idea, wrong execution -> model correct execution)
      5. Careless mistake                               -> progressive_hint
         (approach is fine, nudge toward self-correction)
      6. Knowledge gap                                  -> worked_example
         (fill the prerequisite gap with a concrete model)
      7. Confidence mismatch                            -> socratic
         (probe to recalibrate confidence vs mastery)
      8. Default (no eval yet, or all-correct without depth signal) -> direct
    """
    cm = profile.concept_mastery.get(profile.current_topic)
    mastery = cm.mastery_score if cm else 0.0

    # 1. High mastery + correct + understanding -> verify depth
    if (
        eval_output
        and eval_output.final_answer_correct
        and eval_output.shows_understanding
        and mastery > 0.7
    ):
        return "socratic"

    # 2. Memorization risk -> break the pattern
    if profile.understanding_mode == "memorizing":
        return "socratic"
    if eval_output and eval_output.shows_memorization_risk:
        return "socratic"

    # 3-7. Mistake-type-driven adaptation
    if eval_output and not eval_output.final_answer_correct:
        mistake_strategy = {
            "conceptual": "analogy",
            "procedural": "worked_example",
            "careless": "progressive_hint",
            "knowledge_gap": "worked_example",
            "confidence_mismatch": "socratic",
        }
        strategy = mistake_strategy.get(eval_output.primary_mistake_type)
        if strategy:
            return strategy

    # 8. Default — first exposure or clean correct answer without
    #    a depth signal yet.
    return "direct"


def build_tutor_system_prompt(strategy: str, profile: StudentProfile) -> str:
    """
    Build the system prompt for the given strategy, lightly personalized
    with the student's learning preferences.
    """
    base = TUTOR_SYSTEM_TEMPLATES.get(strategy, TUTOR_SYSTEM_TEMPLATES["direct"])

    personalization_notes = []
    if profile.preferences.cognitive_load == "low":
        personalization_notes.append(
            "Keep cognitive load LOW: short sentences, one idea at a time."
        )
    elif profile.preferences.cognitive_load == "high":
        personalization_notes.append(
            "This student can handle HIGH cognitive load: feel free to "
            "connect multiple related ideas."
        )

    if profile.preferences.responds_well_to_analogies and strategy != "analogy":
        personalization_notes.append(
            "Where natural, briefly relate the idea to a familiar analogy."
        )

    if profile.preferences.needs_step_by_step and strategy not in (
        "worked_example",
        "progressive_hint",
    ):
        personalization_notes.append(
            "Break any explanation into clearly numbered steps."
        )

    if personalization_notes:
        base = base + "\nPERSONALIZATION NOTES:\n" + "\n".join(
            f"- {n}" for n in personalization_notes
        )

    return base
