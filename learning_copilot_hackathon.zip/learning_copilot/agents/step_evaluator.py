"""
Step Evaluator Agent
====================
KEY DIFFERENTIATOR of this system.

Does NOT evaluate final answers.
Evaluates each reasoning step, identifies the FIRST incorrect step,
classifies the mistake type, and determines if understanding or memorization
is at work.

This is what separates an adaptive learning system from a chatbot tutor.
"""
from typing import Optional
from models.schemas import (
    StepEvaluatorOutput, StepAnalysis, MistakeType, StudentProfile
)
from core.logging import safe_parse_json, log_agent_call, get_logger
from core.llm_client import MODEL_EVALUATOR

logger = get_logger(__name__)

STEP_EVALUATOR_SYSTEM = """You are an expert educational diagnostician specializing in reasoning trace analysis.

Your ONLY job: analyze a student's step-by-step solution and determine:
1. Is each step correct?
2. If not — WHY is it wrong, and what TYPE of mistake is it?
3. Which step is the FIRST incorrect step? (This is the root cause, not symptoms)
4. Does this student understand the concept, or are they pattern-matching/memorizing?

MISTAKE TAXONOMY:
- conceptual: Wrong mental model (e.g., thinks multiplication distributes over subtraction like addition)
- procedural: Right concept, wrong execution (e.g., forgot to flip inequality when dividing by negative)
- careless: Arithmetic slip, transcription error, dropped sign (e.g., wrote 3×4=11 not 12)
- knowledge_gap: Missing prerequisite (e.g., solving quadratics without knowing factoring)
- confidence_mismatch: Says "I think" on a correct step, or states a wrong step with certainty

CRITICAL RULES:
- Never evaluate the final answer in isolation. Trace the REASONING.
- A correct final answer can come from flawed reasoning — flag it.
- A wrong final answer can have correct reasoning with one careless slip — distinguish these.
- If multiple steps are wrong, identify the FIRST one — it caused the cascade.

UNDERSTANDING vs MEMORIZATION signals:
- Memorization: Student copies the pattern but can't adapt when you change surface features
- Understanding: Student explains WHY, uses correct notation, catches their own errors
- Key signals for memorization risk: rigid template use, correct on standard form, breaks on novel form

Respond ONLY in this exact JSON format, no preamble:
{
  "step_analyses": [
    {
      "step_number": 1,
      "step_text": "<exact step text>",
      "is_correct": true,
      "mistake_type": null,
      "explanation": "<why correct/wrong>",
      "confidence": 0.95
    }
  ],
  "first_incorrect_step": null,
  "final_answer_correct": true,
  "shows_understanding": true,
  "shows_memorization_risk": false,
  "primary_mistake_type": null,
  "targeted_intervention": "<specific next teaching action>",
  "suggested_next_action": "advance"
}
"""


@log_agent_call("step_evaluator", model=MODEL_EVALUATOR)
async def run_step_evaluator(
    problem: str,
    student_steps: list[str],
    concept_context: str,
    student_profile: StudentProfile,
    llm_client,  # Anthropic or LangChain client
) -> StepEvaluatorOutput:
    """
    Core evaluation function.
    
    Critical design note: we pass the student's misconception history
    so the evaluator can weight its analysis toward known weak points.
    """
    # Build a rich context prompt
    misconceptions = []
    if concept_context in student_profile.concept_mastery:
        cm = student_profile.concept_mastery[concept_context]
        misconceptions = cm.misconception_tags
    
    user_prompt = f"""
PROBLEM: {problem}

STUDENT'S STEP-BY-STEP SOLUTION:
{chr(10).join(f"Step {i+1}: {step}" for i, step in enumerate(student_steps))}

STUDENT CONTEXT:
- Known misconceptions: {misconceptions if misconceptions else "none recorded yet"}
- Mastery score for this concept: {student_profile.concept_mastery.get(concept_context, type('', (), {'mastery_score': 0.5})()).mastery_score:.1%}
- Recent mistake pattern: {_get_recent_mistake_summary(student_profile)}

Analyze each step. Remember: find the FIRST incorrect step, not just the last wrong answer.
"""

    response = await llm_client.messages.create(
        model=MODEL_EVALUATOR,  # Use best model for evaluation — this is the brain
        max_tokens=2000,
        system=STEP_EVALUATOR_SYSTEM,
        messages=[{"role": "user", "content": user_prompt}]
    )
    
    raw = response.content[0].text.strip()
    data = safe_parse_json(raw, context="step_evaluator")
    
    step_analyses = [
        StepAnalysis(
            step_number=s["step_number"],
            step_text=s["step_text"],
            is_correct=s["is_correct"],
            mistake_type=s.get("mistake_type"),
            explanation=s["explanation"],
            confidence=s.get("confidence", 0.9)
        )
        for s in data["step_analyses"]
    ]
    
    return StepEvaluatorOutput(
        problem_id=f"prob_{hash(problem) % 10000:04d}",
        student_steps=student_steps,
        step_analyses=step_analyses,
        first_incorrect_step=data.get("first_incorrect_step"),
        final_answer_correct=data["final_answer_correct"],
        shows_understanding=data["shows_understanding"],
        shows_memorization_risk=data["shows_memorization_risk"],
        primary_mistake_type=data.get("primary_mistake_type"),
        targeted_intervention=data["targeted_intervention"],
        suggested_next_action=data["suggested_next_action"]
    )


def _get_recent_mistake_summary(profile: StudentProfile) -> str:
    if not profile.recent_mistakes:
        return "no recent mistakes"
    
    recent = profile.recent_mistakes[-5:]
    types = [m.mistake_type for m in recent]
    dominant = max(set(types), key=types.count)
    return f"Pattern: mostly '{dominant}' mistakes in last {len(recent)} attempts"


def update_student_model_from_eval(
    profile: StudentProfile,
    eval_output: StepEvaluatorOutput,
    concept_id: str,
) -> StudentProfile:
    """
    Update the student model after a step evaluation.
    
    Key design decisions:
    - Mastery updates use ELO-like decay (wrong answer hurts less than correct helps)
    - Misconceptions accumulate with tags
    - Memorization risk flag is set based on patterns, not single instances
    """
    from datetime import datetime, timezone
    from models.schemas import ConceptMastery, RecentMistake
    
    # Initialize concept if new
    if concept_id not in profile.concept_mastery:
        profile.concept_mastery[concept_id] = ConceptMastery(
            concept_id=concept_id,
            concept_name=concept_id.replace("_", " ").title(),
        )
    
    cm = profile.concept_mastery[concept_id]
    
    # Update mastery score (weighted ELO-style)
    if eval_output.final_answer_correct and eval_output.shows_understanding:
        delta = 0.12 * (1.0 - cm.mastery_score)  # Diminishing returns near ceiling
    elif eval_output.final_answer_correct and not eval_output.shows_understanding:
        delta = 0.04 * (1.0 - cm.mastery_score)  # Memorization: small gain
    elif eval_output.primary_mistake_type == "careless":
        delta = -0.02  # Careless: minimal fixed penalty (arithmetic slip, not knowledge gap)
    else:
        delta = -0.08 * cm.mastery_score  # Conceptual/procedural: proportional decay
    
    cm.mastery_score = max(0.0, min(1.0, cm.mastery_score + delta))
    cm.last_tested = datetime.now(timezone.utc)
    cm.is_memorization_risk = eval_output.shows_memorization_risk
    
    # Add misconception tags from this evaluation
    if eval_output.primary_mistake_type == "conceptual":
        tag = eval_output.targeted_intervention[:50]  # Short tag
        if tag not in cm.misconception_tags:
            cm.misconception_tags.append(tag)
            cm.misconception_tags = cm.misconception_tags[-10:]  # Keep last 10
    
    # Record mistake
    if eval_output.first_incorrect_step is not None:
        mistake = RecentMistake(
            concept_id=concept_id,
            mistake_type=eval_output.primary_mistake_type or "careless",
            description=eval_output.targeted_intervention,
            step_number=eval_output.first_incorrect_step,
            session_id=profile.session_id
        )
        profile.recent_mistakes.append(mistake)
        profile.recent_mistakes = profile.recent_mistakes[-20:]  # Rolling window
    
    # Update understanding mode
    if eval_output.shows_memorization_risk:
        profile.understanding_mode = "memorizing"
    elif eval_output.shows_understanding and cm.mastery_score > 0.7:
        profile.understanding_mode = "conceptual"
    else:
        profile.understanding_mode = "procedural"
    
    # Track streaks
    if eval_output.final_answer_correct:
        profile.questions_correct += 1
    profile.questions_attempted += 1
    
    return profile
