"""
Tool Agent
==========
Decides whether external tools (curriculum retrieval) would help the
student, and uses them only when they genuinely add value.

Design principle:
  Prefer questioning over tools. Retrieval is invoked ONLY for
  `knowledge_gap` mistakes — i.e. when the student is missing prerequisite
  knowledge that an explanation alone is unlikely to fill, and grounding
  in actual curriculum material helps. For every other mistake type
  (conceptual, procedural, careless, confidence_mismatch), the Tutor and
  Socratic agents are preferred — retrieval would be noise.

Graceful degradation:
  If AZURE_SEARCH_ENDPOINT / AZURE_SEARCH_KEY are not configured, or the
  search call fails for any reason (network error, timeout, bad response),
  this module returns empty results. It NEVER raises — a missing or broken
  search backend must not disrupt the learning loop.

Required environment variables (optional — degrades gracefully if absent):
  AZURE_SEARCH_ENDPOINT   https://<service>.search.windows.net
  AZURE_SEARCH_KEY        <admin or query key>
  AZURE_SEARCH_INDEX      curriculum            (default)

Install: pip install azure-search-documents  (only needed for the real SDK
client; this module uses raw httpx so no extra dependency is required)
"""
import os
from dataclasses import dataclass

import httpx

from core.logging import get_logger

logger = get_logger(__name__)


# Read at import/reload time so tests can monkeypatch env vars and reload.
AZURE_SEARCH_ENDPOINT = os.getenv("AZURE_SEARCH_ENDPOINT", "").strip()
AZURE_SEARCH_KEY = os.getenv("AZURE_SEARCH_KEY", "").strip()
AZURE_SEARCH_INDEX = os.getenv("AZURE_SEARCH_INDEX", "curriculum")
AZURE_SEARCH_API_VERSION = os.getenv("AZURE_SEARCH_API_VERSION", "2023-11-01")

# Only mistake types where grounding in curriculum material is worth the
# extra latency / cost. Everything else is better served by the Tutor or
# Socratic agent directly.
RETRIEVAL_WORTHY_MISTAKE_TYPES = {"knowledge_gap"}


@dataclass
class SearchResult:
    """A single curriculum search hit."""
    title: str
    content: str
    score: float = 0.0

    def to_grounding_text(self) -> str:
        """Render as a short block suitable for inclusion in an LLM prompt."""
        return f"[{self.title}]\n{self.content}"


# ─────────────────────────────────────────────
# RAW SEARCH
# ─────────────────────────────────────────────
async def search_curriculum(
    concept: str,
    query: str,
    top_k: int = 3,
) -> list[SearchResult]:
    """
    Query Azure AI Search for curriculum material relevant to `concept`
    and `query`.

    Returns an empty list (never raises) if:
      - Azure Search is not configured (AZURE_SEARCH_ENDPOINT/KEY missing)
      - The HTTP request fails for any reason (network error, bad status)
      - The response cannot be parsed as expected
    """
    if not AZURE_SEARCH_ENDPOINT or not AZURE_SEARCH_KEY:
        logger.info(
            "tool_agent_search_skipped",
            extra={"reason": "azure_search_not_configured", "concept": concept},
        )
        return []

    url = (
        f"{AZURE_SEARCH_ENDPOINT.rstrip('/')}/indexes/{AZURE_SEARCH_INDEX}/docs/search"
        f"?api-version={AZURE_SEARCH_API_VERSION}"
    )
    headers = {
        "Content-Type": "application/json",
        "api-key": AZURE_SEARCH_KEY,
    }
    body = {
        "search": f"{concept} {query}".strip(),
        "top": top_k,
        "queryType": "simple",
    }

    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.post(url, headers=headers, json=body)
            response.raise_for_status()
            data = response.json()
    except Exception as exc:
        logger.warning(
            "tool_agent_search_failed",
            extra={"concept": concept, "error": str(exc), "error_type": type(exc).__name__},
        )
        return []

    results: list[SearchResult] = []
    for doc in data.get("value", []):
        try:
            results.append(
                SearchResult(
                    title=doc.get("title", doc.get("id", "Untitled")),
                    content=doc.get("content", ""),
                    score=float(doc.get("@search.score", 0.0)),
                )
            )
        except Exception:
            continue

    return results[:top_k]


# ─────────────────────────────────────────────
# TOOL AGENT ENTRY POINT
# ─────────────────────────────────────────────
async def run_tool_agent(
    concept: str,
    mistake_type: str | None,
    student_question: str | None,
    llm_client,
) -> dict:
    """
    Decide whether retrieval would help, and if so, fetch and format
    grounding context.

    Returns:
        {
            "used_retrieval": bool,
            "grounding_context": str,   # "" if not used
            "sources": list[SearchResult],  # [] if not used
        }

    `llm_client` is accepted for interface symmetry with the other agents
    and for future use (e.g. query reformulation before search), but the
    current implementation does not call the LLM directly — retrieval
    decisions are deterministic, matching the Orchestrator's philosophy.
    """
    if mistake_type not in RETRIEVAL_WORTHY_MISTAKE_TYPES:
        logger.info(
            "tool_agent_skipped",
            extra={"concept": concept, "mistake_type": mistake_type, "reason": "not_retrieval_worthy"},
        )
        return {"used_retrieval": False, "grounding_context": "", "sources": []}

    query = student_question or concept
    results = await search_curriculum(concept, query, top_k=3)

    if not results:
        return {"used_retrieval": False, "grounding_context": "", "sources": []}

    grounding_context = "\n\n".join(r.to_grounding_text() for r in results)

    logger.info(
        "tool_agent_used_retrieval",
        extra={"concept": concept, "mistake_type": mistake_type, "num_sources": len(results)},
    )

    return {
        "used_retrieval": True,
        "grounding_context": grounding_context,
        "sources": results,
    }
