import { useState, useRef, useEffect } from "react";

const API_BASE = "http://localhost:8000";

// ── helpers ─────────────────────────────────────────────
const post = (path, body) =>
  fetch(API_BASE + path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  }).then(r => r.json());

const get = path => fetch(API_BASE + path).then(r => r.json());

const MISTAKE_COLORS = {
  conceptual: "#ef4444",
  procedural: "#f97316",
  careless: "#eab308",
  knowledge_gap: "#8b5cf6",
  confidence_mismatch: "#06b6d4",
};

const PHASE_LABELS = {
  teach: "📖 Teaching",
  test: "✏️ Testing",
  evaluate: "🔍 Evaluating",
  diagnose: "🩺 Diagnosing",
  adapt: "🔄 Adapting",
};

// ── sub-components ───────────────────────────────────────
function MasteryBar({ value, label }) {
  const pct = Math.round((value || 0) * 100);
  const color = pct >= 75 ? "#22c55e" : pct >= 45 ? "#f97316" : "#ef4444";
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 3 }}>
        <span style={{ color: "var(--color-text-secondary)" }}>{label}</span>
        <span style={{ fontWeight: 600, color }}>{pct}%</span>
      </div>
      <div style={{ height: 6, background: "var(--color-border-secondary)", borderRadius: 3 }}>
        <div style={{ height: "100%", width: `${pct}%`, background: color, borderRadius: 3, transition: "width 0.6s ease" }} />
      </div>
    </div>
  );
}

function StepCard({ step, idx }) {
  return (
    <div style={{
      padding: "10px 14px", marginBottom: 8, borderRadius: 8,
      background: step.correct ? "rgba(34,197,94,0.08)" : "rgba(239,68,68,0.08)",
      border: `1px solid ${step.correct ? "rgba(34,197,94,0.3)" : "rgba(239,68,68,0.3)"}`,
    }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
        <span style={{ fontSize: 16, flexShrink: 0, marginTop: 1 }}>{step.correct ? "✅" : "❌"}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 500, fontSize: 13, marginBottom: 4 }}>
            Step {step.step}: <span style={{ fontFamily: "monospace" }}>{step.text}</span>
          </div>
          <div style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>{step.note}</div>
          {step.mistake_type && (
            <span style={{
              display: "inline-block", marginTop: 6, padding: "2px 8px",
              borderRadius: 12, fontSize: 11, fontWeight: 600,
              background: `${MISTAKE_COLORS[step.mistake_type]}22`,
              color: MISTAKE_COLORS[step.mistake_type],
              border: `1px solid ${MISTAKE_COLORS[step.mistake_type]}44`,
            }}>{step.mistake_type}</span>
          )}
        </div>
      </div>
    </div>
  );
}

function KnowledgeMap({ map }) {
  if (!map || !Object.keys(map).length) return null;
  return (
    <div>
      {Object.entries(map).map(([id, cm]) => (
        <div key={id} style={{ marginBottom: 16 }}>
          <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 6 }}>{cm.name || id}</div>
          <MasteryBar value={cm.mastery} label="Mastery" />
          <MasteryBar value={cm.confidence} label="Confidence" />
          {cm.calibration_error > 0.15 && (
            <div style={{ fontSize: 11, color: "#f97316", marginTop: 4 }}>
              ⚠️ Overconfident by {Math.round(cm.calibration_error * 100)}%
            </div>
          )}
          {cm.is_memorization_risk && (
            <div style={{ fontSize: 11, color: "#8b5cf6", marginTop: 2 }}>
              🔄 Memorization pattern detected
            </div>
          )}
          {cm.misconceptions?.length > 0 && (
            <div style={{ marginTop: 6 }}>
              {cm.misconceptions.map((m, i) => (
                <span key={i} style={{
                  display: "inline-block", marginRight: 6, marginBottom: 4,
                  padding: "2px 8px", borderRadius: 10, fontSize: 11,
                  background: "rgba(239,68,68,0.1)", color: "#ef4444",
                  border: "1px solid rgba(239,68,68,0.3)",
                }}>{m.slice(0, 40)}</span>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function Message({ msg }) {
  const isUser = msg.role === "user";
  const isSystem = msg.role === "system";
  return (
    <div style={{
      display: "flex", flexDirection: isUser ? "row-reverse" : "row",
      marginBottom: 16, gap: 10, alignItems: "flex-start",
    }}>
      <div style={{
        width: 32, height: 32, borderRadius: "50%", flexShrink: 0,
        display: "flex", alignItems: "center", justifyContent: "center",
        background: isUser ? "var(--color-accent-primary)" : isSystem ? "#374151" : "#1B2B4B",
        fontSize: 14, fontWeight: 700, color: "#fff",
      }}>
        {isUser ? "S" : isSystem ? "⚙" : "AI"}
      </div>
      <div style={{
        maxWidth: "78%",
        padding: "12px 16px",
        borderRadius: isUser ? "16px 4px 16px 16px" : "4px 16px 16px 16px",
        background: isUser
          ? "var(--color-accent-primary)"
          : isSystem
          ? "rgba(99,102,241,0.12)"
          : "var(--color-bg-secondary)",
        color: isUser ? "#fff" : "var(--color-text-primary)",
        border: isSystem ? "1px solid rgba(99,102,241,0.3)" : "1px solid var(--color-border-secondary)",
      }}>
        {msg.strategy && (
          <div style={{ fontSize: 11, opacity: 0.7, marginBottom: 6, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}>
            🎯 {msg.strategy} strategy
          </div>
        )}
        <div style={{ fontSize: 14, lineHeight: 1.6, whiteSpace: "pre-wrap" }}>{msg.content}</div>
        {msg.steps?.length > 0 && (
          <div style={{ marginTop: 12 }}>
            {msg.steps.map((s, i) => <StepCard key={i} step={s} idx={i} />)}
          </div>
        )}
        {msg.mistake_type && (
          <div style={{ marginTop: 8, padding: "6px 12px", borderRadius: 8, background: "rgba(0,0,0,0.15)", fontSize: 12 }}>
            <strong>First wrong step:</strong> Step {msg.first_wrong} &nbsp;|&nbsp;
            <strong>Type:</strong> <span style={{ color: MISTAKE_COLORS[msg.mistake_type] }}>{msg.mistake_type}</span>
          </div>
        )}
      </div>
    </div>
  );
}

// ── main app ─────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState("setup"); // setup | chat
  const [sessionId, setSessionId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [steps, setSteps] = useState([""]);
  const [showSteps, setShowSteps] = useState(false);
  const [confidence, setConfidence] = useState(0.7);
  const [loading, setLoading] = useState(false);
  const [state, setState] = useState(null);
  const [phase, setPhase] = useState("teach");
  const [setupForm, setSetupForm] = useState({
    topic: "linear_equations",
    student_name: "Alex",
    preferred_style: "direct",
    prior_mastery: 0,
  });
  const [activeTab, setActiveTab] = useState("chat");
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const addMsg = (role, content, extra = {}) =>
    setMessages(prev => [...prev, { role, content, ...extra }]);

  const refreshState = async (sid) => {
    try {
      const s = await get(`/session/${sid || sessionId}/state`);
      setState(s);
      setPhase(s.current_phase);
    } catch (_) {}
  };

  const handleStart = async () => {
    setLoading(true);
    try {
      const res = await post("/session/start", {
        ...setupForm,
        prior_mastery: parseFloat(setupForm.prior_mastery),
      });
      if (res.session_id) {
        setSessionId(res.session_id);
        setScreen("chat");
        addMsg("assistant", res.initial_message, { strategy: res.teaching_strategy });
        await refreshState(res.session_id);
      }
    } catch (e) {
      addMsg("system", `Failed to start session: ${e.message}`);
    }
    setLoading(false);
  };

  const handleSend = async () => {
    if (!input.trim() && steps.every(s => !s.trim())) return;
    const userText = input.trim() || `Attempting with ${steps.filter(Boolean).length} steps`;
    const validSteps = steps.filter(s => s.trim());
    addMsg("user", userText + (validSteps.length ? "\n\nSteps:\n" + validSteps.map((s, i) => `${i + 1}. ${s}`).join("\n") : ""));
    setInput("");
    setSteps([""]);
    setShowSteps(false);
    setLoading(true);

    try {
      const body = { message: userText || "Here is my solution", confidence };
      if (validSteps.length) body.steps = validSteps;

      const res = await post(`/session/${sessionId}/respond`, body);
      setPhase(res.next_phase || phase);

      if (res.type === "request_steps") {
        addMsg("assistant", res.response);
        setShowSteps(true);
      } else if (res.type === "evaluation") {
        addMsg("assistant", res.response, {
          steps: res.step_analysis || [],
          first_wrong: res.first_incorrect_step,
          mistake_type: res.mistake_type,
        });
      } else {
        addMsg("assistant", res.response || "…", { strategy: res.strategy_changed_to || res.strategy_used });
      }
      await refreshState();
    } catch (e) {
      addMsg("system", `Error: ${e.message}`);
    }
    setLoading(false);
  };

  const handleGenerateProblem = async () => {
    setLoading(true);
    try {
      const res = await post(`/session/${sessionId}/generate-problem`, { force_transfer: false });
      if (res.problem) {
        addMsg("system",
          `🎯 NEW TARGETED PROBLEM\n\n${res.problem.problem}\n\nDifficulty: ${Math.round((res.problem.difficulty || 0.5) * 100)}% | Target: ${res.problem.target_concept}\n\n${res.instruction}`
        );
        setShowSteps(true);
      }
    } catch (e) {
      addMsg("system", `Problem generation failed: ${e.message}`);
    }
    setLoading(false);
  };

  const updateStep = (i, val) => {
    const s = [...steps];
    s[i] = val;
    setSteps(s);
  };
  const addStep = () => setSteps([...steps, ""]);
  const removeStep = i => setSteps(steps.filter((_, idx) => idx !== i));

  // ── SETUP SCREEN ─────────────────────────────────────
  if (screen === "setup") {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24, background: "var(--color-bg-primary)" }}>
        <div style={{ width: "100%", maxWidth: 480, background: "var(--color-bg-secondary)", borderRadius: 16, padding: 32, border: "1px solid var(--color-border-secondary)" }}>
          <div style={{ textAlign: "center", marginBottom: 28 }}>
            <div style={{ fontSize: 40, marginBottom: 8 }}>🎓</div>
            <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Learning Copilot</h1>
            <p style={{ margin: "8px 0 0", fontSize: 14, color: "var(--color-text-secondary)" }}>
              Multi-agent adaptive tutoring — deep understanding, not just correct answers
            </p>
          </div>

          {[
            { label: "Your name", key: "student_name", type: "text", placeholder: "e.g. Alex" },
            { label: "Topic to learn", key: "topic", type: "text", placeholder: "e.g. linear_equations, calculus, probability" },
          ].map(({ label, key, type, placeholder }) => (
            <div key={key} style={{ marginBottom: 16 }}>
              <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6 }}>{label}</label>
              <input
                type={type} value={setupForm[key]} placeholder={placeholder}
                onChange={e => setSetupForm(f => ({ ...f, [key]: e.target.value }))}
                style={{
                  width: "100%", padding: "10px 12px", borderRadius: 8, fontSize: 14,
                  background: "var(--color-bg-primary)", color: "var(--color-text-primary)",
                  border: "1px solid var(--color-border-secondary)", boxSizing: "border-box",
                  outline: "none",
                }}
              />
            </div>
          ))}

          <div style={{ marginBottom: 16 }}>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6 }}>Teaching style</label>
            <select
              value={setupForm.preferred_style}
              onChange={e => setSetupForm(f => ({ ...f, preferred_style: e.target.value }))}
              style={{
                width: "100%", padding: "10px 12px", borderRadius: 8, fontSize: 14,
                background: "var(--color-bg-primary)", color: "var(--color-text-primary)",
                border: "1px solid var(--color-border-secondary)",
              }}
            >
              <option value="direct">Direct explanation</option>
              <option value="socratic">Socratic (guided questions)</option>
              <option value="examples_first">Examples first</option>
              <option value="visual">Visual / analogies</option>
            </select>
          </div>

          <div style={{ marginBottom: 24 }}>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, marginBottom: 6 }}>
              Prior knowledge: {Math.round(setupForm.prior_mastery * 100)}%
            </label>
            <input type="range" min={0} max={100} step={5}
              value={Math.round(setupForm.prior_mastery * 100)}
              onChange={e => setSetupForm(f => ({ ...f, prior_mastery: parseInt(e.target.value) / 100 }))}
              style={{ width: "100%" }}
            />
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "var(--color-text-secondary)", marginTop: 2 }}>
              <span>Complete beginner</span><span>Expert</span>
            </div>
          </div>

          <button
            onClick={handleStart}
            disabled={loading || !setupForm.topic.trim() || !setupForm.student_name.trim()}
            style={{
              width: "100%", padding: "12px 0", borderRadius: 10, fontSize: 15, fontWeight: 700,
              background: loading ? "var(--color-border-secondary)" : "var(--color-accent-primary)",
              color: "#fff", border: "none", cursor: loading ? "not-allowed" : "pointer",
              transition: "opacity 0.2s",
            }}
          >
            {loading ? "Starting…" : "Start Learning →"}
          </button>

          <p style={{ textAlign: "center", fontSize: 12, marginTop: 16, color: "var(--color-text-tertiary)" }}>
            Requires a running API server at localhost:8000
          </p>
        </div>
      </div>
    );
  }

  // ── CHAT SCREEN ──────────────────────────────────────
  const sidebarStyle = {
    width: 260, flexShrink: 0, background: "var(--color-bg-secondary)",
    borderRight: "1px solid var(--color-border-secondary)",
    display: "flex", flexDirection: "column", overflow: "hidden",
  };

  return (
    <div style={{ display: "flex", height: "100vh", background: "var(--color-bg-primary)", overflow: "hidden" }}>

      {/* ── SIDEBAR ── */}
      <div style={sidebarStyle}>
        {/* Header */}
        <div style={{ padding: "16px 16px 12px", borderBottom: "1px solid var(--color-border-secondary)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <span style={{ fontSize: 22 }}>🎓</span>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14 }}>Learning Copilot</div>
              <div style={{ fontSize: 11, color: "var(--color-text-secondary)" }}>Session: {sessionId}</div>
            </div>
          </div>

          {/* Phase pill */}
          <div style={{
            display: "inline-flex", alignItems: "center", gap: 6,
            padding: "4px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600,
            background: "rgba(99,102,241,0.15)", color: "var(--color-accent-primary)",
            border: "1px solid rgba(99,102,241,0.3)",
          }}>
            {PHASE_LABELS[phase] || phase}
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", borderBottom: "1px solid var(--color-border-secondary)" }}>
          {["Model", "Stats"].map(t => (
            <button key={t}
              onClick={() => setActiveTab(t.toLowerCase())}
              style={{
                flex: 1, padding: "8px 0", fontSize: 12, fontWeight: 600,
                background: activeTab === t.toLowerCase() ? "var(--color-bg-primary)" : "transparent",
                color: activeTab === t.toLowerCase() ? "var(--color-accent-primary)" : "var(--color-text-secondary)",
                border: "none", borderBottom: activeTab === t.toLowerCase() ? "2px solid var(--color-accent-primary)" : "2px solid transparent",
                cursor: "pointer",
              }}
            >{t}</button>
          ))}
        </div>

        {/* Tab content */}
        <div style={{ flex: 1, overflowY: "auto", padding: 14 }}>
          {activeTab === "model" && state && (
            <>
              <div style={{ fontSize: 12, fontWeight: 600, color: "var(--color-text-secondary)", marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                Knowledge Map
              </div>
              <KnowledgeMap map={state.knowledge_map} />

              <div style={{ marginTop: 16, padding: "10px 12px", borderRadius: 8, background: "var(--color-bg-primary)", border: "1px solid var(--color-border-secondary)" }}>
                <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6 }}>Understanding Mode</div>
                <div style={{
                  display: "inline-block", padding: "3px 10px", borderRadius: 12, fontSize: 12,
                  background: state.understanding_mode === "conceptual" ? "rgba(34,197,94,0.15)"
                    : state.understanding_mode === "memorizing" ? "rgba(239,68,68,0.15)"
                    : "rgba(249,115,22,0.15)",
                  color: state.understanding_mode === "conceptual" ? "#22c55e"
                    : state.understanding_mode === "memorizing" ? "#ef4444" : "#f97316",
                  border: "1px solid currentColor",
                }}>
                  {state.understanding_mode}
                </div>
              </div>

              {state.recent_mistakes?.length > 0 && (
                <div style={{ marginTop: 14 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: "var(--color-text-secondary)", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.05em" }}>Recent Mistakes</div>
                  {state.recent_mistakes.slice(-3).map((m, i) => (
                    <div key={i} style={{
                      marginBottom: 6, padding: "6px 10px", borderRadius: 6, fontSize: 12,
                      background: `${MISTAKE_COLORS[m.type] || "#6b7280"}11`,
                      border: `1px solid ${MISTAKE_COLORS[m.type] || "#6b7280"}33`,
                    }}>
                      <span style={{ fontWeight: 600, color: MISTAKE_COLORS[m.type] }}>{m.type}</span>
                      {m.step && <span style={{ color: "var(--color-text-secondary)" }}> · Step {m.step}</span>}
                      <div style={{ color: "var(--color-text-secondary)", marginTop: 2 }}>{m.description?.slice(0, 60)}</div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {activeTab === "stats" && state && (
            <>
              {[
                ["Accuracy", `${Math.round((state.performance?.accuracy || 0) * 100)}%`],
                ["Attempted", state.performance?.questions_attempted || 0],
                ["Correct", state.performance?.questions_correct || 0],
                ["Loop count", state.loop_count || 0],
                ["Correct streak", state.performance?.consecutive_correct || 0],
                ["Wrong streak", state.performance?.consecutive_wrong || 0],
              ].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid var(--color-border-tertiary)", fontSize: 13 }}>
                  <span style={{ color: "var(--color-text-secondary)" }}>{k}</span>
                  <span style={{ fontWeight: 600 }}>{v}</span>
                </div>
              ))}
              {state.plateau_detected && (
                <div style={{ marginTop: 12, padding: "8px 12px", borderRadius: 8, background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", fontSize: 12, color: "#ef4444" }}>
                  ⚠️ Learning plateau detected
                </div>
              )}
            </>
          )}
        </div>

        {/* Action buttons */}
        <div style={{ padding: 12, borderTop: "1px solid var(--color-border-secondary)", display: "flex", flexDirection: "column", gap: 8 }}>
          <button
            onClick={handleGenerateProblem}
            disabled={loading}
            style={{
              padding: "9px 0", borderRadius: 8, fontSize: 13, fontWeight: 600,
              background: "rgba(99,102,241,0.15)", color: "var(--color-accent-primary)",
              border: "1px solid rgba(99,102,241,0.3)", cursor: loading ? "not-allowed" : "pointer",
            }}
          >
            🎯 Generate Targeted Problem
          </button>
          <button
            onClick={() => { setScreen("setup"); setMessages([]); setSessionId(null); setState(null); }}
            style={{
              padding: "8px 0", borderRadius: 8, fontSize: 12,
              background: "transparent", color: "var(--color-text-secondary)",
              border: "1px solid var(--color-border-secondary)", cursor: "pointer",
            }}
          >
            ← New Session
          </button>
        </div>
      </div>

      {/* ── CHAT PANEL ── */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        {/* Messages */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px" }}>
          {messages.length === 0 && (
            <div style={{ textAlign: "center", color: "var(--color-text-tertiary)", marginTop: 60, fontSize: 14 }}>
              Session started. Respond to the tutor to begin your learning loop.
            </div>
          )}
          {messages.map((msg, i) => <Message key={i} msg={msg} />)}
          {loading && (
            <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
              <div style={{ width: 32, height: 32, borderRadius: "50%", background: "#1B2B4B", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 14 }}>AI</div>
              <div style={{ padding: "12px 16px", borderRadius: "4px 16px 16px 16px", background: "var(--color-bg-secondary)", border: "1px solid var(--color-border-secondary)" }}>
                <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
                  {[0, 1, 2].map(i => (
                    <div key={i} style={{
                      width: 6, height: 6, borderRadius: "50%", background: "var(--color-accent-primary)",
                      animation: `pulse 1.2s ease-in-out ${i * 0.2}s infinite`,
                    }} />
                  ))}
                </div>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input area */}
        <div style={{ padding: "12px 24px 20px", borderTop: "1px solid var(--color-border-secondary)", background: "var(--color-bg-secondary)" }}>
          {/* Steps */}
          {showSteps && (
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 8, color: "var(--color-text-secondary)" }}>
                📝 Step-by-step solution (the Step Evaluator analyzes each step)
              </div>
              {steps.map((s, i) => (
                <div key={i} style={{ display: "flex", gap: 8, marginBottom: 6, alignItems: "center" }}>
                  <span style={{ fontSize: 12, color: "var(--color-text-secondary)", width: 50, flexShrink: 0 }}>Step {i + 1}</span>
                  <input
                    value={s}
                    onChange={e => updateStep(i, e.target.value)}
                    onKeyDown={e => e.key === "Enter" && i === steps.length - 1 && addStep()}
                    placeholder={`e.g. Subtract 5 from both sides: 2x = 8`}
                    style={{
                      flex: 1, padding: "7px 10px", borderRadius: 7, fontSize: 13,
                      background: "var(--color-bg-primary)", color: "var(--color-text-primary)",
                      border: "1px solid var(--color-border-secondary)", outline: "none",
                    }}
                  />
                  {steps.length > 1 && (
                    <button onClick={() => removeStep(i)} style={{ background: "none", border: "none", color: "var(--color-text-tertiary)", cursor: "pointer", fontSize: 16 }}>×</button>
                  )}
                </div>
              ))}
              <button onClick={addStep} style={{ fontSize: 12, color: "var(--color-accent-primary)", background: "none", border: "none", cursor: "pointer", padding: 0 }}>
                + Add step
              </button>
            </div>
          )}

          {/* Confidence slider */}
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
            <span style={{ fontSize: 12, color: "var(--color-text-secondary)", flexShrink: 0 }}>
              Confidence: {Math.round(confidence * 100)}%
            </span>
            <input type="range" min={0} max={100} step={5}
              value={Math.round(confidence * 100)}
              onChange={e => setConfidence(parseInt(e.target.value) / 100)}
              style={{ flex: 1, maxWidth: 160 }}
            />
            <button
              onClick={() => setShowSteps(v => !v)}
              style={{
                padding: "5px 12px", borderRadius: 7, fontSize: 12, fontWeight: 600,
                background: showSteps ? "rgba(99,102,241,0.15)" : "var(--color-bg-primary)",
                color: showSteps ? "var(--color-accent-primary)" : "var(--color-text-secondary)",
                border: `1px solid ${showSteps ? "rgba(99,102,241,0.3)" : "var(--color-border-secondary)"}`,
                cursor: "pointer",
              }}
            >
              {showSteps ? "✓ Show steps" : "+ Show steps"}
            </button>
          </div>

          {/* Message input */}
          <div style={{ display: "flex", gap: 10 }}>
            <textarea
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
              placeholder="Type your response… (Enter to send, Shift+Enter for newline)"
              rows={2}
              style={{
                flex: 1, padding: "10px 14px", borderRadius: 10, fontSize: 14, resize: "none",
                background: "var(--color-bg-primary)", color: "var(--color-text-primary)",
                border: "1px solid var(--color-border-secondary)", outline: "none",
                fontFamily: "inherit", lineHeight: 1.5,
              }}
            />
            <button
              onClick={handleSend}
              disabled={loading || (!input.trim() && steps.every(s => !s.trim()))}
              style={{
                padding: "0 20px", borderRadius: 10, fontSize: 18, fontWeight: 700,
                background: loading ? "var(--color-border-secondary)" : "var(--color-accent-primary)",
                color: "#fff", border: "none", cursor: loading ? "not-allowed" : "pointer",
                flexShrink: 0, transition: "background 0.2s",
              }}
            >→</button>
          </div>
          <div style={{ fontSize: 11, color: "var(--color-text-tertiary)", marginTop: 6 }}>
            Tip: Use "Show steps" to submit step-by-step solutions for detailed reasoning analysis
          </div>
        </div>
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.3; transform: scale(0.8); }
          50% { opacity: 1; transform: scale(1); }
        }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--color-border-secondary); border-radius: 3px; }
      `}</style>
    </div>
  );
}
