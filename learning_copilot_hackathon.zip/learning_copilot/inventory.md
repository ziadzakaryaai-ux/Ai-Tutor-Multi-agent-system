# Learning Copilot — Project Inventory
> Last updated: Session 6 | Status: **Hackathon Ready** ✅

---

## Project Overview

Multi-Agent Adaptive Learning System that optimizes for **deep understanding**, not content delivery.
Core differentiator: step-level reasoning evaluation with a five-type mistake taxonomy.

---

## Directory Structure

```
learning_copilot/
├── models/
│   ├── __init__.py
│   └── schemas.py              ✅ All Pydantic contracts (StudentProfile, SessionState, …)
├── core/
│   ├── __init__.py
│   ├── llm_client.py           ✅ Factory: Anthropic ↔ Azure OpenAI; MODEL_EVALUATOR / MODEL_TUTOR
│   ├── orchestrator.py         ✅ Deterministic state machine (6-priority routing ladder)
│   ├── storage.py              ✅ InMemory / JSON / CosmosDB (student_id isolation fixed)
│   ├── spaced_repetition.py    ✅ Ebbinghaus retention model
│   └── logging.py              ✅ Structured JSON logging + safe_parse_json
├── agents/
│   ├── __init__.py
│   ├── step_evaluator.py       ✅ Per-step reasoning analysis; MODEL_EVALUATOR
│   ├── tutor.py                ✅ 5-strategy deterministic selection; MODEL_TUTOR
│   ├── evaluator.py            ✅ Deterministic (no LLM) holistic evaluation
│   ├── socratic.py             ✅ Transfer/probing questions; MODEL_TUTOR
│   ├── assessment.py           ✅ Targeted problem generation; MODEL_TUTOR
│   └── tool_agent.py           ✅ Azure AI Search with graceful degradation
├── api/
│   ├── __init__.py
│   └── main.py                 ✅ FastAPI: 10 endpoints + CORS + error handling
├── tests/
│   ├── __init__.py
│   ├── conftest.py             ✅ Shared fixtures (profiles, evals, mock LLM, storage)
│   ├── test_extended.py        ✅ Agents + orchestrator + API smoke (80+ tests)
│   ├── test_spaced_repetition.py ✅ Retention model tests (22 tests)
│   ├── test_storage_isolation.py ✅ Student-ID isolation regression (15 tests)
│   └── test_azure.py           ✅ Azure adapter + storage factory (18 tests)
├── azure/
│   ├── azure-container-app.bicep ✅ Bicep IaC (Container Apps + optional Cosmos)
│   ├── azure-params.json       ✅ Deployment parameters template
│   └── deploy-azure.sh         ✅ One-command deploy script
├── demo.py                     ✅ 3-minute hackathon demo (8 stages)
├── LearningCopilotUI.jsx       ✅ React frontend (setup + chat + sidebar)
├── Dockerfile                  ✅ Production container
├── docker-compose.yml          ✅ Local dev
├── .env.example                ✅ Environment variable template
├── requirements.txt            ✅
├── pyproject.toml              ✅
├── Makefile                    ✅ make test / run / demo / deploy
├── pytest.ini                  ✅
└── ci.yml                      ✅ GitHub Actions: test + lint + API smoke
```

---

## Component Status

| Component | Status | Tests | Notes |
|-----------|--------|-------|-------|
| schemas.py | ✅ Complete | via conftest | Literal[str] phases, no Enum |
| llm_client.py | ✅ Complete | test_azure.py | MODEL_EVALUATOR / MODEL_TUTOR env overridable |
| orchestrator.py | ✅ Complete | test_extended.py | 6-priority routing ladder; evaluator wired in |
| storage.py | ✅ Complete | test_storage_isolation.py | student_id isolation in all 3 backends |
| spaced_repetition.py | ✅ Complete | test_spaced_repetition.py | Ebbinghaus; ReviewItem dataclass |
| step_evaluator.py | ✅ Complete | test_extended.py | Uses MODEL_EVALUATOR constant |
| tutor.py | ✅ Complete | test_extended.py | Uses MODEL_TUTOR constant |
| evaluator.py | ✅ Complete | test_extended.py | Pure deterministic, no LLM |
| socratic.py | ✅ Complete | test_extended.py | Uses MODEL_TUTOR constant |
| assessment.py | ✅ Complete | via api/main.py | Uses MODEL_TUTOR constant |
| tool_agent.py | ✅ Complete | test_azure.py | knowledge_gap only; graceful degradation |
| api/main.py | ✅ Complete | test_extended.py | 10 endpoints |
| demo.py | ✅ Complete | manual | 8-stage showcase |
| LearningCopilotUI.jsx | ✅ Complete | manual | React SPA |

---

## Resolved Bugs

| ID | Description | Resolution |
|----|-------------|------------|
| BUG-001 | list_sessions returned all sessions (ignored student_id) | Fixed in all 3 backends; 15 regression tests added |
| BUG-002 | SessionPhase enum / use_enum_values crash | INVALID — schemas.py uses Literal[str], no Enum |
| BUG-003 | Hardcoded model strings scattered across agents | Fixed: MODEL_EVALUATOR / MODEL_TUTOR constants in llm_client.py |
| BUG-004 | Evaluator not called in orchestrator | Fixed: evaluate_understanding() called in _handle_test_phase and _handle_evaluate_phase |

---

## Test Count

| File | Tests |
|------|-------|
| test_extended.py | ~80 |
| test_spaced_repetition.py | 22 |
| test_storage_isolation.py | 15 |
| test_azure.py | 18 |
| **Total** | **~135** |

---

## Known Limitations (Post-Hackathon Backlog)

1. **Plateau circuit breaker**: `adapt` phase has no upper-bound loop counter — can loop indefinitely in degenerate cases.
2. **No WebSocket**: real-time streaming would improve UX; current API is request/response.
3. **Assessment agent not wired into learning loop**: currently only available via the `/generate-problem` endpoint; could be auto-triggered on mastery advance.
4. **Tool Agent search**: requires Azure AI Search configuration; curriculum index not included.
