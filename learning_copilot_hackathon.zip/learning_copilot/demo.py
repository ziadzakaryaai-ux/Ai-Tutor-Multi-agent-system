"""
Demo Script — Multi-Agent Learning Copilot
===========================================
3-minute hackathon showcase of the full multi-agent loop.

Usage:
  python demo.py                               # default: linear_equations, conceptual
  python demo.py linear_equations procedural
  python demo.py linear_equations careless
  python demo.py probability conceptual

What it shows:
  [1] Student profile created
  [2] Tutor teaches (strategy selected deterministically)
  [3] Student submits WRONG steps (configurable mistake type)
  [4] Step Evaluator identifies FIRST wrong step + classifies mistake type
  [5] Student Model updates mastery + logs misconception
  [6] Tutor ADAPTS strategy based on mistake type
  [7] Student reattempts correctly
  [8] Socratic Agent challenges understanding (transfer / probing question)
  ── Summary printout
"""
import asyncio
import json
import os
import sys
from datetime import timezone, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from models.schemas import (
    SessionState, StudentProfile, ConceptMastery, LearningPreferences
)
from core.orchestrator import LearningOrchestrator
from agents.step_evaluator import run_step_evaluator, update_student_model_from_eval
from agents.tutor import run_tutor_agent
from agents.socratic import run_socratic_agent

# ── colour helpers ──────────────────────────────────────
RESET = "\033[0m"
BOLD  = "\033[1m"
CYAN  = "\033[96m"
GREEN = "\033[92m"
RED   = "\033[91m"
YELLOW= "\033[93m"
DIM   = "\033[2m"

def hdr(n, title): print(f"\n{BOLD}{CYAN}[{n}] {title}{RESET}\n{'─'*50}")
def ok(msg):       print(f"  {GREEN}✓{RESET} {msg}")
def err(msg):      print(f"  {RED}✗{RESET} {msg}")
def info(msg):     print(f"  {DIM}{msg}{RESET}")
def label(k, v):   print(f"  {BOLD}{k}:{RESET} {v}")

# ── demo scenarios ──────────────────────────────────────
SCENARIOS = {
    "linear_equations": {
        "topic": "linear_equations",
        "problem": "Solve for x: 2x + 5 = 13",
        "correct_steps": [
            "Subtract 5 from both sides: 2x + 5 - 5 = 13 - 5",
            "Simplify: 2x = 8",
            "Divide both sides by 2: x = 4",
            "Check: 2(4) + 5 = 13  ✓",
        ],
        "wrong_steps": {
            "conceptual": [
                "Divide both sides by 2 first: x + 5 = 6.5",
                "Subtract 5 from both sides: x = 1.5",
            ],
            "procedural": [
                "Subtract 5 from both sides: 2x = 8",
                "Multiply both sides by 2: x = 16",
            ],
            "careless": [
                "Subtract 5 from both sides: 2x = 7",
                "Divide both sides by 2: x = 3.5",
            ],
        },
    },
    "probability": {
        "topic": "basic_probability",
        "problem": (
            "A bag has 3 red and 7 blue balls. "
            "What is the probability of drawing 2 red balls in a row (without replacement)?"
        ),
        "correct_steps": [
            "P(first red) = 3/10 (3 red out of 10 total)",
            "After removing 1 red: P(second red) = 2/9 (2 red out of 9 remaining)",
            "P(both red) = 3/10 × 2/9 = 6/90 = 1/15",
        ],
        "wrong_steps": {
            "conceptual": [
                "P(first red) = 3/10",
                "P(second red) = 3/10 — same probability, events are independent",
                "P(both) = 9/100 = 0.09",
            ],
            "procedural": [
                "P(first red) = 3/10",
                "P(second red) = 2/9",
                "P(both) = 3/10 + 2/9 = 27/90 + 20/90 = 47/90",
            ],
            "careless": [
                "P(first red) = 3/10",
                "P(second red) = 2/9",
                "P(both) = 3/10 × 2/9 = 6/90 = 1/16",
            ],
        },
    },
}


async def run_demo(scenario_key: str = "linear_equations", mistake_type: str = "conceptual"):

    from core.llm_client import build_llm_client
    client = build_llm_client()

    scenario = SCENARIOS.get(scenario_key)
    if not scenario:
        print(f"{RED}Unknown scenario: {scenario_key}. Choose from: {list(SCENARIOS)}{RESET}")
        sys.exit(1)

    wrong_steps = scenario["wrong_steps"].get(mistake_type)
    if not wrong_steps:
        print(f"{RED}Unknown mistake type: {mistake_type}. Choose from: conceptual, procedural, careless{RESET}")
        sys.exit(1)

    print(f"\n{BOLD}{'═'*60}{RESET}")
    print(f"{BOLD}  MULTI-AGENT ADAPTIVE LEARNING COPILOT — HACKATHON DEMO{RESET}")
    print(f"{BOLD}{'═'*60}{RESET}")
    print(f"  Scenario : {scenario_key}")
    print(f"  Mistake  : {YELLOW}{mistake_type}{RESET}")

    class NoopStorage:
        async def save_session(self, s): pass
        async def load_session(self, sid): return None

    # ── [1] Student profile ──────────────────────────
    hdr(1, "STUDENT PROFILE")
    profile = StudentProfile(
        name="Alex",
        current_topic=scenario["topic"],
        preferences=LearningPreferences(
            preferred_style="direct",
            responds_well_to_analogies=True,
            cognitive_load="medium",
        ),
    )
    profile.concept_mastery[scenario["topic"]] = ConceptMastery(
        concept_id=scenario["topic"],
        concept_name=scenario["topic"].replace("_", " ").title(),
        mastery_score=0.3,
        confidence_score=0.7,
    )
    label("Student", profile.name)
    label("Topic", scenario["topic"])
    label("Starting mastery", f"{0.3:.0%}")
    label("Self-confidence", f"{0.7:.0%}")
    label("Calibration error", f"{abs(0.7-0.3):.0%}  (overconfident)")

    # ── [2] Tutor teaches ────────────────────────────
    hdr(2, "TUTOR AGENT — Initial Explanation")
    tutor_out = await run_tutor_agent(
        concept=scenario["topic"],
        student_steps=None,
        eval_output=None,
        profile=profile,
        llm_client=client,
    )
    label("Strategy selected", tutor_out.teaching_strategy.upper())
    print()
    print(tutor_out.explanation)

    # ── [3] Student submits wrong steps ─────────────
    hdr(3, f"STUDENT ATTEMPT — {mistake_type.upper()} MISTAKE")
    label("Problem", scenario["problem"])
    print()
    print("  Student's steps:")
    for i, step in enumerate(wrong_steps, 1):
        print(f"    Step {i}: {step}")

    # ── [4] Step Evaluator ───────────────────────────
    hdr(4, "STEP EVALUATOR — Reasoning Analysis")
    info("Analyzing each step individually (not just the final answer)...")
    print()

    eval_out = await run_step_evaluator(
        problem=scenario["problem"],
        student_steps=wrong_steps,
        concept_context=scenario["topic"],
        student_profile=profile,
        llm_client=client,
    )

    for a in eval_out.step_analyses:
        if a.is_correct:
            ok(f"Step {a.step_number}: {a.step_text[:55]}")
            info(f"    {a.explanation}")
        else:
            err(f"Step {a.step_number}: {a.step_text[:55]}")
            print(f"    {RED}→ {a.explanation}{RESET}")

    print()
    label("First incorrect step", f"Step {eval_out.first_incorrect_step}" if eval_out.first_incorrect_step else "None")
    label("Mistake type", f"{YELLOW}{eval_out.primary_mistake_type}{RESET}")
    label("Final answer correct", f"{GREEN}Yes{RESET}" if eval_out.final_answer_correct else f"{RED}No{RESET}")
    label("Shows understanding", f"{GREEN}Yes{RESET}" if eval_out.shows_understanding else f"{RED}No{RESET}")
    label("Memorization risk", f"{YELLOW}Yes{RESET}" if eval_out.shows_memorization_risk else "No")
    print()
    label("Targeted intervention", eval_out.targeted_intervention)
    label("Next action", eval_out.suggested_next_action)

    # ── [5] Student Model update ─────────────────────
    hdr(5, "STUDENT MODEL — Update After Evaluation")
    mastery_before = profile.concept_mastery[scenario["topic"]].mastery_score
    profile = update_student_model_from_eval(profile, eval_out, scenario["topic"])
    mastery_after = profile.concept_mastery[scenario["topic"]].mastery_score

    direction = f"{RED}↓{RESET}" if mastery_after < mastery_before else f"{GREEN}↑{RESET}"
    label("Mastery", f"{mastery_before:.0%} → {mastery_after:.0%}  {direction}")
    label("Understanding mode", profile.understanding_mode)
    label("Misconceptions recorded", profile.concept_mastery[scenario["topic"]].misconception_tags or "none yet")
    label("Mistakes logged", len(profile.recent_mistakes))

    # ── [6] Adaptive Tutor ───────────────────────────
    hdr(6, "ADAPTIVE TUTOR — Strategy Adaptation")
    adapted = await run_tutor_agent(
        concept=scenario["topic"],
        student_steps=wrong_steps,
        eval_output=eval_out,
        profile=profile,
        llm_client=client,
    )
    label("NEW strategy (adapted)", f"{CYAN}{adapted.teaching_strategy.upper()}{RESET}")
    label("Adapted for", adapted.adapted_for or "general")
    print()
    print(adapted.explanation)

    # ── [7] Student reattempts correctly ────────────
    hdr(7, "STUDENT REATTEMPT — Correct Solution")
    print("  Student's corrected steps:")
    for i, step in enumerate(scenario["correct_steps"], 1):
        print(f"    Step {i}: {step}")
    print()

    eval_correct = await run_step_evaluator(
        problem=scenario["problem"],
        student_steps=scenario["correct_steps"],
        concept_context=scenario["topic"],
        student_profile=profile,
        llm_client=client,
    )
    label("All steps correct", f"{GREEN}Yes{RESET}" if eval_correct.final_answer_correct else f"{RED}No{RESET}")
    label("Shows understanding", f"{GREEN}Yes{RESET}" if eval_correct.shows_understanding else "No")

    # ── [8] Socratic challenge ───────────────────────
    hdr(8, "SOCRATIC AGENT — Verify Deep Understanding")
    socratic_out = await run_socratic_agent(
        concept=scenario["topic"],
        profile=profile,
        eval_output=eval_correct,
        conversation_history=[],
        llm_client=client,
    )
    label("Goal", socratic_out.primary_goal)
    print()
    for q in socratic_out.questions:
        print(f"  {BOLD}Question type:{RESET} {q.question_type}")
        print(f"  {BOLD}Question:{RESET}")
        print(f"    {CYAN}{q.question}{RESET}")
        label("  Breaks memorization", f"{YELLOW}Yes{RESET}" if q.reveals_if_memorizing else "No")
        print()

    # ── Summary ──────────────────────────────────────
    print(f"\n{BOLD}{'═'*60}{RESET}")
    print(f"{BOLD}  DEMO COMPLETE — SUMMARY{RESET}")
    print(f"{BOLD}{'═'*60}{RESET}")
    cm_final = profile.concept_mastery[scenario["topic"]]
    label("Student", f"{profile.name}  |  Topic: {scenario['topic']}")
    label("Mistake detected", f"{YELLOW}{mistake_type}{RESET}")
    label("First wrong step", f"Step {eval_out.first_incorrect_step}")
    label("Strategy adapted", f"direct → {adapted.teaching_strategy}")
    label("Verification type", f"{socratic_out.questions[0].question_type} questioning")
    label("Final mastery", f"{cm_final.mastery_score:.0%}")
    label("Agents used", "Step Evaluator → Student Model → Tutor → Socratic")
    print(f"\n  {DIM}Infrastructure: 0 external services | Model: Anthropic API only{RESET}")
    print()


if __name__ == "__main__":
    scenario = sys.argv[1] if len(sys.argv) > 1 else "linear_equations"
    mistake = sys.argv[2] if len(sys.argv) > 2 else "conceptual"
    asyncio.run(run_demo(scenario, mistake))
