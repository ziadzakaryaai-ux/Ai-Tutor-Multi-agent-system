"""
Orchestrator Agent
==================
Coordinates the core learning loop:
  Teach → Test → Evaluate → Diagnose → Adapt → Retest

Key design principle: The Orchestrator makes ROUTING decisions, not pedagogical ones.
- "Is understanding demonstrated?" → route to Advance
- "Is there a conceptual error?" → route to Tutor with 'analogy' strategy
- "Is mastery high but could be memorization?" → route to Socratic
- "Is student plateauing?" → route to strategy change or break

The Orchestrator is NOT an LLM. It's a deterministic state machine.
This is by design: LLM orchestrators are unpredictable in production.
"""
import json
from typing import Optional
from datetime import datetime, timezone
from models.schemas import (
    SessionState, StudentProfile, StepEvaluatorOutput,
    TutorOutput, SocraticOutput, EvaluationOutput
)
from agents.step_evaluator import run_step_evaluator, update_student_model_from_eval
from agents.tutor import run_tutor_agent
from agents.socratic import run_socratic_agent
from agents.evaluator import evaluate_understanding


class LearningOrchestrator:
    """
    The central controller. Stateless per call; state lives in SessionState.
    
    MVP version: sequential, synchronous routing.
    Production version: parallel agent execution where appropriate
                       (e.g., Step Evaluator + Student Model update can parallelize)
    """
    
    def __init__(self, llm_client, storage):
        self.llm = llm_client
        self.storage = storage  # MVP: JSON file. Production: PostgreSQL + Redis
    
    # ─────────────────────────────────────────
    # MAIN ENTRY POINT
    # ─────────────────────────────────────────
    async def process_student_response(
        self,
        session: SessionState,
        student_input: str,
        student_steps: list[str] | None = None,
    ) -> dict:
        """
        Process one student turn. Returns the system's response.
        
        This implements the full Teach→Test→Evaluate→Diagnose→Adapt loop
        for one interaction.
        """
        response = {"session_id": session.session_id}
        
        # ── Phase 1: Classify input ──────────────
        input_type = self._classify_input(student_input, student_steps)
        
        # ── Phase 2: Route based on phase ────────
        if session.current_phase == "teach":
            result = await self._handle_teach_phase(session, student_input)
        elif session.current_phase == "test":
            result = await self._handle_test_phase(session, student_input, student_steps)
        elif session.current_phase == "evaluate":
            result = await self._handle_evaluate_phase(session, student_input, student_steps)
        elif session.current_phase == "adapt":
            result = await self._handle_adapt_phase(session, student_input, student_steps)
        else:
            result = await self._handle_teach_phase(session, student_input)
        
        # ── Phase 3: Update history ────────────
        session.conversation_history.append({
            "role": "user",
            "content": student_input,
            "phase": session.current_phase,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        session.conversation_history.append({
            "role": "assistant",
            "content": result.get("response", ""),
            "phase": session.current_phase,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        session.loop_count += 1
        
        # ── Phase 4: Advance phase if appropriate ──
        session.current_phase = self._next_phase(session)
        
        # ── Phase 5: Persist ──────────────────────
        await self.storage.save_session(session)
        
        response.update(result)
        response["next_phase"] = session.current_phase
        response["student_state"] = self._get_student_state_summary(session.student_profile)
        
        return response
    
    # ─────────────────────────────────────────
    # PHASE HANDLERS
    # ─────────────────────────────────────────
    async def _handle_teach_phase(
        self, session: SessionState, student_input: str
    ) -> dict:
        """Initial teaching. No evaluation yet — just explain."""
        tutor_out = await run_tutor_agent(
            concept=session.student_profile.current_topic,
            student_steps=None,
            eval_output=None,
            profile=session.student_profile,
            llm_client=self.llm,
        )
        session.last_tutor_output = tutor_out
        
        return {
            "type": "teaching",
            "response": tutor_out.explanation,
            "strategy_used": tutor_out.teaching_strategy,
            "adapted_for": tutor_out.adapted_for,
            "follow_up": tutor_out.follow_up_prompt,
        }
    
    async def _handle_test_phase(
        self, session: SessionState, student_input: str, student_steps: list[str] | None
    ) -> dict:
        """Student has attempted a problem. Run Step Evaluator."""
        if not student_steps:
            # Student gave answer without showing steps — request them
            return {
                "type": "request_steps",
                "response": (
                    "I can see your answer, but I need to understand your reasoning. "
                    "Can you walk me through each step of how you got there? "
                    "Even if you're confident, showing the steps helps me give you better feedback."
                )
            }
        
        # Run the key agent
        eval_out = await run_step_evaluator(
            problem=session.current_problem or student_input,
            student_steps=student_steps,
            concept_context=session.student_profile.current_topic,
            student_profile=session.student_profile,
            llm_client=self.llm,
        )
        session.last_step_eval = eval_out
        
        # Update student model
        session.student_profile = update_student_model_from_eval(
            session.student_profile,
            eval_out,
            session.student_profile.current_topic
        )
        
        # Track streaks
        if eval_out.final_answer_correct:
            session.consecutive_correct += 1
            session.consecutive_wrong = 0
        else:
            session.consecutive_wrong += 1
            session.consecutive_correct = 0

        # Run holistic evaluation — stores recommended_action for _next_phase
        session.last_eval = evaluate_understanding(session)

        # Generate response based on evaluation
        response = await self._generate_test_response(session, eval_out)
        
        return {
            "type": "evaluation",
            "response": response,
            "step_analysis": self._format_step_analysis(eval_out),
            "first_incorrect_step": eval_out.first_incorrect_step,
            "mistake_type": eval_out.primary_mistake_type,
            "next_action": eval_out.suggested_next_action,
        }
    
    async def _handle_evaluate_phase(
        self, session: SessionState, student_input: str, student_steps: list[str] | None
    ) -> dict:
        """
        Deep evaluation phase: check if understanding is real.
        Uses Socratic questioning when student seems to be getting it right.
        """
        # If recent eval showed correct understanding → Socratic challenge
        if session.last_step_eval and session.last_step_eval.shows_understanding:
            socratic_out = await run_socratic_agent(
                concept=session.student_profile.current_topic,
                profile=session.student_profile,
                eval_output=session.last_step_eval,
                conversation_history=session.conversation_history,
                llm_client=self.llm,
            )
            session.last_socratic_output = socratic_out

            # Re-evaluate now that we have the student's Socratic response;
            # the evaluator scores response depth via the socratic_response arg.
            session.last_eval = evaluate_understanding(session, socratic_response=student_input)

            # Format the Socratic challenge
            questions = [q.question for q in socratic_out.questions]
            response = (
                "Good work on that solution. Let me push your understanding further:\n\n"
                + "\n\n".join(f"**{q}**" for q in questions)
            )
            
            return {
                "type": "socratic_challenge",
                "response": response,
                "goal": socratic_out.primary_goal,
                "question_types": [q.question_type for q in socratic_out.questions],
            }
        
        # If memorization detected → intervention
        elif session.last_step_eval and session.last_step_eval.shows_memorization_risk:
            return await self._handle_memorization_intervention(session)
        
        # Default: standard evaluation with tutor
        return await self._handle_test_phase(session, student_input, student_steps)
    
    async def _handle_adapt_phase(
        self, session: SessionState, student_input: str, student_steps: list[str] | None
    ) -> dict:
        """
        Adaptation after diagnosis. Change strategy and reteach.
        Called when student is stuck or plateau is detected.
        """
        tutor_out = await run_tutor_agent(
            concept=session.student_profile.current_topic,
            student_steps=student_steps,
            eval_output=session.last_step_eval,
            profile=session.student_profile,
            llm_client=self.llm,
        )
        session.last_tutor_output = tutor_out
        
        return {
            "type": "adaptation",
            "response": tutor_out.explanation,
            "strategy_changed_to": tutor_out.teaching_strategy,
            "adapted_for": tutor_out.adapted_for,
        }
    
    # ─────────────────────────────────────────
    # ROUTING LOGIC (the state machine)
    # ─────────────────────────────────────────
    def _next_phase(self, session: SessionState) -> str:
        """
        Deterministic phase transitions.
        This is the core of the adaptive system.

        Priority order:
          1. EvaluationAgent recommendation  (highest signal quality)
          2. Consecutive-wrong plateau guard
          3. High-mastery correct-streak → Socratic challenge
          4. Post-adapt → retest
          5. Post-evaluate understanding confirmed → teach next concept
          6. Default phase-flow table
        """
        eval = session.last_step_eval
        last_eval = session.last_eval          # EvaluationOutput | None
        profile = session.student_profile
        cm = profile.concept_mastery.get(profile.current_topic)
        mastery = cm.mastery_score if cm else 0.0

        # ── 1. Consult the Evaluation Agent recommendation ──────────────
        if last_eval is not None:
            rec = last_eval.recommended_action

            if rec == "take_break":
                # Student is fatigued / focus has collapsed → pause teaching,
                # return to teach phase so the next turn starts fresh.
                profile.learning_plateau_detected = True
                return "adapt"          # adapt surfaces a break suggestion

            if rec == "change_strategy":
                # Plateau confirmed by the evaluator — adapt strategy.
                profile.learning_plateau_detected = True
                return "adapt"

            if rec == "advance":
                # Deep understanding confirmed — move to next concept.
                return "teach"

            # "retest" and "continue" fall through to the streak/mastery checks
            # below so existing logic still controls fine-grained routing.

        # ── 2. Consecutive-wrong plateau guard ──────────────────────────
        if session.consecutive_wrong >= 3:
            profile.learning_plateau_detected = True
            return "adapt"

        # ── 3. High mastery + correct streak → Socratic challenge ───────
        if mastery > 0.7 and session.consecutive_correct >= 2:
            return "evaluate"

        # ── 4. Post-adapt → retest ───────────────────────────────────────
        if session.current_phase == "adapt":
            return "test"

        # ── 5. Post-evaluate deep understanding → advance ────────────────
        if session.current_phase == "evaluate" and eval and eval.shows_understanding:
            return "teach"

        # ── 6. Default phase-flow table ──────────────────────────────────
        phase_flow = {
            "teach":    "test",
            "test":     "evaluate",
            "evaluate": "diagnose" if (eval and not eval.final_answer_correct) else "test",
            "diagnose": "adapt",
        }
        return phase_flow.get(session.current_phase, "test")
    
    # ─────────────────────────────────────────
    # HELPERS
    # ─────────────────────────────────────────
    async def _generate_test_response(
        self, session: SessionState, eval_out: StepEvaluatorOutput
    ) -> str:
        """Generate the response text for a test evaluation."""
        if eval_out.final_answer_correct and eval_out.shows_understanding:
            return (
                f"✓ Correct, and your reasoning is sound. "
                f"I can see you understand why each step works.\n\n"
                f"{eval_out.targeted_intervention if eval_out.targeted_intervention else ''}"
            ).strip()
        
        elif eval_out.final_answer_correct and not eval_out.shows_understanding:
            return (
                f"Your answer is correct, but let me check if the reasoning is solid. "
                f"Your approach in step {eval_out.first_incorrect_step} concerns me — "
                f"it worked here, but might not in a different problem.\n\n"
                f"{eval_out.targeted_intervention}"
            )
        
        elif not eval_out.final_answer_correct:
            step_msg = (
                f"Your reasoning was solid until step {eval_out.first_incorrect_step}. "
                if eval_out.first_incorrect_step
                else "Let me trace through your reasoning. "
            )
            type_msg = {
                "conceptual": "This looks like a conceptual issue — not just a calculation error.",
                "procedural": "You have the right idea, but the procedure went wrong.",
                "careless": "This looks like a careless slip — your approach was right.",
                "knowledge_gap": "It seems there's a prerequisite concept we should revisit.",
                "confidence_mismatch": None,
            }.get(eval_out.primary_mistake_type or "", "")
            
            return f"{step_msg}{type_msg}\n\n{eval_out.targeted_intervention}".strip()
        
        return eval_out.targeted_intervention
    
    async def _handle_memorization_intervention(self, session: SessionState) -> dict:
        """Special handling when student is pattern-matching."""
        socratic_out = await run_socratic_agent(
            concept=session.student_profile.current_topic,
            profile=session.student_profile,
            eval_output=session.last_step_eval,
            conversation_history=session.conversation_history,
            llm_client=self.llm,
        )
        
        # Find transfer question specifically
        transfer_qs = [q for q in socratic_out.questions if q.question_type == "transfer"]
        target_q = transfer_qs[0] if transfer_qs else socratic_out.questions[0]
        
        return {
            "type": "memorization_intervention",
            "response": (
                "Your answer is correct, but I want to make sure you understand the *why*, "
                "not just the *how*. Try this:\n\n"
                f"**{target_q.question}**\n\n"
                "Take your time — think about the underlying principle, not the procedure."
            ),
            "goal": "break_memorization_pattern",
        }
    
    def _classify_input(self, student_input: str, student_steps: list[str] | None) -> str:
        if student_steps:
            return "solution_with_steps"
        if "?" in student_input:
            return "question"
        if len(student_input) < 20:
            return "short_answer"
        return "explanation"
    
    def _format_step_analysis(self, eval_out: StepEvaluatorOutput) -> list[dict]:
        return [
            {
                "step": a.step_number,
                "text": a.step_text,
                "correct": a.is_correct,
                "mistake_type": a.mistake_type,
                "note": a.explanation,
            }
            for a in eval_out.step_analyses
        ]
    
    def _get_student_state_summary(self, profile: StudentProfile) -> dict:
        cm = profile.concept_mastery.get(profile.current_topic, {})
        return {
            "mastery": getattr(cm, 'mastery_score', 0),
            "understanding_mode": profile.understanding_mode,
            "recent_mistakes": len(profile.recent_mistakes),
            "questions_attempted": profile.questions_attempted,
            "accuracy": (
                profile.questions_correct / profile.questions_attempted
                if profile.questions_attempted > 0 else 0
            ),
            "plateau_detected": profile.learning_plateau_detected,
        }
