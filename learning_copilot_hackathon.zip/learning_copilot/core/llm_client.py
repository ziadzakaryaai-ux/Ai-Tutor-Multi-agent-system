"""
LLM Client Factory
==================
Single module that returns an async LLM client to every agent.

ALL agents call:
    response = await llm_client.messages.create(
        model=..., max_tokens=..., system=..., messages=[...]
    )

This module makes that call work identically whether the backend is:
  - Azure OpenAI  (AZURE_OPENAI_ENDPOINT set)
  - Anthropic API (ANTHROPIC_API_KEY set, no Azure endpoint)

No agent, orchestrator, or test file needs to know which backend is active.
Model name aliasing maps Claude model strings → Azure deployment names
so agent code never changes when the backend changes.

Environment variables
─────────────────────
Azure OpenAI (required when using Azure):
  AZURE_OPENAI_ENDPOINT       https://<resource>.openai.azure.com/
  AZURE_OPENAI_API_KEY        <key>
  AZURE_OPENAI_API_VERSION    2025-01-01-preview  (optional, has default)

  Per-role deployment names (optional — defaults shown):
  AZURE_DEPLOYMENT_EVALUATOR  gpt-4o              ← Step Evaluator (best reasoning)
  AZURE_DEPLOYMENT_TUTOR      gpt-4o-mini         ← Tutor (fast + cheap)
  AZURE_DEPLOYMENT_SOCRATIC   gpt-4o-mini         ← Socratic Agent
  AZURE_DEPLOYMENT_ASSESSMENT gpt-4o-mini         ← Assessment Agent

Anthropic (fallback / local dev):
  ANTHROPIC_API_KEY           sk-ant-...

Selection logic:
  AZURE_OPENAI_ENDPOINT set  →  Azure OpenAI
  else                        →  Anthropic
"""
from __future__ import annotations

import os
from typing import Any
from core.logging import get_logger

logger = get_logger(__name__)

# ── Azure deployment name defaults ─────────────────────
# Populated after MODEL_* constants are defined (see below).
# Keys are the Claude model strings agents pass to messages.create();
# values are the Azure deployment names they map to.
_AZURE_DEPLOYMENTS: dict[str, str] = {}  # filled in _init_azure_deployments()

_AZURE_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2025-01-01-preview")

# ── Public model name constants ─────────────────────────
# Agents import these instead of hard-coding model strings.
# Switching models for a demo or backend swap is now a single
# env-var change — no grep-and-replace across agent files.
#
# Override via environment (Anthropic backend only; Azure always
# uses the deployment mapping in _AZURE_DEPLOYMENTS above):
#   MODEL_EVALUATOR   default: claude-opus-4-5        (best reasoning)
#   MODEL_TUTOR       default: claude-haiku-4-5-20251001  (fast + cheap)
MODEL_EVALUATOR: str = os.getenv("MODEL_EVALUATOR", "claude-opus-4-5")
MODEL_TUTOR: str     = os.getenv("MODEL_TUTOR",     "claude-haiku-4-5-20251001")


def _init_azure_deployments() -> dict[str, str]:
    """
    Build the Claude model string → Azure deployment name mapping.
    Called once at module load so it picks up MODEL_* constants and env overrides.
    If MODEL_EVALUATOR or MODEL_TUTOR are overridden via env, the mapping
    stays correct without any other change.
    """
    return {
        MODEL_EVALUATOR: os.getenv("AZURE_DEPLOYMENT_EVALUATOR", "gpt-4o"),
        MODEL_TUTOR:     os.getenv("AZURE_DEPLOYMENT_TUTOR",     "gpt-4o-mini"),
    }


_AZURE_DEPLOYMENTS.update(_init_azure_deployments())


# ─────────────────────────────────────────────────────────
# AZURE OPENAI ADAPTER
# ─────────────────────────────────────────────────────────
class _AzureMessagesAdapter:
    """
    Wraps openai.AsyncAzureOpenAI so every agent can call:
        await client.messages.create(model=..., system=..., messages=[...])

    Translates:
      - Anthropic `system` kwarg  → OpenAI system message prepended to messages
      - Anthropic model string    → Azure deployment name via _AZURE_DEPLOYMENTS
      - OpenAI response           → object with .content[0].text (Anthropic shape)
    """
    def __init__(self, azure_client):
        self._client = azure_client

    async def create(
        self,
        *,
        model: str,
        max_tokens: int,
        messages: list[dict],
        system: str | None = None,
        **kwargs,
    ) -> Any:
        deployment = _AZURE_DEPLOYMENTS.get(model, os.getenv("AZURE_DEPLOYMENT_TUTOR", "gpt-4o-mini"))

        # Build OpenAI message list
        oai_messages: list[dict] = []
        if system:
            oai_messages.append({"role": "system", "content": system})
        oai_messages.extend(messages)

        logger.info(
            "azure_llm_call",
            extra={"deployment": deployment, "model_requested": model, "max_tokens": max_tokens},
        )

        response = await self._client.chat.completions.create(
            model=deployment,
            messages=oai_messages,
            max_tokens=max_tokens,
        )

        # Wrap to Anthropic shape: response.content[0].text
        text = response.choices[0].message.content or ""
        return _AnthropicShapedResponse(text)


class _AzureClientWrapper:
    """Top-level wrapper — agents access client.messages.create(...)."""
    def __init__(self, azure_client):
        self.messages = _AzureMessagesAdapter(azure_client)


class _AnthropicShapedResponse:
    """Minimal response object that looks like anthropic.types.Message."""
    def __init__(self, text: str):
        self.content = [_ContentBlock(text)]


class _ContentBlock:
    def __init__(self, text: str):
        self.text = text


# ─────────────────────────────────────────────────────────
# FACTORY
# ─────────────────────────────────────────────────────────
def build_llm_client():
    """
    Return the active LLM client.

    Called once at startup in api/main.py and demo.py.
    Returns a client whose interface is identical regardless of backend.
    """
    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "").strip()

    if azure_endpoint:
        try:
            from openai import AsyncAzureOpenAI
        except ImportError:
            raise ImportError(
                "AZURE_OPENAI_ENDPOINT is set but 'openai' package is not installed.\n"
                "Run: pip install openai>=1.30"
            )

        api_key = os.getenv("AZURE_OPENAI_API_KEY", "")
        if not api_key:
            raise ValueError(
                "AZURE_OPENAI_ENDPOINT is set but AZURE_OPENAI_API_KEY is missing."
            )

        azure_raw = AsyncAzureOpenAI(
            azure_endpoint=azure_endpoint,
            api_key=api_key,
            api_version=_AZURE_API_VERSION,
        )
        logger.info(
            "llm_backend_selected",
            extra={
                "backend": "azure_openai",
                "endpoint": azure_endpoint,
                "api_version": _AZURE_API_VERSION,
                "evaluator_deployment": _AZURE_DEPLOYMENTS.get(MODEL_EVALUATOR),
                "tutor_deployment": _AZURE_DEPLOYMENTS.get(MODEL_TUTOR),
            },
        )
        return _AzureClientWrapper(azure_raw)

    # ── Anthropic fallback ───────────────────────────────
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        raise ValueError(
            "No LLM backend configured.\n"
            "Set AZURE_OPENAI_ENDPOINT + AZURE_OPENAI_API_KEY  (Azure)\n"
            "  or ANTHROPIC_API_KEY  (direct Anthropic)"
        )

    try:
        import anthropic
    except ImportError:
        raise ImportError("'anthropic' package not installed. Run: pip install anthropic")

    client = anthropic.AsyncAnthropic(api_key=api_key)
    logger.info("llm_backend_selected", extra={"backend": "anthropic"})
    return client
