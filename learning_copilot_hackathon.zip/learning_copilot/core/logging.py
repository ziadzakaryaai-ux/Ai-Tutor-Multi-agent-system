"""
Logging & Middleware
====================
Structured JSON logging for every API request and every agent call.

Production-ready pattern: every log entry includes session_id, agent name,
latency, model used, and outcome. This feeds directly into Azure Monitor,
Datadog, or any structured log system.

Usage:
  from core.logging import get_logger, log_agent_call
  logger = get_logger(__name__)
  logger.info("step_eval_complete", extra={"session_id": "abc", "latency_ms": 142})
"""
import time
import json
import logging
import uuid
from typing import Callable
from functools import wraps

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware


# ─────────────────────────────────────────────
# STRUCTURED JSON FORMATTER
# ─────────────────────────────────────────────
class JSONFormatter(logging.Formatter):
    """
    Emits every log record as a single JSON line.
    Compatible with Azure Monitor, CloudWatch, Datadog, and Splunk.
    """
    def format(self, record: logging.LogRecord) -> str:
        base = {
            "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S.%f"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        # Merge any extra fields passed via extra={...}
        for key, val in record.__dict__.items():
            if key not in (
                "args", "created", "exc_info", "exc_text", "filename",
                "funcName", "id", "levelname", "levelno", "lineno",
                "message", "module", "msecs", "msg", "name", "pathname",
                "process", "processName", "relativeCreated", "stack_info",
                "thread", "threadName", "taskName",
            ):
                base[key] = val
        if record.exc_info:
            base["exception"] = self.formatException(record.exc_info)
        return json.dumps(base, default=str)


def get_logger(name: str) -> logging.Logger:
    """Get a structured logger. Call once per module at the top level."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(JSONFormatter())
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        logger.propagate = False
    return logger


# ─────────────────────────────────────────────
# REQUEST LOGGING MIDDLEWARE
# ─────────────────────────────────────────────
class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """
    Logs every HTTP request with method, path, status, and latency.
    Attaches a request_id to every response header for tracing.
    """
    def __init__(self, app, logger_name: str = "api.requests"):
        super().__init__(app)
        self.logger = get_logger(logger_name)

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = str(uuid.uuid4())[:8]
        start = time.perf_counter()

        # Attach request_id to request state for downstream use
        request.state.request_id = request_id

        try:
            response = await call_next(request)
            latency_ms = (time.perf_counter() - start) * 1000
            self.logger.info(
                "http_request",
                extra={
                    "request_id": request_id,
                    "method": request.method,
                    "path": request.url.path,
                    "status_code": response.status_code,
                    "latency_ms": round(latency_ms, 2),
                    "client_ip": request.client.host if request.client else "unknown",
                }
            )
            response.headers["X-Request-ID"] = request_id
            return response
        except Exception as exc:
            latency_ms = (time.perf_counter() - start) * 1000
            self.logger.error(
                "http_request_error",
                extra={
                    "request_id": request_id,
                    "method": request.method,
                    "path": request.url.path,
                    "error": str(exc),
                    "latency_ms": round(latency_ms, 2),
                }
            )
            raise


# ─────────────────────────────────────────────
# AGENT CALL DECORATOR
# ─────────────────────────────────────────────
def log_agent_call(agent_name: str, model: str = "unknown"):
    """
    Decorator that wraps any async agent function and logs:
    - Start (with session_id if available)
    - Completion (with latency and outcome)
    - Errors (with full traceback context)

    Usage:
        @log_agent_call("step_evaluator", model="claude-opus-4-5")
        async def run_step_evaluator(...):
            ...
    """
    logger = get_logger(f"agent.{agent_name}")

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Try to extract session_id from profile arg
            session_id = _extract_session_id(args, kwargs)
            call_id = str(uuid.uuid4())[:8]
            start = time.perf_counter()

            logger.info(
                f"{agent_name}_start",
                extra={
                    "agent": agent_name,
                    "model": model,
                    "call_id": call_id,
                    "session_id": session_id,
                }
            )

            try:
                result = await func(*args, **kwargs)
                latency_ms = (time.perf_counter() - start) * 1000
                logger.info(
                    f"{agent_name}_complete",
                    extra={
                        "agent": agent_name,
                        "model": model,
                        "call_id": call_id,
                        "session_id": session_id,
                        "latency_ms": round(latency_ms, 2),
                        "outcome": "success",
                    }
                )
                return result
            except Exception as exc:
                latency_ms = (time.perf_counter() - start) * 1000
                logger.error(
                    f"{agent_name}_error",
                    extra={
                        "agent": agent_name,
                        "model": model,
                        "call_id": call_id,
                        "session_id": session_id,
                        "latency_ms": round(latency_ms, 2),
                        "error": str(exc),
                        "error_type": type(exc).__name__,
                    }
                )
                raise
        return wrapper
    return decorator


def _extract_session_id(args, kwargs) -> str:
    """Best-effort extraction of session_id from function arguments."""
    # Check kwargs
    if "session_id" in kwargs:
        return kwargs["session_id"]
    # Check for StudentProfile in args
    for arg in args:
        if hasattr(arg, "session_id"):
            return arg.session_id
        if hasattr(arg, "student_profile") and hasattr(arg.student_profile, "session_id"):
            return arg.student_profile.session_id
    return "unknown"


# ─────────────────────────────────────────────
# LLM RESPONSE REPAIR UTILITY
# ─────────────────────────────────────────────
def safe_parse_json(raw: str, context: str = "unknown") -> dict:
    """
    Robustly parse JSON from LLM output.

    LLMs sometimes return:
    - ```json ... ``` fenced blocks
    - Leading explanation text before the JSON
    - Trailing text after the closing brace
    - Single-quoted keys (invalid JSON)

    This handles all of them. Raises ValueError with context if it truly fails.
    """
    logger = get_logger("llm.parser")

    text = raw.strip()

    # Strip markdown fences
    if "```" in text:
        parts = text.split("```")
        for part in parts:
            stripped = part.strip()
            if stripped.startswith("json"):
                stripped = stripped[4:].strip()
            if stripped.startswith("{") or stripped.startswith("["):
                text = stripped
                break

    # Find the first { or [ and last } or ]
    start_brace = text.find("{")
    start_bracket = text.find("[")

    if start_brace == -1 and start_bracket == -1:
        raise ValueError(f"[{context}] No JSON object or array found in LLM output: {raw[:200]}")

    if start_brace != -1 and (start_bracket == -1 or start_brace <= start_bracket):
        start = start_brace
        end = text.rfind("}") + 1
    else:
        start = start_bracket
        end = text.rfind("]") + 1

    if end == 0:
        raise ValueError(f"[{context}] Unclosed JSON in LLM output: {raw[:200]}")

    json_text = text[start:end]

    try:
        return json.loads(json_text)
    except json.JSONDecodeError as e:
        # Last resort: log and re-raise with context
        logger.warning(
            "json_parse_retry",
            extra={
                "context": context,
                "error": str(e),
                "raw_snippet": raw[:300],
            }
        )
        raise ValueError(f"[{context}] JSON parse failed: {e}\nRaw: {raw[:300]}")
