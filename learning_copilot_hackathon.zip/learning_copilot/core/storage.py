"""
Storage Layer
=============
MVP: JSON file storage (zero infrastructure dependency)
Production: PostgreSQL + Redis (swap via interface)

Interface contract:
  save_session(session: SessionState) -> None
  load_session(session_id: str) -> SessionState | None
  save_student_profile(profile: StudentProfile) -> None
  load_student_profile(student_id: str) -> StudentProfile | None
  list_sessions(student_id: str) -> list[str]
  archive_session(session_id: str) -> None

Any storage backend that satisfies this interface is production-ready.
"""
import json
import asyncio
from pathlib import Path
from typing import Optional
from datetime import datetime, timezone

from models.schemas import SessionState, StudentProfile


class JSONFileStorage:
    """
    In-process JSON storage. Survives restarts. Zero infra.
    Production upgrade: replace with PostgresStorage below.
    """
    def __init__(self, data_dir: str = "./data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._cache: dict[str, SessionState] = {}

    async def save_session(self, session: SessionState) -> None:
        self._cache[session.session_id] = session
        path = self.data_dir / f"session_{session.session_id}.json"
        path.write_text(session.model_dump_json(indent=2))

    async def load_session(self, session_id: str) -> Optional[SessionState]:
        if session_id in self._cache:
            return self._cache[session_id]
        path = self.data_dir / f"session_{session_id}.json"
        if path.exists():
            session = SessionState.model_validate_json(path.read_text())
            self._cache[session_id] = session
            return session
        return None

    async def save_student_profile(self, profile: StudentProfile) -> None:
        path = self.data_dir / f"student_{profile.student_id}.json"
        path.write_text(profile.model_dump_json(indent=2))

    async def load_student_profile(self, student_id: str) -> Optional[StudentProfile]:
        path = self.data_dir / f"student_{student_id}.json"
        if path.exists():
            return StudentProfile.model_validate_json(path.read_text())
        return None

    async def list_sessions(self, student_id: str) -> list[str]:
        """Return session IDs that belong to *student_id* only.

        Strategy (avoids full deserialisation):
          1. If the session is already in the in-process cache, read
             student_id directly from the cached object — O(1).
          2. Otherwise open the file and parse just enough JSON to
             extract ``student_profile.student_id`` — we use a raw
             json.loads so we never construct a heavy SessionState object
             for sessions we may immediately discard.
        """
        result: list[str] = []
        for path in self.data_dir.glob("session_*.json"):
            sid = path.stem.replace("session_", "")
            # Fast path: already in cache
            if sid in self._cache:
                if self._cache[sid].student_profile.student_id == student_id:
                    result.append(sid)
                continue
            # Slow path: read raw JSON, extract only the nested field
            try:
                raw = json.loads(path.read_text())
                stored_student_id = (
                    raw.get("student_profile", {}).get("student_id", "")
                )
                if stored_student_id == student_id:
                    result.append(sid)
            except Exception:
                # Corrupt / unreadable file — skip silently
                continue
        return result

    async def archive_session(self, session_id: str) -> None:
        archive_dir = self.data_dir / "archive"
        archive_dir.mkdir(exist_ok=True)
        src = self.data_dir / f"session_{session_id}.json"
        if src.exists():
            dst = archive_dir / f"session_{session_id}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
            src.rename(dst)
        self._cache.pop(session_id, None)


class InMemoryStorage:
    """
    Pure in-memory storage for tests and CI.
    No disk I/O, no files. Resets on process restart.
    """
    def __init__(self):
        self._sessions: dict[str, SessionState] = {}
        self._profiles: dict[str, StudentProfile] = {}

    async def save_session(self, session: SessionState) -> None:
        self._sessions[session.session_id] = session

    async def load_session(self, session_id: str) -> Optional[SessionState]:
        return self._sessions.get(session_id)

    async def save_student_profile(self, profile: StudentProfile) -> None:
        self._profiles[profile.student_id] = profile

    async def load_student_profile(self, student_id: str) -> Optional[StudentProfile]:
        return self._profiles.get(student_id)

    async def list_sessions(self, student_id: str) -> list[str]:
        return [
            sid
            for sid, session in self._sessions.items()
            if session.student_profile.student_id == student_id
        ]

    async def archive_session(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)


# ─────────────────────────────────────────────
# PRODUCTION STUB (shows the upgrade path)
# ─────────────────────────────────────────────
class PostgresStorage:
    """
    Production storage stub.

    Upgrade instructions:
    1. pip install asyncpg sqlalchemy[asyncio]
    2. Set DATABASE_URL env var
    3. Uncomment and implement below
    4. Swap JSONFileStorage → PostgresStorage in api/main.py

    Tables needed:
      sessions      (session_id PK, student_id FK, data JSONB, updated_at)
      students      (student_id PK, data JSONB, updated_at)
      session_log   (id PK, session_id FK, turn INT, role TEXT, content TEXT, metadata JSONB)
    """

    def __init__(self, database_url: str):
        self.database_url = database_url
        # self.pool = await asyncpg.create_pool(database_url)
        raise NotImplementedError(
            "PostgresStorage is a production stub. "
            "Use JSONFileStorage for MVP. "
            "See comments above for upgrade instructions."
        )

    async def save_session(self, session: SessionState) -> None:
        raise NotImplementedError

    async def load_session(self, session_id: str) -> Optional[SessionState]:
        raise NotImplementedError

    async def save_student_profile(self, profile: StudentProfile) -> None:
        raise NotImplementedError

    async def load_student_profile(self, student_id: str) -> Optional[StudentProfile]:
        raise NotImplementedError

    async def list_sessions(self, student_id: str) -> list[str]:
        raise NotImplementedError

    async def archive_session(self, session_id: str) -> None:
        raise NotImplementedError


# ─────────────────────────────────────────────
# AZURE COSMOS DB STORAGE  (production backend)
# ─────────────────────────────────────────────
class CosmosDBStorage:
    """
    Production storage using Azure Cosmos DB (NoSQL API).

    Same 5-method async interface as JSONFileStorage — swap with zero
    changes to any agent or orchestrator code.

    Required environment variables:
      COSMOS_ENDPOINT   https://<account>.documents.azure.com:443/
      COSMOS_KEY        <primary or secondary key>
      COSMOS_DATABASE   learning_copilot          (created if absent)
      COSMOS_CONTAINER  sessions                  (created if absent)

    Throughput: 400 RU/s autoscale by default (set COSMOS_THROUGHPUT to override).

    Install: pip install azure-cosmos
    """

    def __init__(self):
        try:
            from azure.cosmos.aio import CosmosClient
            from azure.cosmos import PartitionKey
        except ImportError:
            raise ImportError(
                "azure-cosmos package not installed.\n"
                "Run: pip install azure-cosmos"
            )

        import os
        endpoint  = os.environ["COSMOS_ENDPOINT"]
        key       = os.environ["COSMOS_KEY"]
        db_name   = os.getenv("COSMOS_DATABASE",  "learning_copilot")
        cont_name = os.getenv("COSMOS_CONTAINER", "sessions")
        throughput = int(os.getenv("COSMOS_THROUGHPUT", "400"))

        self._client    = CosmosClient(url=endpoint, credential=key)
        self._db_name   = db_name
        self._cont_name = cont_name
        self._throughput = throughput
        self._PartitionKey = PartitionKey
        self._container = None   # lazy-initialised in _get_container()

    async def _get_container(self):
        if self._container is not None:
            return self._container
        db = await self._client.create_database_if_not_exists(id=self._db_name)
        self._container = await db.create_container_if_not_exists(
            id=self._cont_name,
            partition_key=self._PartitionKey(path="/partition_key"),
            offer_throughput=self._throughput,
        )
        return self._container

    # ── sessions ─────────────────────────────────────────
    async def save_session(self, session) -> None:
        container = await self._get_container()
        doc = {
            "id":            session.session_id,
            "partition_key": "session",
            "type":          "session",
            # Stored at the top level so list_sessions can filter cheaply
            # without deserialising the full nested `data` blob.
            "student_id":    session.student_profile.student_id,
            "data":          session.model_dump(mode="json"),
        }
        await container.upsert_item(doc)

    async def load_session(self, session_id: str):
        container = await self._get_container()
        try:
            item = await container.read_item(item=session_id, partition_key="session")
            from models.schemas import SessionState
            return SessionState.model_validate(item["data"])
        except Exception:
            return None

    # ── student profiles ─────────────────────────────────
    async def save_student_profile(self, profile) -> None:
        container = await self._get_container()
        doc = {
            "id":            profile.student_id,
            "partition_key": "student",
            "type":          "student",
            "data":          profile.model_dump(mode="json"),
        }
        await container.upsert_item(doc)

    async def load_student_profile(self, student_id: str):
        container = await self._get_container()
        try:
            item = await container.read_item(item=student_id, partition_key="student")
            from models.schemas import StudentProfile
            return StudentProfile.model_validate(item["data"])
        except Exception:
            return None

    # ── utilities ────────────────────────────────────────
    async def list_sessions(self, student_id: str) -> list[str]:
        container = await self._get_container()
        # `student_id` is now a top-level field written by save_session.
        # Parameterised query avoids injection and is indexed by Cosmos.
        query = (
            "SELECT c.id FROM c "
            "WHERE c.type = 'session' AND c.student_id = @student_id"
        )
        params = [{"name": "@student_id", "value": student_id}]
        items = [
            item
            async for item in container.query_items(
                query=query, parameters=params
            )
        ]
        return [i["id"] for i in items]

    async def archive_session(self, session_id: str) -> None:
        """Move to an 'archived' partition instead of deleting."""
        container = await self._get_container()
        try:
            item = await container.read_item(item=session_id, partition_key="session")
            item["partition_key"] = "session_archived"
            await container.upsert_item(item)
            await container.delete_item(item=session_id, partition_key="session")
        except Exception:
            pass


def build_storage():
    """
    Return the active storage backend chosen by environment variable.

    STORAGE_BACKEND=cosmos   →  CosmosDBStorage  (requires COSMOS_ENDPOINT + COSMOS_KEY)
    STORAGE_BACKEND=json     →  JSONFileStorage   (default, zero infra)
    STORAGE_BACKEND=memory   →  InMemoryStorage   (tests / CI)

    All backends expose the same 5-method async interface — swap with no
    changes to any agent, orchestrator, or test.
    """
    import os
    backend = os.getenv("STORAGE_BACKEND", "json").lower().strip()

    if backend == "cosmos":
        return CosmosDBStorage()
    elif backend == "memory":
        return InMemoryStorage()
    else:
        data_dir = os.getenv("DATA_DIR", "./data")
        return JSONFileStorage(data_dir=data_dir)
