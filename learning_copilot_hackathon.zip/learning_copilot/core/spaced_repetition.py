"""
Spaced Repetition Scheduler
============================
Ebbinghaus-inspired retention model for long-term memory management.

This is a production extension component — not required for MVP,
but wired into the Student Model for when episodic memory is enabled.

Algorithm:
  Retention R = mastery * exp(-elapsed_hours / stability)
  Stability   = BASE_STABILITY * (1 + mastery * STABILITY_SCALE)
  Next review = now + stability * TARGET_RETENTION_THRESHOLD hours

When R drops below REVIEW_THRESHOLD, the concept is scheduled for review.
Higher mastery concepts have higher stability (decay slower).
"""
import math
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass
from models.schemas import StudentProfile, ConceptMastery


# ── config ──────────────────────────────────────────────
BASE_STABILITY_HOURS = 24      # Minimum: 1 day at zero mastery
STABILITY_SCALE      = 168     # Max extra: 7 days at full mastery
REVIEW_THRESHOLD     = 0.65    # Schedule review when retention drops below 65%
CRITICAL_THRESHOLD   = 0.40    # Urgent: retention below 40% = forgotten


@dataclass
class ReviewItem:
    concept_id:      str
    concept_name:    str
    mastery:         float
    retention:       float
    hours_overdue:   float       # Negative = not yet due
    urgency:         str         # "critical" | "due" | "upcoming" | "ok"
    next_review_at:  datetime


def compute_retention(cm: ConceptMastery, now: datetime | None = None) -> float:
    """Ebbinghaus retention for a single concept."""
    if cm.last_tested is None:
        return cm.mastery_score * 0.5   # Unknown decay — assume half gone

    if now is None:
        now = datetime.now(timezone.utc)

    last = cm.last_tested
    # Make timezone-aware if naive
    if last.tzinfo is None:
        last = last.replace(tzinfo=timezone.utc)

    elapsed_hours = (now - last).total_seconds() / 3600
    stability = BASE_STABILITY_HOURS + cm.mastery_score * STABILITY_SCALE
    retention = cm.mastery_score * math.exp(-elapsed_hours / stability)
    return max(0.0, min(1.0, retention))


def get_review_schedule(profile: StudentProfile) -> list[ReviewItem]:
    """
    Return all concepts sorted by review urgency.

    Usage:
        schedule = get_review_schedule(profile)
        due_now  = [r for r in schedule if r.urgency in ("critical", "due")]
    """
    now = datetime.now(timezone.utc)
    items = []

    for cid, cm in profile.concept_mastery.items():
        retention = compute_retention(cm, now)
        stability = BASE_STABILITY_HOURS + cm.mastery_score * STABILITY_SCALE
        next_review_hours = stability * math.log(cm.mastery_score / REVIEW_THRESHOLD) \
            if cm.mastery_score > REVIEW_THRESHOLD else 0.0

        if cm.last_tested:
            last = cm.last_tested
            if last.tzinfo is None:
                last = last.replace(tzinfo=timezone.utc)
            next_review_at = last + timedelta(hours=max(0, next_review_hours))
            hours_overdue = (now - next_review_at).total_seconds() / 3600
        else:
            next_review_at = now
            hours_overdue = 999.0

        if retention < CRITICAL_THRESHOLD:
            urgency = "critical"
        elif retention < REVIEW_THRESHOLD:
            urgency = "due"
        elif hours_overdue > -24:
            urgency = "upcoming"
        else:
            urgency = "ok"

        items.append(ReviewItem(
            concept_id=cid,
            concept_name=cm.concept_name,
            mastery=round(cm.mastery_score, 3),
            retention=round(retention, 3),
            hours_overdue=round(hours_overdue, 1),
            urgency=urgency,
            next_review_at=next_review_at,
        ))

    # Sort: critical first, then by hours_overdue descending
    urgency_order = {"critical": 0, "due": 1, "upcoming": 2, "ok": 3}
    items.sort(key=lambda x: (urgency_order[x.urgency], -x.hours_overdue))
    return items


def select_next_concept(profile: StudentProfile) -> str:
    """
    Pick the highest-priority concept to study next.

    Priority order:
      1. Critical retention (concept almost forgotten)
      2. Due for review
      3. Lowest mastery (most to learn)
      4. Current topic (no-op if already optimal)
    """
    schedule = get_review_schedule(profile)
    critical = [r for r in schedule if r.urgency == "critical"]
    if critical:
        return critical[0].concept_id

    due = [r for r in schedule if r.urgency == "due"]
    if due:
        return due[0].concept_id

    # Fall back to lowest mastery
    if profile.concept_mastery:
        return min(profile.concept_mastery, key=lambda c: profile.concept_mastery[c].mastery_score)

    return profile.current_topic


def format_schedule_summary(schedule: list[ReviewItem]) -> str:
    """Human-readable review schedule for the student."""
    if not schedule:
        return "No concepts tracked yet."

    lines = []
    for item in schedule:
        icon = {"critical": "🔴", "due": "🟡", "upcoming": "🟢", "ok": "✅"}[item.urgency]
        if item.urgency in ("critical", "due"):
            time_str = f"{abs(item.hours_overdue):.0f}h overdue"
        elif item.urgency == "upcoming":
            time_str = f"due in {abs(item.hours_overdue):.0f}h"
        else:
            time_str = f"next review in {abs(item.hours_overdue):.0f}h"
        lines.append(
            f"  {icon} {item.concept_name} — mastery {item.mastery:.0%} · retention {item.retention:.0%} · {time_str}"
        )
    return "\n".join(lines)
